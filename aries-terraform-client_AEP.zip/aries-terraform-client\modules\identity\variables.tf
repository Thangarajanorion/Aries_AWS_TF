variable "project" {
  type = string
}

variable "environment" {
  type = string
}

variable "aws_account_id" {
  type = string
}

variable "aws_region" {
  type = string
}

variable "entra_tenant_id" {
  type = string
}

variable "domain_name" {
  type = string
}

variable "sso_admin_group_name" {
  type = string
}

variable "sso_dev_group_name" {
  type = string
}

variable "sso_readonly_group_name" {
  type = string
}