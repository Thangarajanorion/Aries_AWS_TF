project     = "myproject"
environment = "dev"

# ---------------- Account ----------------
# FILL IN: the target AWS account and region
aws_region     = "eu-north-1"
aws_account_id = "<AWS_ACCOUNT_ID>"

# ---------------- VPC ----------------
vpc_cidr = "10.1.0.0/16"

availability_zones = [
  "eu-north-1a",
  "eu-north-1b"
]

public_subnet_cidrs = [
  "10.1.1.0/24",
  "10.1.2.0/24"
]

private_app_subnet_cidrs = [
  "10.1.11.0/24",
  "10.1.12.0/24"
]

private_data_subnet_cidrs = [
  "10.1.21.0/24",
  "10.1.22.0/24"
]

# ---------------- DB ----------------
db_name = "appdb"
db_user = "dbadmin"
# DB password: generated and stored in Secrets Manager (<project>-<environment>-db-secret), not here.
db_instance_class    = "db.t3.medium"
db_allocated_storage = 20
db_multi_az          = false

# ---------------- OpenSearch Serverless ----------------
# ⚠️ TWO-PASS DEPLOYMENT REQUIRED:
# Pass 1: leave aoss_vpc_endpoint_id = "" (creates VPC endpoint)
# Pass 2: set to output value from pass 1:
#   Run: terraform output aoss_vpc_endpoint_id
#   Then set it here and run terraform apply again
aoss_vpc_endpoint_id = ""

# ---------------- Identity / DNS ----------------
# FILL IN: the client's domain and Entra tenant
domain_name     = "<DOMAIN_NAME>"
entra_tenant_id = "<ENTRA_TENANT_ID>"

sso_admin_group_name    = "Admins"
sso_dev_group_name      = "Developers"
sso_readonly_group_name = "ReadOnly"

# FILL IN: image tags pushed to the ECR repositories this code creates
image_tag_backend  = "<BACKEND_IMAGE_TAG>"
image_tag_frontend = "<FRONTEND_IMAGE_TAG>"

# ---------------- Retention ----------------
incident_index_name  = "aries-incidents-idx"
incident_query_field = "ticket_creation_date.keyword"
retention_days       = 90

# Staged rollout. Enable in this order:
#   1. Apply as-is                       -> infra created, nothing deletes
#   2. Invoke Lambda manually            -> confirms eligible count
#   3. retention_dry_run = false         -> OpenSearch deletes on invoke
#   4. retention_schedule_enabled = true -> daily job active
#
# Keep FALSE. The Lambda handles S3 deletion so that both
# stores use ticket_creation_date. An S3 lifecycle rule would
# expire on upload date and cause the two to drift.
incident_retention_enabled = false

# Lambda deletes the matching S3 object in the same pass
delete_s3_objects          = true
retention_dry_run          = true
retention_schedule_enabled = false

# Extra IAM principals granted OpenSearch read access (troubleshooting only)
additional_access_principals = []

# ---------------- AgentCore Gateway ----------------
# AWS_IAM: the ARIES API task role signs requests (no Entra setup needed).
# CUSTOM_JWT: callers send an Entra ID token; set entra_tenant_id above and
#             the audiences / client IDs below.
agentcore_gateway_authorizer_type       = "AWS_IAM"
agentcore_gateway_jwt_allowed_audiences = []
agentcore_gateway_jwt_allowed_clients   = []

# Tools exposed to the agents. Examples:
# agentcore_gateway_lambda_targets = {
#   "ticket-lookup" = {
#     lambda_arn         = "arn:aws:lambda:eu-north-1:<account>:function:<name>"
#     tool_schema_s3_uri = "s3://<bucket>/gateway/ticket-lookup-tools.json"
#   }
# }
# agentcore_gateway_openapi_targets = {
#   "servicenow" = {
#     spec_s3_uri               = "s3://<bucket>/gateway/servicenow-openapi.json"
#     api_key_secret_arn        = "arn:aws:secretsmanager:eu-north-1:<account>:secret:<name>"
#     credential_parameter_name = "Authorization"
#     credential_prefix         = "Bearer "
#   }
# }
agentcore_gateway_lambda_targets     = {}
agentcore_gateway_openapi_targets    = {}
agentcore_gateway_mcp_server_targets = {}