########################################
# Knowledge Base Bucket
########################################
resource "aws_s3_bucket" "knowledge" {
  bucket = "${var.project}-${var.environment}-knowledge-bucket"

  tags = {
    Name = "${var.project}-${var.environment}-knowledge-bucket"
  }
}

resource "aws_s3_bucket_versioning" "knowledge_versioning" {
  bucket = aws_s3_bucket.knowledge.id

  versioning_configuration {
    status = "Enabled"
  }
}

########################################
# Incidents Bucket
########################################
resource "aws_s3_bucket" "incidents" {
  bucket = "${var.project}-${var.environment}-incidents-bucket"

  tags = {
    Name = "${var.project}-${var.environment}-incidents-bucket"
  }
}

resource "aws_s3_bucket_versioning" "incidents_versioning" {
  bucket = aws_s3_bucket.incidents.id

  versioning_configuration {
    status = "Enabled"
  }
}

########################################
# Basic Bucket Public Access Block
########################################
resource "aws_s3_bucket_public_access_block" "knowledge_block" {
  bucket = aws_s3_bucket.knowledge.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_public_access_block" "incidents_block" {
  bucket = aws_s3_bucket.incidents.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

########################################
# Incidents Bucket - Retention Policy
#
# Versioning is ENABLED on this bucket.
# A plain `expiration` block only creates delete
# markers - the object data remains as a noncurrent
# version and continues to be billed.
#
# `noncurrent_version_expiration` is what actually
# removes the data. Both are required.
#
# Two rules are used because S3 does not permit
# `days` and `expired_object_delete_marker` within
# the same expiration block.
#
# Set incident_retention_enabled = false to disable
# without removing this code.
########################################
resource "aws_s3_bucket_lifecycle_configuration" "incidents_retention" {
  count = var.incident_retention_enabled ? 1 : 0

  bucket = aws_s3_bucket.incidents.id

  depends_on = [aws_s3_bucket_versioning.incidents_versioning]

  # ---- Rule 1: expire current and previous versions ----
  rule {
    id     = "expire-incidents-after-retention"
    status = "Enabled"

    filter {
      prefix = var.incident_retention_prefix
    }

    expiration {
      days = var.incident_retention_days
    }

    noncurrent_version_expiration {
      noncurrent_days = var.incident_retention_days
    }

    abort_incomplete_multipart_upload {
      days_after_initiation = 7
    }
  }

  # ---- Rule 2: clean up orphaned delete markers ----
  rule {
    id     = "remove-expired-delete-markers"
    status = "Enabled"

    filter {
      prefix = var.incident_retention_prefix
    }

    expiration {
      expired_object_delete_marker = true
    }
  }
}

########################################
# Knowledge Bucket - Retention Policy
#
# Disabled by default. The knowledge base is
# reference material rather than time-series data,
# so it is not normally subject to expiry.
# Enable only if the client explicitly requires it.
########################################
resource "aws_s3_bucket_lifecycle_configuration" "knowledge_retention" {
  count = var.knowledge_retention_enabled ? 1 : 0

  bucket = aws_s3_bucket.knowledge.id

  depends_on = [aws_s3_bucket_versioning.knowledge_versioning]

  rule {
    id     = "expire-knowledge-after-retention"
    status = "Enabled"

    filter {
      prefix = var.knowledge_retention_prefix
    }

    expiration {
      days = var.knowledge_retention_days
    }

    noncurrent_version_expiration {
      noncurrent_days = var.knowledge_retention_days
    }

    abort_incomplete_multipart_upload {
      days_after_initiation = 7
    }
  }

  rule {
    id     = "remove-expired-delete-markers"
    status = "Enabled"

    filter {
      prefix = var.knowledge_retention_prefix
    }

    expiration {
      expired_object_delete_marker = true
    }
  }
}
