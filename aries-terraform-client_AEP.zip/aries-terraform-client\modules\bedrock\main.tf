########################################
# 🤖 Bedrock — Knowledge Base + Agent + Guardrail
# Region: eu-north-1 (Test Infrastructure)
# Embedding: amazon.titan-embed-text-v2:0 (1024 dims)
# Storage: OpenSearch Serverless
#
# KEY DIFFERENCES FROM us-east-2:
# 1. Agent foundation model uses eu. cross-region
#    inference profile prefix — bare model IDs are
#    not supported for Agents in eu-north-1.
# 2. Titan Embed v2 is ON_DEMAND in eu-north-1 —
#    no inference profile needed for embeddings.
# 3. Guardrail config carried over from us-east-2
#    (was missing in eu-north-1 version).
#
# TWO-PASS DEPLOYMENT:
# Pass 1: aoss_vpc_endpoint_id = "" 
#         → KB, data source, KB association skipped (count=0)
#         → Agent, guardrail, alias created normally
# Pass 2: aoss_vpc_endpoint_id = "vpce-xxx"
#         → KB, data source, KB association created
#         → Agent associated with KB
########################################

########################################
# KNOWLEDGE BASE (OpenSearch Serverless)
# ⚠️ Pass 2 only — index must exist first
########################################
resource "aws_bedrockagent_knowledge_base" "this" {
  count    = var.aoss_vpc_endpoint_id != "" ? 1 : 0

  name     = "${var.project}-${var.environment}-kb"
  role_arn = var.bedrock_kb_role_arn

  knowledge_base_configuration {
    type = "VECTOR"

    vector_knowledge_base_configuration {
      # ✅ eu-north-1: Titan Embed v2 is ON_DEMAND — use bare model ID,
      # no eu. inference profile prefix needed for embeddings.
      embedding_model_arn = "arn:aws:bedrock:${var.aws_region}::foundation-model/amazon.titan-embed-text-v2:0"
    }
  }

  storage_configuration {
    type = "OPENSEARCH_SERVERLESS"

    opensearch_serverless_configuration {
      collection_arn    = var.opensearch_collection_arn
      vector_index_name = var.opensearch_vector_index_name

      field_mapping {
        vector_field   = "embedding"
        text_field     = "text"
        metadata_field = "metadata"
      }
    }
  }

  tags = {
    Project     = var.project
    Environment = var.environment
  }
}

########################################
# KNOWLEDGE BASE DATA SOURCE (S3)
# ⚠️ Pass 2 only — KB must exist first
########################################
resource "aws_bedrockagent_data_source" "s3" {
  count             = var.aoss_vpc_endpoint_id != "" ? 1 : 0

  knowledge_base_id = aws_bedrockagent_knowledge_base.this[0].id
  name              = "${var.project}-${var.environment}-s3-datasource"

  data_source_configuration {
    type = "S3"

    s3_configuration {
      bucket_arn = var.kb_s3_bucket_arn
    }
  }

  vector_ingestion_configuration {
    chunking_configuration {
      chunking_strategy = "FIXED_SIZE"

      fixed_size_chunking_configuration {
        max_tokens         = 512
        overlap_percentage = 20
      }
    }
  }
}

########################################
# GUARDRAIL
# ✅ Created on Pass 1 — no dependency on index
# All filters per Security & Governance Briefing §6.1
########################################
resource "aws_bedrock_guardrail" "this" {
  name                      = "${var.project}-${var.environment}-guardrail"
  blocked_input_messaging   = "Your request has been blocked by our content policy."
  blocked_outputs_messaging = "The response has been blocked by our content policy."
  description               = "Guardrail for ARIES ${var.environment} environment"

  ########################################
  # CONTENT FILTERS
  # §6.1: Hate, Insults, Violence, Sexual,
  # Misconduct — all HIGH filter strength.
  ########################################
  content_policy_config {
    filters_config {
      input_strength  = "HIGH"
      output_strength = "HIGH"
      type            = "HATE"
    }
    filters_config {
      input_strength  = "HIGH"
      output_strength = "HIGH"
      type            = "VIOLENCE"
    }
    filters_config {
      input_strength  = "HIGH"
      output_strength = "HIGH"
      type            = "MISCONDUCT"
    }
    filters_config {
      input_strength  = "HIGH"
      output_strength = "NONE"
      type            = "PROMPT_ATTACK"
    }
    filters_config {
      input_strength  = "HIGH"
      output_strength = "HIGH"
      type            = "INSULTS"
    }
    filters_config {
      input_strength  = "HIGH"
      output_strength = "HIGH"
      type            = "SEXUAL"
    }
  }

  ########################################
  # PII REDACTION
  # §6.1: NAME, EMAIL, PHONE, SSN,
  # CREDIT_CARD, AWS_ACCESS_KEY
  ########################################
  sensitive_information_policy_config {
    pii_entities_config {
      action = "BLOCK"
      type   = "EMAIL"
    }
    pii_entities_config {
      action = "ANONYMIZE"
      type   = "NAME"
    }
    pii_entities_config {
      action = "ANONYMIZE"
      type   = "PHONE"
    }
    pii_entities_config {
      action = "ANONYMIZE"
      type   = "US_SOCIAL_SECURITY_NUMBER"
    }
    pii_entities_config {
      action = "ANONYMIZE"
      type   = "CREDIT_DEBIT_CARD_NUMBER"
    }
    pii_entities_config {
      action = "ANONYMIZE"
      type   = "AWS_ACCESS_KEY"
    }
  }

  ########################################
  # TOPIC DENIAL
  # §6.1: political opinions, financial advice,
  # medical diagnosis, competitor comparisons.
  ########################################
  topic_policy_config {
    tier_config {
      tier_name = "CLASSIC"
    }
    topics_config {
      name       = "political-opinions"
      type       = "DENY"
      definition = "Any discussion of political parties, politicians, elections, political ideologies, or government policies."
      examples   = ["Who should I vote for?", "What do you think about the current government?"]
    }
    topics_config {
      name       = "personal-financial-advice"
      type       = "DENY"
      definition = "Personalised advice on investments, savings, loans, insurance, or any financial decisions."
      examples   = ["Should I invest in crypto?", "Which stocks should I buy?"]
    }
    topics_config {
      name       = "medical-diagnosis"
      type       = "DENY"
      definition = "Any medical diagnosis, treatment recommendations, or health advice for specific individuals."
      examples   = ["Do I have diabetes?", "What medication should I take for my headache?"]
    }
    topics_config {
      name       = "competitor-comparisons"
      type       = "DENY"
      definition = "Comparisons between Grange Insurance and competitor products, pricing, or services."
      examples   = ["Is your insurance cheaper than Allstate?", "How do you compare to State Farm?"]
    }
  }

  ########################################
  # WORD FILTERS
  # §6.1: profanity, system identifiers,
  # credential-related terms.
  ########################################
  word_policy_config {
    words_config { text = "password" }
    words_config { text = "api_key" }
    words_config { text = "apikey" }
    words_config { text = "secret_key" }
    words_config { text = "access_key" }
    words_config { text = "private_key" }
    words_config { text = "client_secret" }
    words_config { text = "auth_token" }
    words_config { text = "bearer_token" }
    words_config { text = "webhook_secret" }
    words_config { text = "aries-dev" }
    words_config { text = "aries-prod" }
    words_config { text = "gts-oiaries" }

    managed_word_lists_config {
      type = "PROFANITY"
    }
  }

  ########################################
  # GROUNDING CHECK
  # §6.1 + §6.4: threshold 0.75
  ########################################
  contextual_grounding_policy_config {
    filters_config {
      type      = "GROUNDING"
      threshold = 0.75
    }
    filters_config {
      type      = "RELEVANCE"
      threshold = 0.75
    }
  }

  tags = {
    Project     = var.project
    Environment = var.environment
  }
}

########################################
# GUARDRAIL VERSION
# ✅ Created on Pass 1
########################################
resource "aws_bedrock_guardrail_version" "this" {
  guardrail_arn = aws_bedrock_guardrail.this.guardrail_arn
  description   = "v1 for ${var.environment}"
}

########################################
# BEDROCK AGENT
# ✅ Created on Pass 1 — no KB dependency
# ✅ eu-north-1: Claude Sonnet requires the eu.
# cross-region inference profile prefix.
# Bare model IDs are NOT supported for Agents
# in eu-north-1 — must use eu.* profile.
########################################
resource "aws_bedrockagent_agent" "this" {
  agent_name              = "${var.project}-${var.environment}-agent"
  agent_resource_role_arn = var.bedrock_agent_role_arn

  # Must use the eu. prefixed cross-region inference profile
  foundation_model = var.agent_foundation_model

  description                 = "Bedrock Agent for ${var.project} ${var.environment}"
  idle_session_ttl_in_seconds = 600
  instruction                 = var.agent_instruction

  guardrail_configuration {
    guardrail_identifier = aws_bedrock_guardrail.this.guardrail_id
    guardrail_version    = aws_bedrock_guardrail_version.this.version
  }

  tags = {
    Project     = var.project
    Environment = var.environment
  }

  depends_on = [
    aws_bedrock_guardrail_version.this
  ]
}

########################################
# AGENT — KNOWLEDGE BASE ASSOCIATION
# ⚠️ Pass 2 only — KB must exist first
########################################
resource "aws_bedrockagent_agent_knowledge_base_association" "this" {
  count = var.aoss_vpc_endpoint_id != "" ? 1 : 0

  agent_id             = aws_bedrockagent_agent.this.agent_id
  knowledge_base_id    = aws_bedrockagent_knowledge_base.this[0].id
  description          = "KB association for ${var.project}-${var.environment}"
  knowledge_base_state = "ENABLED"
}

########################################
# AGENT ALIAS
# ✅ Created on Pass 1
########################################
resource "aws_bedrockagent_agent_alias" "this" {
  agent_id         = aws_bedrockagent_agent.this.agent_id
  agent_alias_name = "${var.environment}-alias"

  tags = {
    Project     = var.project
    Environment = var.environment
  }

  depends_on = [
    aws_bedrockagent_agent.this
  ]
}
