########################################
# OpenSearch Serverless Variables
# Removed: instance_type, instance_count, volume_size
# Added:   aoss_vpc_endpoint_id
########################################

variable "project" {
  type = string
}

variable "environment" {
  type = string
}

variable "aws_account_id" {
  type = string
}

variable "aws_region" {
  type = string
}

variable "vpc_id" {
  type        = string
  description = "VPC ID for aoss VPC endpoint"
}

variable "subnet_ids" {
  type        = list(string)
  description = "Subnet IDs for aoss VPC endpoint"
}

variable "security_group_id" {
  type        = string
  description = "Security group for aoss VPC endpoint"
}

variable "aoss_vpc_endpoint_id" {
  type        = string
  description = "aoss VPC endpoint ID for network policy (set after first apply)"
  default     = ""
}

variable "backend_task_role_arn" {
  type        = string
  description = "ECS backend task role ARN — added to data access policy"
}

variable "bedrock_kb_role_arn" {
  type        = string
  description = "Bedrock KB role ARN — added to data access policy"
}
