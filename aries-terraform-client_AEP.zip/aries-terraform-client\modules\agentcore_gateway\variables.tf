variable "project" {
  type = string
}

variable "environment" {
  type = string
}

variable "tags" {
  description = "Extra tags for every resource in this module"
  type        = map(string)
  default     = {}
}

########################################
# Inbound authentication
########################################

variable "authorizer_type" {
  description = "AWS_IAM (callers sign with SigV4) or CUSTOM_JWT (callers send a Microsoft Entra ID token)"
  type        = string
  default     = "AWS_IAM"

  validation {
    condition     = contains(["AWS_IAM", "CUSTOM_JWT"], var.authorizer_type)
    error_message = "authorizer_type must be AWS_IAM or CUSTOM_JWT."
  }
}

variable "entra_tenant_id" {
  description = "Microsoft Entra tenant ID (CUSTOM_JWT only); used to build the OIDC discovery URL"
  type        = string
  default     = null
}

variable "jwt_allowed_audiences" {
  description = "Accepted 'aud' values (CUSTOM_JWT only), e.g. the Application ID URI of the Entra app"
  type        = list(string)
  default     = []
}

variable "jwt_allowed_clients" {
  description = "Accepted client IDs (CUSTOM_JWT only), e.g. the Entra app registration client ID"
  type        = list(string)
  default     = []
}

variable "caller_role_arn" {
  description = "IAM role allowed to invoke the gateway (AWS_IAM only); the ARIES API ECS task role"
  type        = string
  default     = null
}

variable "attach_caller_policy" {
  description = "Attach the InvokeGateway policy to caller_role_arn (AWS_IAM only). Set false when caller_role_arn is not given."
  type        = bool
  default     = true
}

########################################
# Targets (tools exposed to the agents)
########################################

variable "lambda_targets" {
  description = <<-EOT
    Lambda functions exposed as MCP tools, keyed by target name (letters, digits, single hyphens).
      lambda_arn         - function to invoke
      tool_schema_s3_uri - s3://bucket/key of the JSON tool definitions for this function
      description        - optional
  EOT
  type = map(object({
    lambda_arn         = string
    tool_schema_s3_uri = string
    description        = optional(string)
  }))
  default = {}
}

variable "openapi_targets" {
  description = <<-EOT
    REST APIs exposed as MCP tools through their OpenAPI spec, keyed by target name.
    The API key is read from Secrets Manager at apply time and stored in an AgentCore
    Identity API key credential provider; it never appears in code, tfvars or state.
      spec_s3_uri               - s3://bucket/key of the OpenAPI 3 spec
      api_key_secret_arn        - Secrets Manager secret holding the API key
      api_key_secret_json_key   - set if the secret is JSON; the key that holds the API key
      api_key_version           - bump to push a rotated key to the credential provider
      credential_location       - HEADER or QUERY_PARAMETER
      credential_parameter_name - header / query parameter name, e.g. Authorization or x-api-key
      credential_prefix         - optional, e.g. "Bearer "
      description               - optional
  EOT
  type = map(object({
    spec_s3_uri               = string
    api_key_secret_arn        = string
    api_key_secret_json_key   = optional(string)
    api_key_version           = optional(number, 1)
    credential_location       = optional(string, "HEADER")
    credential_parameter_name = optional(string, "x-api-key")
    credential_prefix         = optional(string)
    description               = optional(string)
  }))
  default = {}
}

variable "mcp_server_targets" {
  description = <<-EOT
    Existing MCP servers exposed through the gateway, keyed by target name.
      endpoint             - https URL of the MCP server
      oauth_provider_arn   - optional AgentCore Identity OAuth2 credential provider for outbound auth
      oauth_scopes         - scopes requested with oauth_provider_arn
      description          - optional
  EOT
  type = map(object({
    endpoint           = string
    oauth_provider_arn = optional(string)
    oauth_scopes       = optional(list(string), [])
    description        = optional(string)
  }))
  default = {}
}

variable "enable_semantic_search" {
  description = "Adds the built-in semantic tool search; cannot be changed after the gateway is created"
  type        = bool
  default     = false
}

########################################
# Network
########################################

variable "create_vpc_endpoint" {
  description = "Create an interface VPC endpoint (private DNS) so callers reach the gateway without leaving the VPC"
  type        = bool
  default     = true
}

variable "vpc_id" {
  type    = string
  default = null
}

variable "endpoint_subnet_ids" {
  description = "Subnets for the VPC endpoint network interfaces"
  type        = list(string)
  default     = []
}

variable "allowed_security_group_ids" {
  description = "Security groups allowed to reach the VPC endpoint on 443 (the ECS API security group)"
  type        = list(string)
  default     = []
}

########################################
# Encryption and logging
########################################

variable "kms_key_arn" {
  description = "Customer managed KMS key for the gateway and its log group; null uses AWS owned keys"
  type        = string
  default     = null
}

variable "enable_logging" {
  description = "Send gateway application logs to a CloudWatch log group"
  type        = bool
  default     = true
}

variable "log_retention_days" {
  type    = number
  default = 30
}
