########################################
# BACKEND ECR REPOSITORY
########################################

resource "aws_ecr_repository" "backend" {
  name = "${var.project}-${var.environment}-api"

  image_scanning_configuration {
    scan_on_push = true
  }

  force_delete = true

  tags = {
    Name        = "${var.project}-${var.environment}-api"
    Environment = var.environment
  }
}

########################################
# FRONTEND ECR REPOSITORY
########################################

resource "aws_ecr_repository" "frontend" {
  name = "${var.project}-${var.environment}-fe"

  image_scanning_configuration {
    scan_on_push = true
  }

  force_delete = true

  tags = {
    Name        = "${var.project}-${var.environment}-fe"
    Environment = var.environment
  }
}