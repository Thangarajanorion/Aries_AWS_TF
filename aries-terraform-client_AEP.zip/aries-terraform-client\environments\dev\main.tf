########################################
# 🌍 Providers
########################################
provider "aws" {
  region = var.aws_region
}

########################################
# LEVEL 0 — Identity + Base Infra
########################################

module "identity" {
  source = "../../modules/identity"

  project         = var.project
  environment     = var.environment
  aws_account_id  = var.aws_account_id
  aws_region      = var.aws_region
  entra_tenant_id = var.entra_tenant_id

  domain_name             = var.domain_name
  sso_admin_group_name    = var.sso_admin_group_name
  sso_dev_group_name      = var.sso_dev_group_name
  sso_readonly_group_name = var.sso_readonly_group_name
}

module "networking" {
  source = "../../modules/networking"

  project                   = var.project
  environment               = var.environment
  vpc_cidr                  = var.vpc_cidr
  availability_zones        = var.availability_zones
  public_subnet_cidrs       = var.public_subnet_cidrs
  private_app_subnet_cidrs  = var.private_app_subnet_cidrs
  private_data_subnet_cidrs = var.private_data_subnet_cidrs
}

module "iam" {
  source = "../../modules/iam"

  project        = var.project
  environment    = var.environment
  aws_account_id = var.aws_account_id
  aws_region     = var.aws_region

  backend_secret_arn = module.secrets.backend_secret_arn
}

module "s3" {
  source = "../../modules/s3"

  project        = var.project
  environment    = var.environment
  aws_account_id = var.aws_account_id
  kb_role_arn    = module.iam.bedrock_kb_role_arn

  # S3 lifecycle rule. NOTE: leave this DISABLED.
  # Deletion is handled by the retention Lambda instead, so
  # that S3 and OpenSearch both key off ticket_creation_date.
  # An S3 lifecycle rule can only expire on UPLOAD date, which
  # would cause the two stores to drift apart.
  incident_retention_enabled = var.incident_retention_enabled
  incident_retention_days    = var.retention_days

  depends_on = [module.iam]
}

########################################
# LEVEL 1 — Security Layer
########################################

module "security_groups" {
  source = "../../modules/security_groups"

  project     = var.project
  environment = var.environment
  vpc_id      = module.networking.vpc_id

  depends_on = [module.networking]
}

module "secrets" {
  source = "../../modules/secrets"

  project            = var.project
  environment        = var.environment
  db_name            = var.db_name
  oidc_client_id     = module.identity.oidc_client_id
  oidc_client_secret = module.identity.oidc_client_secret

  depends_on = [module.identity]
}

########################################
# LEVEL 2 — Core Services
########################################

module "rds" {
  source = "../../modules/rds"

  project           = var.project
  environment       = var.environment
  db_name           = var.db_name
  db_user           = var.db_user
  instance_class    = var.db_instance_class
  allocated_storage = var.db_allocated_storage
  multi_az          = var.db_multi_az

  subnet_ids        = module.networking.private_data_subnet_ids
  security_group_id = module.security_groups.rds_sg_id
  db_secret_arn     = module.secrets.db_secret_arn

  depends_on = [module.networking, module.security_groups, module.secrets]
}

########################################
# ✅ OpenSearch Serverless (replaces provisioned)
# KEY CHANGE: removed instance_type/count/volume_size
# Added: aoss_vpc_endpoint_id for network policy
# Two-pass deploy:
#   Pass 1: aoss_vpc_endpoint_id = "" → public access temporarily
#   Pass 2: aoss_vpc_endpoint_id = "vpce-xxx" → VPC-only access
# ✅ opensearch provider removed — index created manually
#    from inside VPC using awscurl (see create_index_command output)
########################################
module "opensearch" {
  source = "../../modules/opensearch"

  project        = var.project
  environment    = var.environment
  aws_account_id = var.aws_account_id
  aws_region     = var.aws_region

  vpc_id            = module.networking.vpc_id
  subnet_ids        = module.networking.private_data_subnet_ids
  security_group_id = module.security_groups.opensearch_sg_id

  aoss_vpc_endpoint_id  = var.aoss_vpc_endpoint_id
  backend_task_role_arn = module.iam.ecs_backend_task_role_arn
  bedrock_kb_role_arn   = module.iam.bedrock_kb_role_arn
}

module "alb" {
  source = "../../modules/alb"

  project           = var.project
  environment       = var.environment
  vpc_id            = module.networking.vpc_id
  public_subnet_ids = module.networking.public_subnet_ids
  security_group_id = module.security_groups.alb_sg_id

  depends_on = [module.networking, module.security_groups]
}

########################################
# LEVEL 3 — ECR
########################################
module "ecr" {
  source = "../../modules/ecr"

  project     = var.project
  environment = var.environment
}

########################################
# LEVEL 3 — ECS
# ✅ OPENSEARCH_ENDPOINT points to serverless endpoint
# Format: https://xxx.eu-north-1.aoss.amazonaws.com
########################################
module "ecs" {
  source = "../../modules/ecs"

  project     = var.project
  environment = var.environment
  aws_region  = var.aws_region

  private_subnet_ids = module.networking.private_app_subnet_ids
  backend_sg_id      = module.security_groups.ecs_backend_sg_id
  frontend_sg_id     = module.security_groups.ecs_frontend_sg_id

  execution_role_arn     = module.iam.ecs_execution_role_arn
  backend_task_role_arn  = module.iam.ecs_backend_task_role_arn
  frontend_task_role_arn = module.iam.ecs_frontend_task_role_arn

  backend_image  = "${module.ecr.backend_repository_url}:${var.image_tag_backend}"
  frontend_image = "${module.ecr.frontend_repository_url}:${var.image_tag_frontend}"

  backend_target_group_arn  = module.alb.backend_target_group_arn
  frontend_target_group_arn = module.alb.frontend_target_group_arn

  rds_endpoint           = module.rds.endpoint
  opensearch_kb_endpoint = module.opensearch.opensearch_endpoint

  db_name            = var.db_name
  db_user            = var.db_user
  backend_secret_arn = module.secrets.backend_secret_arn

  bedrock_agent_id          = module.bedrock.agent_id
  bedrock_agent_alias_id    = module.bedrock.agent_alias_id
  bedrock_knowledge_base_id = module.bedrock.knowledge_base_id

  depends_on = [
    module.rds,
    module.opensearch,
    module.alb,
    module.iam,
    module.bedrock
  ]
}

########################################
# LEVEL 4 — Bedrock
########################################
module "bedrock" {
  source = "../../modules/bedrock"

  project        = var.project
  environment    = var.environment
  aws_region     = var.aws_region
  aws_account_id = var.aws_account_id

  bedrock_kb_role_arn    = module.iam.bedrock_kb_role_arn
  bedrock_agent_role_arn = module.iam.bedrock_agent_role_arn

  kb_s3_bucket_arn             = module.s3.knowledge_bucket_arn
  opensearch_collection_arn    = module.opensearch.opensearch_serverless_collection_arn
  opensearch_vector_index_name = module.opensearch.vector_index_name

  # ✅ Pass aoss_vpc_endpoint_id to control two-pass KB creation
  aoss_vpc_endpoint_id = var.aoss_vpc_endpoint_id

  agent_foundation_model = "arn:aws:bedrock:eu-north-1:${var.aws_account_id}:inference-profile/eu.anthropic.claude-sonnet-4-6"

  agent_instruction = "You are a helpful assistant. Answer questions using the knowledge base."

  depends_on = [
    module.iam,
    module.s3,
    module.opensearch
  ]
}

########################################
# LEVEL 5 — Edge Layer
########################################
module "cloudfront" {
  source = "../../modules/cloudfront"

  alb_dns_name = module.alb.alb_dns_name
  domain_name  = var.domain_name

  depends_on = [module.alb]
}

########################################
# LEVEL 6 — DNS
########################################
module "dns" {
  source = "../../modules/dns"

  domain_name       = var.domain_name
  cloudfront_domain = module.cloudfront.cloudfront_domain
  alb_dns           = module.alb.alb_dns_name
  alb_zone_id       = module.alb.alb_zone_id
}

########################################
# LEVEL 7 - Retention (NEW)
#
# Deletes incident data older than the retention period
# from OpenSearch Serverless. The S3 side is handled by
# lifecycle rules inside the s3 module.
#
# A Lambda is required for OpenSearch because:
#   1. AOSS data lifecycle policies support only TIME
#      SERIES collections; ours is VECTORSEARCH
#   2. _delete_by_query is not supported in AOSS
#   3. Only search + bulk delete by _id are available
#
# SAFETY: dry_run and schedule_enabled default to safe
# values, so applying changes nothing until enabled.
########################################
module "retention" {
  source = "../../modules/retention"

  project     = var.project
  environment = var.environment
  aws_region  = var.aws_region

  opensearch_endpoint          = module.opensearch.opensearch_endpoint
  opensearch_collection_arn    = module.opensearch.opensearch_serverless_collection_arn
  opensearch_collection_name   = module.opensearch.collection_name
  opensearch_security_group_id = module.security_groups.opensearch_sg_id

  incident_index_name = var.incident_index_name

  # ticket_creation_date is mapped as TEXT, not date, so the
  # .keyword subfield must be queried.
  query_field    = var.incident_query_field
  retention_days = var.retention_days

  dry_run          = var.retention_dry_run
  schedule_enabled = var.retention_schedule_enabled

  # Deletes the matching S3 object in the same pass, so both
  # stores are driven by ticket_creation_date and cannot drift.
  incidents_bucket_arn = module.s3.incidents_bucket_arn
  delete_s3_objects    = var.delete_s3_objects

  # TEMPORARY: extra identities granted read access for
  # troubleshooting. Reset to [] when finished.
  additional_access_principals = var.additional_access_principals

  vpc_id     = module.networking.vpc_id
  subnet_ids = module.networking.private_data_subnet_ids

  depends_on = [
    module.opensearch,
    module.security_groups,
    module.networking
  ]
}

########################################
# LEVEL 8 - OSI on-demand scheduler
########################################
# The OSI pipelines themselves are not managed by Terraform yet; their names
# and S3 sources below must match the live pipeline configuration.
module "osi_scheduler" {
  source = "../../modules/osi_scheduler"

  project     = var.project
  environment = var.environment

  pipelines = {
    "${var.project}-${var.environment}-incidents" = {
      sub_pipeline     = "incidents-approved-pipeline"
      bucket           = module.s3.incidents_bucket_name
      prefixes         = ["approved-incidents/"]
      exclude_suffixes = [".pdf", ".md"]
    }
    "${var.project}-${var.environment}-knowledge" = {
      sub_pipeline     = "knowledge-approved-pipeline"
      bucket           = module.s3.knowledge_bucket_name
      prefixes         = ["approved-files/"]
      exclude_suffixes = [".pdf", ".md"]
    }
  }
}
########################################
# LEVEL 9 - AgentCore Gateway (MCP tools for the ARIES agents)
########################################
module "agentcore_gateway" {
  source = "../../modules/agentcore_gateway"

  project     = var.project
  environment = var.environment

  authorizer_type       = var.agentcore_gateway_authorizer_type
  entra_tenant_id       = var.entra_tenant_id
  jwt_allowed_audiences = var.agentcore_gateway_jwt_allowed_audiences
  jwt_allowed_clients   = var.agentcore_gateway_jwt_allowed_clients
  caller_role_arn       = module.iam.ecs_backend_task_role_arn

  lambda_targets = merge(var.agentcore_gateway_lambda_targets, {
    "incident-tools" = {
      lambda_arn         = module.gateway_tools.lambda_arn
      tool_schema_s3_uri = module.gateway_tools.tool_schema_s3_uri
      description        = "Look up approved ARIES incidents"
    }
  })
  openapi_targets    = var.agentcore_gateway_openapi_targets
  mcp_server_targets = var.agentcore_gateway_mcp_server_targets

  vpc_id                     = module.networking.vpc_id
  endpoint_subnet_ids        = module.networking.private_data_subnet_ids
  allowed_security_group_ids = [module.security_groups.ecs_backend_sg_id]

  kms_key_arn = var.agentcore_gateway_kms_key_arn
}

# First gateway tool: read-only lookup of approved incidents in S3.
module "gateway_tools" {
  source = "../../modules/gateway_tools"

  project     = var.project
  environment = var.environment

  incidents_bucket_name = module.s3.incidents_bucket_name
  incidents_bucket_arn  = module.s3.incidents_bucket_arn
}