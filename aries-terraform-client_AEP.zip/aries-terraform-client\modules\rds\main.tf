########################################
# 🗄️ RDS Subnet Group
########################################

resource "aws_db_subnet_group" "this" {
  name       = "${var.project}-${var.environment}-db-subnet"
  subnet_ids = var.subnet_ids

  tags = {
    Name = "${var.project}-${var.environment}-db-subnet"
  }
}

########################################
# 🔐 Secrets Manager Reference
########################################

data "aws_secretsmanager_secret_version" "db" {
  secret_id = var.db_secret_arn
}

########################################
# 🔐 RDS Instance
########################################

resource "aws_db_instance" "this" {

  identifier = "${var.project}-${var.environment}-db"

  engine         = "postgres"
  engine_version = "15"

  instance_class = var.instance_class

  allocated_storage = var.allocated_storage

  db_name  = var.db_name

  # ✅ FIXED: valid RDS username
  username = "dbadmin"

  # password from Secrets Manager
  password = jsondecode(data.aws_secretsmanager_secret_version.db.secret_string)["password"]

  db_subnet_group_name   = aws_db_subnet_group.this.name
  vpc_security_group_ids = [var.security_group_id]

  multi_az = var.multi_az

  publicly_accessible = false

  skip_final_snapshot = true

  storage_encrypted = true

  backup_retention_period = 7

  deletion_protection = false
}