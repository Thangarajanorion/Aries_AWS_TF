########################################
# 🌐 Route53 Hosted Zone
########################################

resource "aws_route53_zone" "this" {
  name = var.domain_name
}

########################################
# 🌍 CloudFront Record (Primary App)
########################################

resource "aws_route53_record" "root" {
  zone_id = aws_route53_zone.this.zone_id
  name    = var.domain_name
  type    = "A"

  alias {
    name                   = var.cloudfront_domain
    zone_id                = var.cloudfront_zone_id
    evaluate_target_health = false
  }
}

########################################
# ⚖️ ALB API Subdomain
########################################

resource "aws_route53_record" "api" {
  zone_id = aws_route53_zone.this.zone_id
  name    = "api.${var.domain_name}"
  type    = "A"

  alias {
    name                   = var.alb_dns
    zone_id                = var.alb_zone_id
    evaluate_target_health = true
  }
}