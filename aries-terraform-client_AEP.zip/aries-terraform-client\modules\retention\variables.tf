########################################
# FILE: modules/retention/variables.tf
########################################

variable "project" {
  type = string
}

variable "environment" {
  type = string
}

variable "aws_region" {
  type = string
}

########################################
# OpenSearch
########################################

variable "opensearch_endpoint" {
  type        = string
  description = "AOSS collection endpoint (https:// prefix is stripped automatically)"
}

variable "opensearch_collection_arn" {
  type        = string
  description = "AOSS collection ARN - used for the aoss:APIAccessAll IAM permission"
}

variable "opensearch_collection_name" {
  type        = string
  description = "AOSS collection name - used in the data access policy resource paths"
}

variable "opensearch_security_group_id" {
  type        = string
  description = "Security group attached to the aoss VPC endpoint. An ingress rule is added to it for this Lambda."
}

########################################
# Index and retention
########################################

variable "incident_index_name" {
  type        = string
  description = "Index holding incident documents to expire. Not defined in Terraform elsewhere - obtain from the application team."
}

variable "query_field" {
  type        = string
  description = "Field queried to determine document age. NOTE: in aries-incidents-idx, ticket_creation_date is mapped as TEXT, not date. Text fields must be queried via their .keyword subfield, hence the default below. If the field is ever remapped to a true date type, drop the .keyword suffix."
  default     = "ticket_creation_date.keyword"
}

variable "date_format" {
  type        = string
  description = "strftime format the dates are stored in. Used to build the cutoff string."
  default     = "%Y-%m-%d %H:%M:%S"
}

variable "retention_days" {
  type        = number
  description = "Delete documents older than this many days"
  default     = 90

  validation {
    condition     = var.retention_days >= 1
    error_message = "retention_days must be at least 1."
  }
}

variable "batch_size" {
  type        = number
  description = "Documents deleted per bulk request"
  default     = 500
}

########################################
# Safety controls
########################################

variable "dry_run" {
  type        = bool
  description = "When true the Lambda reports what WOULD be deleted but deletes nothing. Keep true until verified."
  default     = true
}

variable "schedule_enabled" {
  type        = bool
  description = "Whether the daily EventBridge schedule is active. Set false while awaiting security approval."
  default     = false
}

variable "schedule_expression" {
  type        = string
  description = "EventBridge schedule expression"
  default     = "cron(0 2 * * ? *)" # 02:00 UTC daily
}

########################################
# Networking
########################################

variable "vpc_id" {
  type        = string
  description = "VPC ID - Lambda runs inside the VPC to reach the collection"
}

variable "subnet_ids" {
  type        = list(string)
  description = "Private subnet IDs for the Lambda ENIs"
}

########################################
# Monitoring (optional)
########################################

variable "alarm_sns_topic_arn" {
  type        = string
  description = "Optional SNS topic for failure alarms. Empty string disables the alarm."
  default     = ""
}

########################################
# Temporary access (optional)
########################################

variable "additional_access_principals" {
  type        = list(string)
  description = "Extra IAM ARNs granted read access to the collection. Intended for temporary troubleshooting, e.g. a test EC2 instance role used to inspect indices and mappings. Set back to [] once finished."
  default     = []
}

variable "incidents_bucket_arn" {
  type        = string
  description = "ARN of the incidents S3 bucket. The Lambda deletes the matching object alongside the OpenSearch document. Required when delete_s3_objects is true."
  default     = ""
}

variable "delete_s3_objects" {
  type        = bool
  description = "Whether to delete the matching S3 object when deleting an OpenSearch document. Keeps both stores on the same parameter."
  default     = true
}
