########################################
# 🤖 Bedrock — Variables
# Region: eu-north-1 (Test Infrastructure)
########################################

########################################
# GENERAL
########################################

variable "project" {
  description = "Project name"
  type        = string
}

variable "environment" {
  description = "Deployment environment (dev, stg, uat, prod)"
  type        = string
}

variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "eu-north-1"
}

variable "aws_account_id" {
  description = "AWS account ID"
  type        = string
}

########################################
# IAM — separate roles for KB and Agent
########################################

variable "bedrock_kb_role_arn" {
  description = "IAM role ARN for Bedrock Knowledge Base"
  type        = string
}

variable "bedrock_agent_role_arn" {
  description = "IAM role ARN for Bedrock Agent"
  type        = string
}

########################################
# S3
########################################

variable "kb_s3_bucket_arn" {
  description = "ARN of the S3 bucket used as KB data source"
  type        = string
}

########################################
# OPENSEARCH SERVERLESS
########################################

variable "opensearch_collection_arn" {
  description = "OpenSearch Serverless collection ARN"
  type        = string
}

variable "opensearch_vector_index_name" {
  description = "Name of the vector index in OpenSearch Serverless"
  type        = string
  default     = "bedrock-kb-index"
}

########################################
# ✅ TWO-PASS DEPLOYMENT CONTROL
# Pass 1: aoss_vpc_endpoint_id = "" → KB skipped
# Pass 2: aoss_vpc_endpoint_id = "vpce-xxx" → KB created
########################################

variable "aoss_vpc_endpoint_id" {
  description = <<-EOT
    aoss VPC endpoint ID — controls two-pass deployment.
    Pass 1: leave as "" — KB, data source, KB association skipped.
    Pass 2: set to VPC endpoint ID — all resources created.
  EOT
  type        = string
  default     = ""
}

########################################
# EMBEDDING MODEL
# ✅ eu-north-1: Titan Embed v2 is ON_DEMAND
# No inference profile prefix needed.
# Supported dimensions: 256, 512, 1024
########################################

variable "embedding_model_id" {
  description = "Bedrock embedding model ID"
  type        = string
  default     = "amazon.titan-embed-text-v2:0"
}

variable "embedding_dimensions" {
  description = "Vector dimensions for titan-embed-text-v2:0 (256, 512, or 1024)"
  type        = number
  default     = 1024

  validation {
    condition     = contains([256, 512, 1024], var.embedding_dimensions)
    error_message = "embedding_dimensions must be 256, 512, or 1024 for amazon.titan-embed-text-v2:0."
  }
}

########################################
# AGENT FOUNDATION MODEL
# ✅ eu-north-1: Must use eu. cross-region
# inference profile — bare model IDs not
# supported for Agents in this region.
########################################

variable "agent_foundation_model" {
  description = "Cross-region inference profile for Bedrock Agent in eu-north-1"
  type        = string
  default     = "eu.anthropic.claude-sonnet-4-6-20250131-v1:0"
}

variable "agent_instruction" {
  description = "System instruction for the Bedrock Agent"
  type        = string
  default     = <<-EOT
    You are ARIES, an intelligent AI assistant for IT operations.
    You help resolve incidents, answer queries using the knowledge base,
    and assist with operational tasks. Always be concise, accurate, and helpful.
  EOT
}
