########################################
# 🤖 Bedrock Outputs
# ⚠️ KB resources use count — outputs
# return empty string on Pass 1
########################################

output "knowledge_base_id" {
  description = "Bedrock KB ID — empty on Pass 1, set on Pass 2"
  value       = var.aoss_vpc_endpoint_id != "" ? aws_bedrockagent_knowledge_base.this[0].id : ""
}

output "agent_id" {
  description = "Bedrock Agent ID"
  value       = aws_bedrockagent_agent.this.agent_id
}

output "agent_alias_id" {
  description = "Bedrock Agent Alias ID"
  value       = aws_bedrockagent_agent_alias.this.agent_alias_id
}

output "guardrail_id" {
  description = "Bedrock Guardrail ID"
  value       = aws_bedrock_guardrail.this.guardrail_id
}

output "guardrail_arn" {
  description = "Bedrock Guardrail ARN"
  value       = aws_bedrock_guardrail.this.guardrail_arn
}
