variable "project" {
  type = string
}

variable "environment" {
  type = string
}

variable "aws_region" {
  type = string
}

variable "private_subnet_ids" {
  type = list(string)
}

variable "backend_sg_id" {
  type = string
}

variable "frontend_sg_id" {
  type = string
}

variable "execution_role_arn" {
  type = string
}

variable "backend_task_role_arn" {
  type = string
}

variable "frontend_task_role_arn" {
  type = string
}

variable "backend_image" {
  type = string
}

variable "frontend_image" {
  type = string
}

variable "backend_target_group_arn" {
  type = string
}

variable "frontend_target_group_arn" {
  type = string
}

variable "rds_endpoint" {
  type = string
}

variable "opensearch_kb_endpoint" {
  type = string
}
variable "db_name" {
  type = string
}

variable "db_user" {
  type = string
}

variable "backend_secret_arn" {
  description = "Secrets Manager secret whose JSON keys are injected into the backend container"
  type        = string
}
variable "bedrock_agent_id" {
  description = "Bedrock Agent ID"
  type        = string
}

variable "bedrock_agent_alias_id" {
  description = "Bedrock Agent Alias ID"
  type        = string
}

variable "bedrock_knowledge_base_id" {
  description = "Bedrock Knowledge Base ID"
  type        = string
}