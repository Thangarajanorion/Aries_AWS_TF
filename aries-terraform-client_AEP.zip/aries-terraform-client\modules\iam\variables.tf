variable "project" {
  type = string
}

variable "environment" {
  type = string
}

variable "aws_account_id" {
  type = string
}

variable "aws_region" {
  type = string
}

variable "backend_secret_arn" {
  description = "Secrets Manager secret the ECS execution role may read for the backend"
  type        = string
}