variable "domain_name" {
  type = string
}

variable "cloudfront_domain" {
  type = string
}

variable "cloudfront_zone_id" {
  type    = string
  default = "Z2FDTNDATAQYW2" # CloudFront fixed zone id
}

variable "alb_dns" {
  type = string
}

variable "alb_zone_id" {
  type = string
}