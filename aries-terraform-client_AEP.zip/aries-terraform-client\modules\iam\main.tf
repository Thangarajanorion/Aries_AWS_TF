########################################
# 👷 ECS Execution Role
########################################
resource "aws_iam_role" "ecs_execution_role" {
  name = "${var.project}-${var.environment}-ecs-execution-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Service = "ecs-tasks.amazonaws.com"
      }
      Action = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "ecs_execution_policy" {
  role       = aws_iam_role.ecs_execution_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

# Lets ECS read the backend secret and inject it into the container.
resource "aws_iam_role_policy" "ecs_execution_secrets" {
  name = "read-backend-secrets"
  role = aws_iam_role.ecs_execution_role.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "secretsmanager:GetSecretValue"
      Resource = var.backend_secret_arn
    }]
  })
}

########################################
# 🚀 ECS Backend Task Role
########################################
resource "aws_iam_role" "ecs_backend_task_role" {
  name = "${var.project}-${var.environment}-ecs-backend-task-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Service = "ecs-tasks.amazonaws.com"
      }
      Action = "sts:AssumeRole"
    }]
  })
}

########################################
# 🎯 ECS Frontend Task Role
########################################
resource "aws_iam_role" "ecs_frontend_task_role" {
  name = "${var.project}-${var.environment}-ecs-frontend-task-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Service = "ecs-tasks.amazonaws.com"
      }
      Action = "sts:AssumeRole"
    }]
  })
}

########################################
# 🧠 Bedrock / Knowledge Base Role
########################################
resource "aws_iam_role" "bedrock_kb_role" {
  name = "${var.project}-${var.environment}-bedrock-kb-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Service = "bedrock.amazonaws.com"
      }
      Action = "sts:AssumeRole"
    }]
  })
}

########################################
# 📦 S3 Access Policy (shared)
########################################
resource "aws_iam_policy" "s3_access_policy" {
  name = "${var.project}-${var.environment}-s3-access-policy"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "s3:*"
      ]
      Resource = "*"
    }]
  })
}

########################################
# 🔗 Attach S3 policy to backend role
########################################
resource "aws_iam_role_policy_attachment" "backend_s3_attach" {
  role       = aws_iam_role.ecs_backend_task_role.name
  policy_arn = aws_iam_policy.s3_access_policy.arn
}

########################################
# 🔗 Attach S3 policy to frontend role
########################################
resource "aws_iam_role_policy_attachment" "frontend_s3_attach" {
  role       = aws_iam_role.ecs_frontend_task_role.name
  policy_arn = aws_iam_policy.s3_access_policy.arn
}

########################################
# 🔍 OpenSearch Access Policy (basic)
########################################
resource "aws_iam_policy" "opensearch_access_policy" {
  name = "${var.project}-${var.environment}-opensearch-policy"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "es:*"
      ]
      Resource = "*"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "backend_opensearch_attach" {
  role       = aws_iam_role.ecs_backend_task_role.name
  policy_arn = aws_iam_policy.opensearch_access_policy.arn
}
########################################
# ✅ OpenSearch Serverless Access Policy
# Added for serverless — aoss:APIAccessAll
# replaces es:* for serverless collections
########################################
resource "aws_iam_policy" "aoss_access_policy" {
  name = "${var.project}-${var.environment}-aoss-access-policy"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "aoss:APIAccessAll",
        "aoss:DashboardsAccessAll"
      ]
      Resource = "*"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "backend_aoss_attach" {
  role       = aws_iam_role.ecs_backend_task_role.name
  policy_arn = aws_iam_policy.aoss_access_policy.arn
}
