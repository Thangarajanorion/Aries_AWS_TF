########################################
# OSI on-demand scheduler
#
# Keeps OpenSearch Ingestion pipelines STOPPED, starts them on a schedule only
# when their S3 prefix has new objects, and stops them once the scan has been
# processed. See lambda/osi_scheduler.py for the logic.
########################################

data "aws_caller_identity" "current" {}
data "aws_region" "current" {}

locals {
  name         = "${var.project}-${var.environment}-osi-scheduler"
  state_prefix = "/${var.project}-${var.environment}/osi-scheduler"
  region       = data.aws_region.current.region
  account_id   = data.aws_caller_identity.current.account_id

  pipeline_arns = [for name in keys(var.pipelines) : "arn:aws:osis:${local.region}:${local.account_id}:pipeline/${name}"]
  bucket_names  = distinct([for p in values(var.pipelines) : p.bucket])
}

########################################
# Lambda
########################################

data "archive_file" "lambda" {
  type        = "zip"
  source_file = "${path.module}/lambda/osi_scheduler.py"
  output_path = "${path.module}/lambda/osi_scheduler.zip"
}

resource "aws_cloudwatch_log_group" "lambda" {
  name              = "/aws/lambda/${local.name}"
  retention_in_days = 30
}

resource "aws_lambda_function" "this" {
  function_name    = local.name
  role             = aws_iam_role.lambda.arn
  runtime          = "python3.12"
  handler          = "osi_scheduler.handler"
  filename         = data.archive_file.lambda.output_path
  source_code_hash = data.archive_file.lambda.output_base64sha256
  timeout          = 120
  memory_size      = 256

  # One invocation at a time so start and reconcile never race on the state.
  reserved_concurrent_executions = 1

  environment {
    variables = {
      PIPELINES = jsonencode([
        for name, p in var.pipelines : {
          name             = name
          sub_pipeline     = p.sub_pipeline
          bucket           = p.bucket
          prefixes         = p.prefixes
          exclude_suffixes = p.exclude_suffixes
        }
      ])
      STATE_PREFIX       = local.state_prefix
      MIN_ACTIVE_MINUTES = tostring(var.min_active_minutes)
      IDLE_MINUTES       = tostring(var.idle_minutes)
      BASE_RUN_MINUTES   = tostring(var.base_run_minutes)
      SECONDS_PER_OBJECT = tostring(var.seconds_per_object)
      MAX_RUN_MINUTES    = tostring(var.max_run_minutes)
    }
  }

  depends_on = [aws_cloudwatch_log_group.lambda, aws_iam_role_policy.lambda]
}

resource "aws_iam_role" "lambda" {
  name = "${local.name}-lambda"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy" "lambda" {
  name = "osi-scheduler"
  role = aws_iam_role.lambda.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = ["osis:GetPipeline", "osis:StartPipeline", "osis:StopPipeline"]
        Resource = local.pipeline_arns
      },
      {
        Effect   = "Allow"
        Action   = "s3:ListBucket"
        Resource = [for b in local.bucket_names : "arn:aws:s3:::${b}"]
      },
      {
        Effect   = "Allow"
        Action   = ["ssm:GetParameter", "ssm:PutParameter"]
        Resource = "arn:aws:ssm:${local.region}:${local.account_id}:parameter${local.state_prefix}/*"
      },
      {
        Effect   = "Allow"
        Action   = "cloudwatch:GetMetricData"
        Resource = "*"
      },
      {
        Effect   = "Allow"
        Action   = ["logs:CreateLogStream", "logs:PutLogEvents"]
        Resource = "${aws_cloudwatch_log_group.lambda.arn}:*"
      }
    ]
  })
}

########################################
# EventBridge Scheduler
########################################

resource "aws_iam_role" "scheduler" {
  name = "${local.name}-invoke"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "scheduler.amazonaws.com" }
      Action    = "sts:AssumeRole"
      Condition = { StringEquals = { "aws:SourceAccount" = local.account_id } }
    }]
  })
}

resource "aws_iam_role_policy" "scheduler" {
  name = "invoke-osi-scheduler"
  role = aws_iam_role.scheduler.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "lambda:InvokeFunction"
      Resource = aws_lambda_function.this.arn
    }]
  })
}

resource "aws_scheduler_schedule" "start" {
  name        = "${local.name}-start"
  description = "Start OSI pipelines that have new S3 objects"
  state       = var.enabled ? "ENABLED" : "DISABLED"

  schedule_expression          = var.start_schedule
  schedule_expression_timezone = var.schedule_timezone

  flexible_time_window {
    mode = "OFF"
  }

  target {
    arn      = aws_lambda_function.this.arn
    role_arn = aws_iam_role.scheduler.arn
    input    = jsonencode({ action = "start" })

    retry_policy {
      maximum_event_age_in_seconds = 3600
      maximum_retry_attempts       = 3
    }
  }
}

resource "aws_scheduler_schedule" "reconcile" {
  name        = "${local.name}-reconcile"
  description = "Stop running OSI pipelines once their scan is processed"
  state       = var.enabled ? "ENABLED" : "DISABLED"

  schedule_expression          = "rate(${var.reconcile_interval_minutes} minutes)"
  schedule_expression_timezone = var.schedule_timezone

  flexible_time_window {
    mode = "OFF"
  }

  target {
    arn      = aws_lambda_function.this.arn
    role_arn = aws_iam_role.scheduler.arn
    input    = jsonencode({ action = "reconcile" })

    # The next tick retries anyway.
    retry_policy {
      maximum_event_age_in_seconds = 60
      maximum_retry_attempts       = 0
    }
  }
}

########################################
# Alert on failures
########################################

resource "aws_cloudwatch_metric_alarm" "errors" {
  alarm_name          = "${local.name}-errors"
  alarm_description   = "OSI scheduler Lambda failed; pipelines may be left running or not started"
  namespace           = "AWS/Lambda"
  metric_name         = "Errors"
  dimensions          = { FunctionName = aws_lambda_function.this.function_name }
  statistic           = "Sum"
  period              = 900
  evaluation_periods  = 1
  threshold           = 0
  comparison_operator = "GreaterThanThreshold"
  treat_missing_data  = "notBreaching"
}
