"""
FILE: modules/retention/src/index.py

Deletes OpenSearch Serverless documents older than the
configured retention period.

WHY THIS APPROACH:
  - AOSS data lifecycle policies  -> TIME SERIES collections only
                                     (this collection is VECTORSEARCH)
  - _delete_by_query              -> not supported in AOSS
  - search + _bulk delete by _id  -> supported, so that is used here

IMPORTANT - DATE FIELD IS TEXT, NOT DATE:
  In aries-incidents-idx, ticket_creation_date is mapped as
  "text" with a ".keyword" subfield, not as a date type.
  OpenSearch cannot perform date math (now-90d) on it.

  The values are formatted "YYYY-MM-DD HH:MM:SS", which sorts
  correctly as a string, so the cutoff is computed here in
  Python and passed as a literal string to a range query
  against ticket_creation_date.keyword.

  This also works if the field is later remapped to a proper
  date type, so no code change is needed if that happens.

NO EXTERNAL DEPENDENCIES:
  Requests are signed with botocore, already present in the
  Lambda Python runtime. No Lambda layer required.
"""

import hashlib
import json
import os
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone

import boto3
import botocore.session
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest

REGION   = os.environ.get("AWS_REGION", "eu-north-1")
ENDPOINT = os.environ["AOSS_ENDPOINT"].replace("https://", "").rstrip("/")
INDEX    = os.environ["AOSS_INDEX"]

# Field actually queried. For a text field this must be the
# .keyword subfield. For a true date field, drop the suffix.
QUERY_FIELD = os.environ.get("QUERY_FIELD", "ticket_creation_date.keyword")

# Format the values are stored in
DATE_FORMAT = os.environ.get("DATE_FORMAT", "%Y-%m-%d %H:%M:%S")

RETENTION_DAYS = int(os.environ.get("RETENTION_DAYS", "90"))
DRY_RUN        = os.environ.get("DRY_RUN", "true").lower() == "true"
BATCH_SIZE     = int(os.environ.get("BATCH_SIZE", "500"))
MAX_BATCHES    = int(os.environ.get("MAX_BATCHES", "200"))

# Also delete the matching S3 object, so both stores are
# driven by the SAME parameter (ticket_creation_date) and
# cannot drift apart.
DELETE_S3 = os.environ.get("DELETE_S3", "true").lower() == "true"

SERVICE = "aoss"
_session = botocore.session.get_session()
_s3 = boto3.client("s3")


def _delete_s3_objects(keys_by_bucket):
    """
    Delete S3 objects in batches of 1000 (API limit).

    keys_by_bucket: {bucket_name: [key, key, ...]}
    Returns (deleted_count, error_count).
    """
    deleted = 0
    errors = 0
    for bucket, keys in keys_by_bucket.items():
        unique = sorted(set(k for k in keys if k))
        for i in range(0, len(unique), 1000):
            chunk = unique[i:i + 1000]
            try:
                resp = _s3.delete_objects(
                    Bucket=bucket,
                    Delete={
                        "Objects": [{"Key": k} for k in chunk],
                        "Quiet": True,
                    },
                )
                errs = resp.get("Errors", [])
                if errs:
                    errors += len(errs)
                    print("[retention] S3 errors in {}: {} first={}".format(
                        bucket, len(errs), errs[0]))
                deleted += len(chunk) - len(errs)
            except Exception as e:
                errors += len(chunk)
                print("[retention] S3 delete failed for {}: {}".format(bucket, e))
    return deleted, errors


def _signed_request(method, path, body=None, content_type="application/json"):
    """
    Send a SigV4-signed request to the collection.

    NOTE: AOSS requires X-Amz-Content-Sha256 to be present and
    included in the signed headers. Without it the service
    returns a bare 403 Forbidden that looks like a permissions
    error but is actually a signature mismatch.
    """
    url = "https://" + ENDPOINT + path
    data = body.encode("utf-8") if body else b""

    payload_hash = hashlib.sha256(data).hexdigest()

    headers = {
        "Content-Type": content_type,
        "X-Amz-Content-Sha256": payload_hash,
        "Host": ENDPOINT,
    }

    aws_req = AWSRequest(method=method, url=url, data=data, headers=headers)

    # Freeze credentials so the session token is captured
    creds = _session.get_credentials().get_frozen_credentials()
    SigV4Auth(creds, SERVICE, REGION).add_auth(aws_req)

    signed_headers = dict(aws_req.headers.items())

    req = urllib.request.Request(
        url,
        data=data if data else None,
        headers=signed_headers,
        method=method,
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(
            "{} {} failed with HTTP {}: {}".format(method, path, e.code, detail)
        ) from None


def _cutoff_string(retention_days):
    """
    Cutoff as a literal string.

    Works because the stored format "YYYY-MM-DD HH:MM:SS" is
    lexicographically ordered - string comparison gives the
    same result as date comparison.
    """
    cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
    return cutoff.strftime(DATE_FORMAT)


def _range_query(cutoff):
    return {"range": {QUERY_FIELD: {"lt": cutoff}}}


def lambda_handler(event, context):
    event = event if isinstance(event, dict) else {}
    dry_run   = event.get("dry_run", DRY_RUN)
    retention = int(event.get("retention_days", RETENTION_DAYS))

    cutoff = _cutoff_string(retention)

    print(
        "[retention] index={} field={} retention={}d cutoff='{}' dry_run={}".format(
            INDEX, QUERY_FIELD, retention, cutoff, dry_run
        )
    )

    query = _range_query(cutoff)

    # ---- Count eligible documents ----
    try:
        count_resp = _signed_request(
            "POST", "/{}/_count".format(INDEX), json.dumps({"query": query})
        )
        eligible = count_resp.get("count", 0)
    except RuntimeError as e:
        print("[retention] ERROR during count: {}".format(e))
        raise

    print("[retention] eligible documents: {}".format(eligible))

    if dry_run:
        # Show a sample so the match can be eyeballed before enabling
        try:
            sample = _signed_request(
                "POST",
                "/{}/_search".format(INDEX),
                json.dumps({
                    "size": 3,
                    "_source": ["ticket_number", "ticket_creation_date",
                                "s3.key", "s3.bucket", "title"],
                    "query": query,
                    "sort": [{QUERY_FIELD: "asc"}],
                }),
            )
            for h in sample.get("hits", {}).get("hits", []):
                src = h.get("_source", {})
                print(
                    "[retention]   would delete: ticket={} date={} s3key={}".format(
                        src.get("ticket_number"),
                        src.get("ticket_creation_date"),
                        src.get("s3", {}).get("key"),
                    )
                )
        except RuntimeError as e:
            print("[retention] sample query failed: {}".format(e))

        print(
            "[retention] DRY RUN - nothing deleted. "
            "Set dry_run = false in Terraform to enable deletion."
        )
        return {
            "eligible": eligible, "deleted": 0,
            "cutoff": cutoff, "dry_run": True,
        }

    if eligible == 0:
        return {
            "eligible": 0, "deleted": 0,
            "cutoff": cutoff, "dry_run": False,
        }

    # ---- Delete in batches ----
    # _source must include the S3 pointer so the matching
    # object can be removed in the same pass.
    search_body = json.dumps({
        "size": BATCH_SIZE,
        "_source": ["s3.bucket", "s3.key"],
        "query": query,
        "sort": [{QUERY_FIELD: "asc"}],
    })

    total_deleted = 0
    total_errors = 0
    s3_deleted = 0
    s3_errors = 0

    for batch in range(MAX_BATCHES):
        resp = _signed_request("POST", "/{}/_search".format(INDEX), search_body)
        hits = resp.get("hits", {}).get("hits", [])
        if not hits:
            break

        # Collect S3 pointers BEFORE deleting the documents,
        # otherwise the reference is lost.
        keys_by_bucket = {}
        for h in hits:
            s3info = (h.get("_source") or {}).get("s3") or {}
            bucket = s3info.get("bucket")
            key = s3info.get("key")
            if bucket and key:
                keys_by_bucket.setdefault(bucket, []).append(key)

        lines = [
            json.dumps({"delete": {"_index": INDEX, "_id": h["_id"]}})
            for h in hits
        ]
        result = _signed_request(
            "POST", "/_bulk", "\n".join(lines) + "\n",
            content_type="application/x-ndjson",
        )

        errors = [
            item["delete"]
            for item in result.get("items", [])
            if item.get("delete", {}).get("status", 200) >= 400
        ]
        if errors:
            total_errors += len(errors)
            print("[retention] batch {}: {} errors, first={}".format(
                batch, len(errors), errors[0]))

        total_deleted += len(hits) - len(errors)

        # Delete matching S3 objects for this batch
        if DELETE_S3 and keys_by_bucket:
            d, e = _delete_s3_objects(keys_by_bucket)
            s3_deleted += d
            s3_errors += e

        if len(hits) < BATCH_SIZE:
            break
    else:
        print(
            "[retention] hit MAX_BATCHES ({}); "
            "remaining documents handled on the next run".format(MAX_BATCHES)
        )

    print("[retention] complete docs_deleted={} doc_errors={} "
          "s3_deleted={} s3_errors={}".format(
              total_deleted, total_errors, s3_deleted, s3_errors))
    return {
        "eligible": eligible,
        "deleted": total_deleted,
        "errors": total_errors,
        "s3_deleted": s3_deleted,
        "s3_errors": s3_errors,
        "cutoff": cutoff,
        "dry_run": False,
    }
