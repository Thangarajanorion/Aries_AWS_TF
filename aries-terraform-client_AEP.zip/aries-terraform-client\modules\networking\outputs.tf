########################################
# 🌐 VPC
########################################
output "vpc_id" {
  value = aws_vpc.this.id
}

########################################
# 📡 Public Subnets
########################################
output "public_subnet_ids" {
  value = aws_subnet.public[*].id
}

########################################
# 🧩 Private App Subnets
########################################
output "private_app_subnet_ids" {
  value = aws_subnet.private_app[*].id
}

########################################
# 🗄️ Private Data Subnets
########################################
output "private_data_subnet_ids" {
  value = aws_subnet.private_data[*].id
}