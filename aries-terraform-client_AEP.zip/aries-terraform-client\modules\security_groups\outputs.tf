output "alb_sg_id" {
  value = aws_security_group.alb.id
}

output "ecs_backend_sg_id" {
  value = aws_security_group.ecs_backend.id
}

output "ecs_frontend_sg_id" {
  value = aws_security_group.ecs_frontend.id
}

output "rds_sg_id" {
  value = aws_security_group.rds.id
}

output "opensearch_sg_id" {
  value = aws_security_group.opensearch.id
}
output "aoss_vpce_sg_id" {
  value = aws_security_group.aoss_vpce.id
}
