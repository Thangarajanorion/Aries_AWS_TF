########################################
# 🧠 ECS Cluster
########################################
resource "aws_ecs_cluster" "this" {
  name = "${var.project}-${var.environment}-cluster"
}

########################################
# 📦 CloudWatch Log Groups
########################################
resource "aws_cloudwatch_log_group" "backend" {
  name              = "/ecs/${var.project}-${var.environment}-backend"
  retention_in_days = 7
}

resource "aws_cloudwatch_log_group" "frontend" {
  name              = "/ecs/${var.project}-${var.environment}-frontend"
  retention_in_days = 7
}

########################################
# 🔧 Locals
########################################
locals {
  # Keys of the backend Secrets Manager secret (var.backend_secret_arn).
  backend_secret_keys = [
    "WEBHOOK_PASSWORD",
    "WEBHOOK_TOKEN",
    "DB_URL",
    "DB_URL_ASYNC",
    "EASYVISTA_PASSWORD",
    "EASYVISTA_WEBHOOK_PASSWORD",
    "AZURE_HOST_CLIENT_SECRET",
    "AZURE_DATA_CLIENT_SECRET",
    "AZURE_STORAGE_ACCOUNT_KEY_OPS",
    "AZURE_STORAGE_ACCOUNT_KEY_KB",
    "ENCRYPTION_SECRET_KEY",
    "SERVICENOW_PASSWORD",
    "AZURE_SEARCH_KEY_OPS",
    "AZURE_OPENAI_API_KEY",
    "APPINSIGHTS_INSTRUMENTATION_KEY",
    "AZURE_DEVOPS_PAT",
    "DEVOPS_ENCRYPTION_KEY",
    "AWS_BILLING_ACCESS_KEY",
    "AWS_BILLING_SECRET_KEY",
    "AZURE_STORAGE_ACCOUNT_KEY_FINOPS",
    "DEPLOYMENT_STORAGE_ACCOUNT_KEY",
    "DEPLOYMENT_SEARCH_API_KEY",
    "ELASTIC_API_KEY",
    "COMET_DB_PASSWORD",
  ]
}

########################################
# 🚀 Backend Task Definition
########################################
resource "aws_ecs_task_definition" "backend" {
  family                   = "${var.project}-${var.environment}-backend"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 512
  memory                   = 1024
  execution_role_arn       = var.execution_role_arn
  task_role_arn            = var.backend_task_role_arn

  container_definitions = jsonencode([
    {
      name  = "backend"
      image = var.backend_image

      portMappings = [{
        containerPort = 8000    # ✅ backend app runs on 8000
        protocol      = "tcp"
      }]

      # Non-secret settings. Credentials come from Secrets Manager (see secrets below).
      environment = [
        { name = "WEBHOOK_USERNAME", value = "servicenow_background_user" },
        { name = "EASYVISTA_BASE_URL", value = "https://instance.easyvista.com" },
        { name = "EASYVISTA_ACCOUNT_ID", value = "50005" },
        { name = "EASYVISTA_USERNAME", value = "servicenow_background_user" },
        { name = "EASYVISTA_WEBHOOK_USERNAME", value = "servicenow_background_user" },
        { name = "BEDROCK_AGENT_ID", value = "${var.bedrock_agent_id}" },
        { name = "BEDROCK_AGENT_ALIAS_ID", value = "${var.bedrock_agent_alias_id}" },
        { name = "BEDROCK_KNOWLEDGE_BASE_ID", value = "${var.bedrock_knowledge_base_id}" },
        { name = "AZURE_AUTHORITY", value = "https://login.microsoftonline.com" },
        { name = "AZURE_SCOPE", value = "https://graph.microsoft.com/.default" },
        { name = "AZURE_AUD", value = "00d83faf-f4c5-4ae7-a8d9-ab95021bb824" },
        { name = "AZURE_HOST_TENANT_ID", value = "17c29566-c09c-42c8-bfc8-6a041ba809b2" },
        { name = "AZURE_HOST_CLIENT_ID", value = "00d83faf-f4c5-4ae7-a8d9-ab95021bb824" },
        { name = "AZURE_DATA_TENANT_ID", value = "adbbbd82-76e5-4952-8531-3cc59f3c1fdd" },
        { name = "AZURE_DATA_CLIENT_ID", value = "eeefd71e-60ef-49ca-a78e-0f4ff343d5d3" },
        { name = "AZURE_STORAGE_ACCOUNT_NAME_OPS", value = "storage4cometdashboard" },
        { name = "SERVICENOW_USERNAME", value = "aries.user" },
        { name = "AZURE_SEARCH_ENDPOINT_OPS", value = "https://ops-knowledge.search.windows.net" },
        { name = "AZURE_SEARCH_INDEX_NAME_OPS", value = "rag-1748433167477" },
        { name = "AZURE_SEARCH_INDEX_INCIDENTS", value = "rag-1755084774466" },
        { name = "AZURE_OPENAI_ENDPOINT", value = "https://aries-resource.services.ai.azure.com/api/projects/aries" },
        { name = "AZURE_OPENAI_API_VERSION", value = "2025-01-01-preview" },
        { name = "KEY_VAULT_URL", value = "" },
        { name = "ADMIN_GROUP", value = "5d63fec6-9a47-4751-bc29-fd0ede423b8c" },
        { name = "ENGINEER_GROUP", value = "b1469e1b-d3fb-4668-801e-39561dc6167f" },
        { name = "PRACTITIONER_GROUP", value = "53b5e8b6-a2ff-4a48-84d0-54dd0d0b2d54" },
        { name = "LOG_LEVEL", value = "DEBUG" },
        { name = "LOG_FORMATTER", value = "json" },
        { name = "SERVICENOW_BASE_URL", value = "https://oismartsupportdev.service-now.com" },
        { name = "ENVIRONMENT", value = "production" },
        { name = "REVISION", value = "102768" },
        { name = "LICENSE_PUBLIC_KEY", value = "" },
        { name = "AZURE_STORAGE_ACCOUNT_NAME", value = "storage4cometdashboard" },
        { name = "AZURE_DEVOPS_ORG", value = "OrionSystemsIntegratorsLLC" },
        { name = "AZURE_DEVOPS_PROJECT", value = "Comet" },
        { name = "AWS_BILLING_REGION", value = "us-east-1" },
        { name = "AZURE_STORAGE_ACCOUNT_NAME_FINOPS", value = "cometbillingexport" },
        { name = "FINOPS_RG", value = "oi-aries-maf-rg,cometcopilotazbe,aries_rg" },
        { name = "FINOPS_CONTAINER_NAME", value = "coifocuscostexport" },
        { name = "FINOPS_EXPORT_PREFIX", value = "costexport/coisanbox01-focus-cost" },
        { name = "FINOPS_CSV_FILENAME", value = "part_0_0001.csv" },
        { name = "ENVIRONMENT", value = "Developement" },
        { name = "AZURE_STORAGE_ACCOUNT_NAME_KB", value = "cometbillingexport" }
      ]

      # Each key of the backend secret is injected as an environment variable.
      secrets = [
        for key in local.backend_secret_keys : {
          name      = key
          valueFrom = "${var.backend_secret_arn}:${key}::"
        }
      ]

      logConfiguration = {
        logDriver = "awslogs"
        options = {
          awslogs-group         = aws_cloudwatch_log_group.backend.name
          awslogs-region        = var.aws_region
          awslogs-stream-prefix = "backend"
        }
      }
    }
  ])
}

########################################
# 🎨 Frontend Task Definition
########################################
resource "aws_ecs_task_definition" "frontend" {
  family                   = "${var.project}-${var.environment}-frontend"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 256
  memory                   = 512
  execution_role_arn       = var.execution_role_arn
  task_role_arn            = var.frontend_task_role_arn
  
  container_definitions = jsonencode([
    {
      name  = "frontend"
      image = var.frontend_image

      portMappings = [{
        containerPort = 80      # ✅ frontend nginx runs on 80
        protocol      = "tcp"
      }]
      environment = [
      {
        "name": "REACT_APP_BASE_URL",
        "value": "https://dae6v14zq0ncn.cloudfront.net"
      },
      {
        "name": "REACT_APP_CLIENT_ID",
        "value": "00d83faf-f4c5-4ae7-a8d9-ab95021bb824"
      },
      {
        "name": "REACT_APP_AUTHORITY",
        "value": "https://login.microsoftonline.com/17c29566-c09c-42c8-bfc8-6a041ba809b2/oauth2/v2.0/authorize"
      },
      {
        "name": "REACT_APP_REDIRECT_URI",
        "value": "https://dae6v14zq0ncn.cloudfront.net"
      },
      {
        "name": "GENERATE_SOURCEMAP",
        "value": "false"
      },
      {
        "name": "REVISION",
        "value": "102769"
      }
]
      logConfiguration = {
        logDriver = "awslogs"
        options = {
          awslogs-group         = aws_cloudwatch_log_group.frontend.name
          awslogs-region        = var.aws_region
          awslogs-stream-prefix = "frontend"
        }
      }
    }
  ])
}

########################################
# 🚀 Backend ECS Service
########################################
resource "aws_ecs_service" "backend" {
  name            = "${var.project}-${var.environment}-backend"
  cluster         = aws_ecs_cluster.this.id
  task_definition = aws_ecs_task_definition.backend.arn
  launch_type     = "FARGATE"
  desired_count   = 1
  health_check_grace_period_seconds = 180

  network_configuration {
    subnets          = var.private_subnet_ids
    security_groups  = [var.backend_sg_id]
    assign_public_ip = false
  }

  load_balancer {
    target_group_arn = var.backend_target_group_arn
    container_name   = "backend"
    container_port   = 8000    # ✅ matches task definition
  }
}

########################################
# 🎨 Frontend ECS Service
########################################
resource "aws_ecs_service" "frontend" {
  name            = "${var.project}-${var.environment}-frontend"
  cluster         = aws_ecs_cluster.this.id
  task_definition = aws_ecs_task_definition.frontend.arn
  launch_type     = "FARGATE"
  desired_count   = 1

  network_configuration {
    subnets          = var.private_subnet_ids
    security_groups  = [var.frontend_sg_id]
    assign_public_ip = false
  }

  load_balancer {
    target_group_arn = var.frontend_target_group_arn
    container_name   = "frontend"
    container_port   = 80      # ✅ matches task definition
  }
}
