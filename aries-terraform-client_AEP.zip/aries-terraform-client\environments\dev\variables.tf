########################################
# GLOBAL VARIABLES (ROOT MODULE)
########################################

variable "aws_region" {
  type = string
}

variable "project" {
  type = string
}

variable "environment" {
  type = string
}

variable "aws_account_id" {
  type = string
}

variable "entra_tenant_id" {
  type = string
}

variable "domain_name" {
  type = string
}

variable "sso_admin_group_name" {
  type = string
}

variable "sso_dev_group_name" {
  type = string
}

variable "sso_readonly_group_name" {
  type = string
}

########################################
# NETWORK VARIABLES
########################################

variable "vpc_cidr" {
  type = string
}

variable "availability_zones" {
  type = list(string)
}

variable "public_subnet_cidrs" {
  type = list(string)
}

variable "private_app_subnet_cidrs" {
  type = list(string)
}

variable "private_data_subnet_cidrs" {
  type = list(string)
}

########################################
# DATABASE VARIABLES
########################################

variable "db_name" {
  type = string
}

variable "db_user" {
  type = string
}

variable "db_instance_class" {
  type = string
}

variable "db_allocated_storage" {
  type = number
}

variable "db_multi_az" {
  type = bool
}

########################################
# ✅ OPENSEARCH SERVERLESS VARIABLES
# Removed: opensearch_instance_type, instance_count, volume_size
# Added: aoss_vpc_endpoint_id for two-pass deployment
########################################

variable "aoss_vpc_endpoint_id" {
  type        = string
  description = <<-EOT
    aoss VPC endpoint ID for the network policy.
    Leave empty ("") on first apply — the endpoint gets created.
    On second apply, set to: module.opensearch.aoss_vpc_endpoint_id
  EOT
  default     = ""
}

########################################
# IMAGE TAG VARIABLES
########################################

variable "image_tag_backend" {
  type    = string
  default = "latest"
}

variable "image_tag_frontend" {
  type    = string
  default = "latest"
}

########################################
# RETENTION VARIABLES (NEW)
#
# Controls 90 day deletion of incident data from both
# the S3 incidents bucket and OpenSearch.
#
# All flags default to OFF so applying changes nothing
# until deliberately enabled.
########################################

variable "incident_index_name" {
  type        = string
  description = "AOSS index holding incident documents. Created by the application at runtime, not by Terraform."
  default     = "aries-incidents-idx"
}

variable "incident_query_field" {
  type        = string
  description = "Field queried for document age. ticket_creation_date is mapped as TEXT so the .keyword subfield is required."
  default     = "ticket_creation_date.keyword"
}

variable "retention_days" {
  type        = number
  description = "Retention period in days, applied to both S3 and OpenSearch"
  default     = 90
}

variable "incident_retention_enabled" {
  type        = bool
  description = "Enable the S3 lifecycle rule on the incidents bucket. Keep false until security approval."
  default     = false
}

variable "retention_dry_run" {
  type        = bool
  description = "True means the Lambda reports eligible documents but deletes nothing. Keep true until verified."
  default     = true
}

variable "retention_schedule_enabled" {
  type        = bool
  description = "Whether the daily EventBridge cleanup schedule is active. Keep false until verified and approved."
  default     = false
}

variable "additional_access_principals" {
  type        = list(string)
  description = "TEMPORARY. Extra IAM ARNs granted read access to the OpenSearch collection. Reset to [] when finished."
  default     = []
}

variable "delete_s3_objects" {
  type        = bool
  description = "Whether the retention Lambda also deletes the matching S3 object. Keeps S3 and OpenSearch on the same parameter."
  default     = true
}

########################################
# AGENTCORE GATEWAY VARIABLES
########################################

variable "agentcore_gateway_authorizer_type" {
  description = "AWS_IAM (ECS task role signs requests) or CUSTOM_JWT (Microsoft Entra ID token)"
  type        = string
  default     = "AWS_IAM"
}

variable "agentcore_gateway_jwt_allowed_audiences" {
  description = "CUSTOM_JWT only: accepted 'aud' values of the Entra token"
  type        = list(string)
  default     = []
}

variable "agentcore_gateway_jwt_allowed_clients" {
  description = "CUSTOM_JWT only: accepted Entra client IDs"
  type        = list(string)
  default     = []
}

variable "agentcore_gateway_lambda_targets" {
  description = "Lambda tools exposed through the gateway (see modules/agentcore_gateway)"
  type = map(object({
    lambda_arn         = string
    tool_schema_s3_uri = string
    description        = optional(string)
  }))
  default = {}
}

variable "agentcore_gateway_openapi_targets" {
  description = "REST API tools exposed through the gateway (see modules/agentcore_gateway)"
  type = map(object({
    spec_s3_uri               = string
    api_key_secret_arn        = string
    api_key_secret_json_key   = optional(string)
    api_key_version           = optional(number, 1)
    credential_location       = optional(string, "HEADER")
    credential_parameter_name = optional(string, "x-api-key")
    credential_prefix         = optional(string)
    description               = optional(string)
  }))
  default = {}
}

variable "agentcore_gateway_mcp_server_targets" {
  description = "Existing MCP servers exposed through the gateway (see modules/agentcore_gateway)"
  type = map(object({
    endpoint           = string
    oauth_provider_arn = optional(string)
    oauth_scopes       = optional(list(string), [])
    description        = optional(string)
  }))
  default = {}
}

variable "agentcore_gateway_kms_key_arn" {
  description = "Customer managed KMS key for the gateway and its logs; null = AWS owned key"
  type        = string
  default     = null
}