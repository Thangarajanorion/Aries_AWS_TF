# ARIES – AWS Infrastructure (Terraform)

Terraform for the ARIES application on AWS: VPC, ALB, ECS Fargate (backend + frontend),
RDS PostgreSQL, OpenSearch Serverless, Bedrock (agent + knowledge base), CloudFront,
Secrets Manager, the OSI on-demand scheduler, the incident retention job, and the
Amazon Bedrock AgentCore Gateway with a first tool (incident lookup).

No WAF is included. Edge protection is expected from the client's own firewall
(on-premise or otherwise) in front of the CloudFront URL / ALB.

## Requirements

- Terraform >= 1.11, AWS provider ~> 6.0 (tested with 6.53)
- AWS CLI, credentials with admin rights on the target account
- Bedrock model access enabled in the region (Claude Sonnet inference profile)
- Amazon Bedrock AgentCore available in the region (it is in eu-north-1)
- For the gateway test: Python 3 with `botocore` (`pip install botocore`)

## Layout

```
environments/dev/   root module – run terraform from here
modules/            agentcore_gateway, alb, bedrock, cloudfront, cloudwatch, dns, ecr,
                    ecs, gateway_tools, iam, identity, networking, opensearch,
                    osi_scheduler, rds, retention, s3, secrets, security_groups
scripts/            test-gateway.py – smoke test for the AgentCore Gateway
```

## Deploy

1. Fill in the `<...>` placeholders in `environments/dev/terraform.tfvars`.
   Adjust CIDRs, region and AZs if needed. State is local by default; add a
   remote backend (S3) if the team shares it.

2. Pass 1 – base infrastructure:
   ```
   cd environments/dev
   terraform init
   terraform apply
   ```

3. Push the application images to the ECR repositories created in pass 1
   (`<project>-<environment>-api` and `<project>-<environment>-fe`) with the tags
   set in `terraform.tfvars`.

4. Load application credentials into Secrets Manager. Terraform creates the secret
   `<project>-<environment>-backend-secrets` but never stores values in code or tfvars.
   Put a JSON object with these keys (the list is `local.backend_secret_keys` in
   `modules/ecs/main.tf`):
   ```
   WEBHOOK_PASSWORD, WEBHOOK_TOKEN, DB_URL, DB_URL_ASYNC, EASYVISTA_PASSWORD,
   EASYVISTA_WEBHOOK_PASSWORD, AZURE_HOST_CLIENT_SECRET, AZURE_DATA_CLIENT_SECRET,
   AZURE_STORAGE_ACCOUNT_KEY_OPS, AZURE_STORAGE_ACCOUNT_KEY_KB, ENCRYPTION_SECRET_KEY,
   SERVICENOW_PASSWORD, AZURE_SEARCH_KEY_OPS, AZURE_OPENAI_API_KEY,
   APPINSIGHTS_INSTRUMENTATION_KEY, AZURE_DEVOPS_PAT, DEVOPS_ENCRYPTION_KEY,
   AWS_BILLING_ACCESS_KEY, AWS_BILLING_SECRET_KEY, AZURE_STORAGE_ACCOUNT_KEY_FINOPS,
   DEPLOYMENT_STORAGE_ACCOUNT_KEY, DEPLOYMENT_SEARCH_API_KEY, ELASTIC_API_KEY,
   COMET_DB_PASSWORD
   ```
   ```
   aws secretsmanager put-secret-value --secret-id <project>-<environment>-backend-secrets --secret-string file://backend-secrets.json
   ```
   `DB_URL` / `DB_URL_ASYNC` use the generated DB password from
   `<project>-<environment>-db-secret`. Do not add `sslmode` to `DB_URL_ASYNC`
   (asyncpg rejects it). Delete the local JSON file afterwards.
   Every key must be present or the backend task will not start.

5. Pass 2 – lock OpenSearch to the VPC:
   ```
   terraform output aoss_vpc_endpoint_id
   ```
   Set `aoss_vpc_endpoint_id` in `terraform.tfvars` to that value and run
   `terraform apply` again. This also creates the Bedrock knowledge base.

6. Create the OpenSearch indexes (the knowledge-base vector index and
   `aries-incidents-idx`) from inside the VPC, e.g. with awscurl against the
   `opensearch_endpoint` output. OpenSearch Serverless is VPC-only after pass 2.

7. Open the app at the CloudFront URL (`terraform output`), or point the
   client's DNS at it.

8. Test the AgentCore Gateway (see below).

## AgentCore Gateway

The ARIES API calls three Bedrock services separately, each through its own VPC
endpoint: the foundation model (guardrail applied in the same call), the Knowledge
Base, and the AgentCore Gateway. The gateway is the MCP endpoint through which the
agent calls tools; it does not forward requests to the model or the Knowledge Base.

What this code creates:

| Component | Module | Notes |
|---|---|---|
| AgentCore Gateway (MCP) | `agentcore_gateway` | inbound auth `AWS_IAM` (default) or Microsoft Entra ID (`CUSTOM_JWT`) |
| Gateway execution role | `agentcore_gateway` | may only invoke the listed Lambdas and read the listed tool definitions |
| `InvokeGateway` policy on the ARIES API task role | `agentcore_gateway` | added as a separate policy |
| Interface VPC endpoint `bedrock-agentcore.gateway` | `agentcore_gateway` | private DNS, port 443 from the ECS API security group only |
| Gateway application logs | `agentcore_gateway` | `/aws/vendedlogs/bedrock-agentcore/gateway/<name>` |
| Incident tools Lambda + tool definitions | `gateway_tools` | `get_incident`, `list_incidents`; read-only on `approved-incidents/` in the incidents bucket |

### Test it

After `terraform apply`, from `environments/dev`:

```
pip install botocore
python ../../scripts/test-gateway.py "$(terraform output -raw agentcore_gateway_url)"
```
(PowerShell: `python ..\..\scripts\test-gateway.py (terraform output -raw agentcore_gateway_url)`)

Expected output:

```
1. initialize          HTTP 200  server=<project>-<environment>-gateway
2. tools/list          HTTP 200  tools=['incident-tools___get_incident', 'incident-tools___list_incidents']
3. list_incidents      HTTP 200  {'count': N, 'incident_ids': [...]}
4. get_incident        HTTP 200  {'incidentId': ..., 'title': ..., 'state': ..., 'priority': ...}

RESULT: PASS
```

The tools read approved incidents from `s3://<project>-<environment>-incidents-bucket/approved-incidents/`
(`<INCIDENT_ID>.json` or `<INCIDENT_ID>_<date>_<title>.md`). On a new deployment the
folder is empty, so step 4 is skipped until an incident is uploaded. Pass an incident
number as the third argument to test a specific one:
`python ../../scripts/test-gateway.py <gateway_url> <region> INC0012345`.

### Connect the ARIES API

1. Set the `agentcore_gateway_url` output as `AGENTCORE_GATEWAY_URL` on the ARIES API
   task (through the CI/CD pipeline that registers task definitions).
2. The API needs an MCP client (for example the Strands Agents SDK) that calls the
   gateway with SigV4 signing (service `bedrock-agentcore`) using the task role. The
   classic Bedrock Agent (agent ID / alias) cannot call an AgentCore Gateway.

### Add more tools

Add entries to `agentcore_gateway_lambda_targets`, `agentcore_gateway_openapi_targets`
or `agentcore_gateway_mcp_server_targets` in `terraform.tfvars`; examples are in the
file and in `modules/agentcore_gateway/README.md`. API keys for REST tools are read
from Secrets Manager at apply time and never stored in code, tfvars or state.
Tools on-premises (e.g. ServiceNow) need a private endpoint on the gateway target so
the call goes through the VPC, Transit Gateway and Direct Connect.

## Not managed by this code

- OpenSearch Ingestion (OSI) pipelines and the OpenSearch indexes – created
  separately. The OSI scheduler in `environments/dev/main.tf` expects pipelines named
  `<project>-<environment>-incidents` and `<project>-<environment>-knowledge`.
- CI/CD (image build and ECS deploy).
- The ARIES API code change that connects to the gateway (see above).
- WAF / perimeter firewall.

## Optional components – safe defaults

- **OSI scheduler**: starts an OSI pipeline only when new files arrive in S3 and
  stops it when ingestion is complete, idle, or past its time budget.
- **Retention**: deletes incidents older than `retention_days` from OpenSearch and S3.
  Ships with `retention_dry_run = true` and `retention_schedule_enabled = false`,
  so nothing is deleted until those are changed. See the staged rollout in
  `terraform.tfvars`.
