########################################
# OpenSearch Serverless — Full Serverless
# Replaces provisioned aws_opensearch_domain
# Uses VECTORSEARCH collection type for Bedrock KB
#
# KEY CHANGES vs provisioned:
# 1. No aws_opensearch_domain — replaced with
#    aws_opensearchserverless_collection
# 2. No security group for domain — uses VPC endpoint
# 3. IAM uses aoss:APIAccessAll not es:*
# 4. Requires: encryption + network + data access policies
# 5. awscurl: --service aoss (not --service es)
# 6. No _cluster/settings, _ingest/pipeline support
# 7. Embedding handled by Bedrock KB (no ML plugin)
#
# NOTE: opensearch_index resource removed — index must
# be created manually from inside the VPC using awscurl.
# See outputs for the create_index_command to run.
########################################

########################################
# Encryption Policy (required first)
########################################
resource "aws_opensearchserverless_security_policy" "encryption" {
  name        = "${var.project}-${var.environment}-enc"
  type        = "encryption"
  description = "Encryption policy for ${var.project}-${var.environment} collection"

  policy = jsonencode({
    Rules = [{
      Resource     = ["collection/${var.project}-${var.environment}-kb"]
      ResourceType = "collection"
    }]
    AWSOwnedKey = true
  })
}

########################################
# Network Policy — VPC-only access
# Two-pass deployment:
# Pass 1: aoss_vpc_endpoint_id = "" → AllowFromPublic = true
# Pass 2: aoss_vpc_endpoint_id = "vpce-xxx" → AllowFromPublic = false
########################################
resource "aws_opensearchserverless_security_policy" "network" {
  name        = "${var.project}-${var.environment}-net"
  type        = "network"
  description = "Network policy for ${var.project}-${var.environment}"

  policy = var.aoss_vpc_endpoint_id == "" ? jsonencode([{
    Rules = [
      {
        Resource     = ["collection/${var.project}-${var.environment}-kb"]
        ResourceType = "collection"
      },
      {
        Resource     = ["collection/${var.project}-${var.environment}-kb"]
        ResourceType = "dashboard"
      }
    ]
    AllowFromPublic = true
    Description     = "Temporary public access — Pass 1 only"
  }]) : jsonencode([{
    Rules = [
      {
        Resource     = ["collection/${var.project}-${var.environment}-kb"]
        ResourceType = "collection"
      },
      {
        Resource     = ["collection/${var.project}-${var.environment}-kb"]
        ResourceType = "dashboard"
      }
    ]
    AllowFromPublic = false
    SourceVPCEs     = [var.aoss_vpc_endpoint_id]
    Description     = "VPC-only access via ${var.project}-${var.environment} aoss endpoint"
  }])

  depends_on = [aws_opensearchserverless_security_policy.encryption]
}

########################################
# Data Access Policy
# Controls who can read/write documents
# Must include: ECS task role, Bedrock KB role,
# and TFUser for admin
########################################
resource "aws_opensearchserverless_access_policy" "data" {
  name        = "${var.project}-${var.environment}-data"
  type        = "data"
  description = "Data access for ARIES ECS, Bedrock KB, OSIS"

  policy = jsonencode([{
    Rules = [
      {
        Resource = ["collection/${var.project}-${var.environment}-kb"]
        Permission = [
          "aoss:CreateCollectionItems",
          "aoss:DeleteCollectionItems",
          "aoss:UpdateCollectionItems",
          "aoss:DescribeCollectionItems"
        ]
        ResourceType = "collection"
      },
      {
        Resource = ["index/${var.project}-${var.environment}-kb/*"]
        Permission = [
          "aoss:CreateIndex",
          "aoss:DeleteIndex",
          "aoss:UpdateIndex",
          "aoss:DescribeIndex",
          "aoss:ReadDocument",
          "aoss:WriteDocument"
        ]
        ResourceType = "index"
      }
    ]
    Principal = [
      var.backend_task_role_arn,
      var.bedrock_kb_role_arn,
      "arn:aws:iam::${var.aws_account_id}:user/Aries-TFUser"
    ]
    Description = "ARIES component access"
  }])
}

########################################
# OpenSearch Serverless Collection
# VECTORSEARCH type required for Bedrock KB
########################################
resource "aws_opensearchserverless_collection" "kb" {
  name        = "${var.project}-${var.environment}-kb"
  type        = "VECTORSEARCH"
  description = "ARIES knowledge base vector search collection"

  depends_on = [
    aws_opensearchserverless_security_policy.encryption,
    aws_opensearchserverless_security_policy.network,
    aws_opensearchserverless_access_policy.data
  ]

  tags = {
    Project     = var.project
    Environment = var.environment
    Name        = "${var.project}-${var.environment}-kb"
  }
}

########################################
# aoss VPC Endpoint
# Allows private VPC access to the collection
# without going through the public internet
########################################
resource "aws_opensearchserverless_vpc_endpoint" "this" {
  name               = "${var.project}-${var.environment}-aoss-vpce"
  vpc_id             = var.vpc_id
  subnet_ids         = var.subnet_ids
  security_group_ids = [var.security_group_id]
}

########################################
# Outputs
########################################

output "opensearch_endpoint" {
  description = "OpenSearch Serverless collection endpoint — use as OPENSEARCH_ENDPOINT in ECS"
  value       = aws_opensearchserverless_collection.kb.collection_endpoint
}

output "opensearch_serverless_collection_arn" {
  description = "Collection ARN — used by Bedrock KB storage_configuration"
  value       = aws_opensearchserverless_collection.kb.arn
}

output "opensearch_serverless_collection_endpoint" {
  description = "Collection endpoint — used by opensearch provider"
  value       = aws_opensearchserverless_collection.kb.collection_endpoint
}

output "vector_index_name" {
  description = "Vector index name — passed to Bedrock KB field_mapping"
  value       = "${var.project}-${var.environment}-kb-idx"
}

output "aoss_vpc_endpoint_id" {
  description = "aoss VPC endpoint ID — copy to terraform.tfvars on Pass 2"
  value       = aws_opensearchserverless_vpc_endpoint.this.id
}

output "collection_name" {
  value = aws_opensearchserverless_collection.kb.name
}

########################################
# ⚠️ MANUAL STEP REQUIRED
# After terraform apply, run this command
# from inside the VPC (eu-north-1 Linux box)
# to create the vector index:
########################################
output "create_index_command" {
  description = "Run this command from ip-10-0-1-158 to create the vector index"
  value       = <<-CMD
    awscurl --service aoss --region ${var.aws_region} \
      -X PUT "${aws_opensearchserverless_collection.kb.collection_endpoint}/${var.project}-${var.environment}-kb-idx" \
      -H "Content-Type: application/json" \
      -d '{
        "settings": {
          "index": {
            "knn": true,
            "knn.algo_param.ef_search": 512,
            "number_of_shards": 2,
            "number_of_replicas": 0
          }
        },
        "mappings": {
          "properties": {
            "embedding": {
              "type": "knn_vector",
              "dimension": 1024,
              "method": {
                "name": "hnsw",
                "engine": "faiss",
                "space_type": "l2",
                "parameters": {}
              }
            },
            "text":     { "type": "text" },
            "metadata": { "type": "text" }
          }
        }
      }'
  CMD
}
