variable "project" {
  type = string
}

variable "environment" {
  type = string
}

variable "pipelines" {
  description = <<-EOT
    OSI pipelines to run on demand, keyed by pipeline name.
      sub_pipeline     - top-level key in the pipeline YAML (prefix of its CloudWatch metrics)
      bucket           - S3 bucket the pipeline's s3 source scans
      prefixes         - include_prefix values of the scan
      exclude_suffixes - exclude_suffix values of the scan
  EOT
  type = map(object({
    sub_pipeline     = string
    bucket           = string
    prefixes         = list(string)
    exclude_suffixes = optional(list(string), [])
  }))
}

variable "start_schedule" {
  description = "When to check for new objects and start pipelines that have work"
  type        = string
  default     = "cron(0 0,6,12,18 * * ? *)"
}

variable "schedule_timezone" {
  type    = string
  default = "UTC"
}

variable "reconcile_interval_minutes" {
  description = "How often running pipelines are checked and stopped once done"
  type        = number
  default     = 5
}

variable "min_active_minutes" {
  description = "Minimum time a pipeline stays ACTIVE before it can be stopped (must exceed the s3 scan interval)"
  type        = number
  default     = 7
}

variable "idle_minutes" {
  description = "Stop when the buffer is empty and no object has been read for this long"
  type        = number
  default     = 12
}

variable "base_run_minutes" {
  description = "Run budget before per-object time is added"
  type        = number
  default     = 15
}

variable "seconds_per_object" {
  description = "Run budget added per object in the scanned prefixes"
  type        = number
  default     = 3
}

variable "max_run_minutes" {
  description = "Upper limit on the run budget"
  type        = number
  default     = 120
}

variable "enabled" {
  description = "Set to false to pause both schedules (pipelines are left as they are)"
  type        = bool
  default     = true
}
