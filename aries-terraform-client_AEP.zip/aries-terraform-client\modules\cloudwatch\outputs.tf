output "ecs_backend_log_group" {
  value = "/ecs/${var.project}-${var.environment}-backend"
}

output "ecs_frontend_log_group" {
  value = "/ecs/${var.project}-${var.environment}-frontend"
}

output "alb_log_group" {
  value = aws_cloudwatch_log_group.alb.name
}