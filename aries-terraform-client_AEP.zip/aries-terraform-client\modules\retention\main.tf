########################################
# OpenSearch Serverless Retention Cleanup
# FILE: modules/retention/main.tf
#
# WHY A LAMBDA IS REQUIRED:
# 1. AOSS data lifecycle policies support only
# TIME SERIES collections. Ours is VECTORSEARCH.
# 2. _delete_by_query is NOT supported in AOSS.
# 3. Only search + bulk delete by _id are available.
#
# DESIGN NOTES:
# - Uses its OWN data access policy so there is no
# circular dependency with the opensearch module.
# - Uses its OWN security group plus an ingress rule
# on the aoss endpoint SG (which otherwise only
# permits the ECS backend).
# - Uses botocore SigV4 (built into the Lambda
# runtime) so NO Lambda layer is required.
########################################
# Security Group for the Lambda
########################################

resource "aws_security_group" "retention_lambda" {
  name        = "${var.project}-${var.environment}-retention-lambda-sg"
  description = "Retention Lambda outbound to aoss VPC endpoint"
  vpc_id      = var.vpc_id

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
    description = "Allow outbound to aoss endpoint and AWS APIs"
  }

  tags = {
    Name        = "${var.project}-${var.environment}-retention-lambda-sg"
    Project     = var.project
    Environment = var.environment
  }
}

# The aoss endpoint SG only allows the ECS backend.
# This adds the Lambda without editing the
# security_groups module.
resource "aws_vpc_security_group_ingress_rule" "aoss_from_retention" {
  security_group_id            = var.opensearch_security_group_id
  referenced_security_group_id = aws_security_group.retention_lambda.id
  from_port                    = 443
  to_port                      = 443
  ip_protocol                  = "tcp"
  description                  = "Allow retention Lambda to reach aoss endpoint"
}

########################################
# IAM Role
########################################

resource "aws_iam_role" "retention_lambda" {
  name = "${var.project}-${var.environment}-retention-lambda-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = {
    Project     = var.project
    Environment = var.environment
  }
}

resource "aws_iam_role_policy_attachment" "retention_basic" {
  role       = aws_iam_role.retention_lambda.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

# Required so the Lambda can attach ENIs in the VPC
resource "aws_iam_role_policy_attachment" "retention_vpc" {
  role       = aws_iam_role.retention_lambda.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole"
}

# S3 delete permission, scoped to the incidents bucket only.
# Required so the same job removes the matching S3 object,
# keeping both stores driven by ticket_creation_date.
resource "aws_iam_role_policy" "retention_s3" {
  # Keyed on a plain bool: the bucket ARN is unknown until the bucket exists.
  count = var.delete_s3_objects ? 1 : 0

  name = "${var.project}-${var.environment}-retention-s3"
  role = aws_iam_role.retention_lambda.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "s3:DeleteObject",
          "s3:DeleteObjectVersion"
        ]
        Resource = "${var.incidents_bucket_arn}/*"
      },
      {
        Effect   = "Allow"
        Action   = ["s3:ListBucket"]
        Resource = var.incidents_bucket_arn
      }
    ]
  })
}

resource "aws_iam_role_policy" "retention_aoss" {
  name = "${var.project}-${var.environment}-retention-aoss"
  role = aws_iam_role.retention_lambda.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["aoss:APIAccessAll"]
      Resource = var.opensearch_collection_arn
    }]
  })
}

########################################
# Data Access Policy (own policy - avoids
# circular dependency with opensearch module)
#
# AOSS permits multiple data access policies on a
# single collection; they are additive.
########################################

resource "aws_opensearchserverless_access_policy" "retention" {
  name        = "${var.project}-${var.environment}-retention"
  type        = "data"
  description = "Retention Lambda read and delete documents"

  policy = jsonencode([{
    Rules = [
      {
        ResourceType = "collection"
        Resource     = ["collection/${var.opensearch_collection_name}"]
        Permission   = ["aoss:DescribeCollectionItems"]
      },
      {
        ResourceType = "index"
        Resource     = ["index/${var.opensearch_collection_name}/*"]
        Permission = [
          "aoss:DescribeIndex",
          "aoss:ReadDocument",
          "aoss:WriteDocument"
        ]
      }
    ]
    Principal = concat(
      [aws_iam_role.retention_lambda.arn],
      var.additional_access_principals
    )
    Description = "Retention cleanup access"
  }])
}

########################################
# Lambda Package
########################################

data "archive_file" "retention" {
  type        = "zip"
  source_dir  = "${path.module}/src"
  output_path = "${path.module}/build/retention_lambda.zip"
}

resource "aws_lambda_function" "retention" {
  function_name = "${var.project}-${var.environment}-aoss-retention"
  description   = "Deletes OpenSearch documents older than the retention period"
  role          = aws_iam_role.retention_lambda.arn
  handler       = "index.lambda_handler"
  runtime       = "python3.12"
  timeout       = 900
  memory_size   = 512

  filename         = data.archive_file.retention.output_path
  source_code_hash = data.archive_file.retention.output_base64sha256

  # Collection is VPC-only, so the Lambda must be in the VPC
  vpc_config {
    subnet_ids         = var.subnet_ids
    security_group_ids = [aws_security_group.retention_lambda.id]
  }

  environment {
    variables = {
      AOSS_ENDPOINT  = replace(var.opensearch_endpoint, "https://", "")
      AOSS_INDEX     = var.incident_index_name
      RETENTION_DAYS = tostring(var.retention_days)
      DRY_RUN        = var.dry_run ? "true" : "false"
      BATCH_SIZE     = tostring(var.batch_size)

      # ticket_creation_date is mapped as TEXT, not date, so the
      # .keyword subfield is queried with a literal cutoff string.
      QUERY_FIELD = var.query_field
      DATE_FORMAT = var.date_format

      # Delete the matching S3 object in the same pass
      DELETE_S3 = var.delete_s3_objects ? "true" : "false"
    }
  }

  depends_on = [
    aws_iam_role_policy.retention_aoss,
    aws_opensearchserverless_access_policy.retention,
    aws_cloudwatch_log_group.retention
  ]

  tags = {
    Project     = var.project
    Environment = var.environment
  }
}

########################################
# Log Group
########################################

resource "aws_cloudwatch_log_group" "retention" {
  name              = "/aws/lambda/${var.project}-${var.environment}-aoss-retention"
  retention_in_days = 30

  tags = {
    Project     = var.project
    Environment = var.environment
  }
}

########################################
# Daily Schedule
########################################

resource "aws_cloudwatch_event_rule" "retention_daily" {
  name                = "${var.project}-${var.environment}-retention-daily"
  description         = "Daily OpenSearch retention cleanup"
  schedule_expression = var.schedule_expression
  state               = var.schedule_enabled ? "ENABLED" : "DISABLED"
}

resource "aws_cloudwatch_event_target" "retention" {
  rule      = aws_cloudwatch_event_rule.retention_daily.name
  target_id = "retention-lambda"
  arn       = aws_lambda_function.retention.arn
}

resource "aws_lambda_permission" "allow_events" {
  statement_id  = "AllowExecutionFromEventBridge"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.retention.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.retention_daily.arn
}

########################################
# Alarm on failures
########################################

resource "aws_cloudwatch_metric_alarm" "retention_errors" {
  count = var.alarm_sns_topic_arn == "" ? 0 : 1

  alarm_name          = "${var.project}-${var.environment}-retention-errors"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 1
  metric_name         = "Errors"
  namespace           = "AWS/Lambda"
  period              = 86400
  statistic           = "Sum"
  threshold           = 0
  alarm_description   = "Retention Lambda failed"
  treat_missing_data  = "notBreaching"

  dimensions = {
    FunctionName = aws_lambda_function.retention.function_name
  }

  alarm_actions = [var.alarm_sns_topic_arn]
}
