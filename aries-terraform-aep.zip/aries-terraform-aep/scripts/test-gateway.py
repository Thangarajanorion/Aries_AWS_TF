"""Smoke test for the ARIES AgentCore Gateway.

Sends signed (SigV4) MCP requests the same way the ARIES API does:
initialize, tools/list, then the two incident tools.

Usage (from environments/dev after terraform apply):
    pip install botocore
    python ../../scripts/test-gateway.py "$(terraform output -raw agentcore_gateway_url)" [region] [incident_id]

The AWS credentials in your environment must allow bedrock-agentcore:InvokeGateway
on the gateway (an administrator role does).
"""
import json
import sys
import urllib.error
import urllib.request

import botocore.session
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest

if len(sys.argv) < 2:
    sys.exit(__doc__)

URL = sys.argv[1]
REGION = sys.argv[2] if len(sys.argv) > 2 else URL.split(".gateway.bedrock-agentcore.")[1].split(".")[0]
INCIDENT = sys.argv[3] if len(sys.argv) > 3 else None

creds = botocore.session.get_session().get_credentials()
if creds is None:
    sys.exit("No AWS credentials found. Configure the AWS CLI or set AWS_PROFILE.")


def call(method, params, rid):
    body = json.dumps({"jsonrpc": "2.0", "id": rid, "method": method, "params": params})
    req = AWSRequest(method="POST", url=URL, data=body,
                     headers={"Content-Type": "application/json", "Accept": "application/json, text/event-stream"})
    SigV4Auth(creds, "bedrock-agentcore", REGION).add_auth(req)
    r = urllib.request.Request(URL, data=body.encode(), headers=dict(req.headers), method="POST")
    try:
        with urllib.request.urlopen(r, timeout=30) as resp:
            return resp.status, json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()


def tool_text(result):
    content = result.get("result", {}).get("content", [{}])
    return json.loads(content[0].get("text", "{}"))


ok = True

status, res = call("initialize", {"protocolVersion": "2025-03-26", "capabilities": {},
                                  "clientInfo": {"name": "aries-smoke-test", "version": "1"}}, 1)
print(f"1. initialize          HTTP {status}  server={res.get('result', {}).get('serverInfo', {}).get('name') if status == 200 else res}")
ok &= status == 200

status, res = call("tools/list", {}, 2)
tools = [t["name"] for t in res.get("result", {}).get("tools", [])] if status == 200 else []
print(f"2. tools/list          HTTP {status}  tools={tools or res}")
ok &= status == 200 and any(t.endswith("___get_incident") for t in tools)

status, res = call("tools/call", {"name": "incident-tools___list_incidents", "arguments": {"limit": 5}}, 3)
listed = tool_text(res) if status == 200 else res
print(f"3. list_incidents      HTTP {status}  {listed}")
ok &= status == 200

incident = INCIDENT or (listed.get("incident_ids") or [None])[0] if isinstance(listed, dict) else INCIDENT
if incident:
    status, res = call("tools/call", {"name": "incident-tools___get_incident", "arguments": {"incident_id": incident}}, 4)
    got = tool_text(res) if status == 200 else res
    if isinstance(got, dict) and "content" in got:  # incident stored as Markdown
        summary = {"incidentId": got.get("incidentId"), "content": got["content"][:80].replace("\n", " ") + "..."}
    elif isinstance(got, dict) and "error" not in got:
        summary = {k: got.get(k) for k in ("incidentId", "title", "state", "priority")}
    else:
        summary = got
    print(f"4. get_incident        HTTP {status}  {summary}")
    ok &= status == 200 and isinstance(got, dict) and "error" not in got
else:
    print("4. get_incident        skipped: no incidents in approved-incidents/ yet (upload one to test)")

print("\nRESULT:", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
