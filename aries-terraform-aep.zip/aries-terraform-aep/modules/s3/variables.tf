########################################
# Existing variables
########################################
variable "project" {
  type = string
}

variable "environment" {
  type = string
}

variable "aws_account_id" {
  type = string
}

variable "kb_role_arn" {
  type    = string
  default = ""
}

########################################
# Incidents Bucket Retention
########################################
variable "incident_retention_enabled" {
  type        = bool
  description = "Enable the 90 day lifecycle rule on the incidents bucket. Set false to disable without removing the code."
  default     = true
}

variable "incident_retention_days" {
  type        = number
  description = "Days to retain incident objects before deletion. Applies to current and noncurrent versions."
  default     = 90

  validation {
    condition     = var.incident_retention_days >= 1
    error_message = "incident_retention_days must be at least 1."
  }
}

variable "incident_retention_prefix" {
  type        = string
  description = "Prefix within the incidents bucket to apply retention to. Empty string applies to the whole bucket."
  default     = ""
}

########################################
# Knowledge Bucket Retention
# Disabled by default - knowledge base content is
# reference material, not time-series data.
########################################
variable "knowledge_retention_enabled" {
  type        = bool
  description = "Enable a lifecycle rule on the knowledge bucket. Normally false."
  default     = false
}

variable "knowledge_retention_days" {
  type        = number
  description = "Days to retain knowledge objects, if retention is enabled."
  default     = 365
}

variable "knowledge_retention_prefix" {
  type        = string
  description = "Prefix within the knowledge bucket to apply retention to."
  default     = ""
}

variable "name_prefix" {
  description = "Prefix for resource names, e.g. aep-demo-aries"
  type        = string
}
