########################################
# Knowledge Bucket Outputs
########################################
output "knowledge_bucket_name" {
  value = aws_s3_bucket.knowledge.bucket
}

output "knowledge_bucket_arn" {
  value = aws_s3_bucket.knowledge.arn
}

########################################
# Incidents Bucket Outputs
########################################
output "incidents_bucket_name" {
  value = aws_s3_bucket.incidents.bucket
}

output "incidents_bucket_arn" {
  value = aws_s3_bucket.incidents.arn
}

########################################
# Retention Outputs
# Useful for confirming what was applied and for
# reporting the configuration back to the client.
########################################
output "incident_retention_enabled" {
  description = "Whether the incidents bucket lifecycle rule is active"
  value       = var.incident_retention_enabled
}

output "incident_retention_days" {
  description = "Retention period applied to the incidents bucket"
  value       = var.incident_retention_days
}

output "incident_retention_summary" {
  description = "Human readable summary of the incidents retention configuration"
  value = var.incident_retention_enabled ? format(
    "Incidents bucket '%s': objects expire after %d days (current and noncurrent versions)%s",
    aws_s3_bucket.incidents.bucket,
    var.incident_retention_days,
    var.incident_retention_prefix == "" ? " across the whole bucket" : format(" under prefix '%s'", var.incident_retention_prefix)
  ) : "Incidents retention is DISABLED"
}

output "knowledge_retention_enabled" {
  description = "Whether the knowledge bucket lifecycle rule is active"
  value       = var.knowledge_retention_enabled
}
