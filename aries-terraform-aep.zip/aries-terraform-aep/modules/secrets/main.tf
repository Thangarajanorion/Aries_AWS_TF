########################################
# 🔐 Database Secret
########################################
# The Aurora master password is created and stored in Secrets Manager by RDS
# itself (manage_master_user_password, see modules/aurora).

########################################
# 🔐 OpenSearch Secret
########################################

resource "random_password" "opensearch" {
  length           = 32
  special          = true
  override_special = "!#$%^*()-_=+[]{}<>?"
}

resource "aws_secretsmanager_secret" "opensearch" {
  name                    = "${var.name_prefix}-opensearch-secret"
  recovery_window_in_days = 0 # ← ADD THIS
}

resource "aws_secretsmanager_secret_version" "opensearch" {
  secret_id = aws_secretsmanager_secret.opensearch.id

  secret_string = jsonencode({
    username = "master-user"
    password = random_password.opensearch.result
  })

  lifecycle {
    ignore_changes = [secret_string]
  }
}

########################################
# 🔐 OIDC Secret
########################################

resource "aws_secretsmanager_secret" "oidc" {
  name                    = "${var.name_prefix}-oidc-secret"
  recovery_window_in_days = 0 # ← ADD THIS
}

resource "aws_secretsmanager_secret_version" "oidc" {
  secret_id = aws_secretsmanager_secret.oidc.id

  secret_string = jsonencode({
    client_id     = var.oidc_client_id
    client_secret = var.oidc_client_secret
  })
}

########################################
# 🔐 Backend Application Secret
########################################
# One JSON secret holding every credential the backend container needs; ECS
# injects each key as an environment variable (see modules/ecs).
# Terraform creates the secret only. Values are set outside Terraform so they
# never appear in code or state:
#   aws secretsmanager put-secret-value --secret-id <name> --secret-string file://backend-secrets.json

resource "aws_secretsmanager_secret" "backend" {
  name                    = "${var.name_prefix}-backend-secrets"
  description             = "Credentials for the ${var.name_prefix} backend ECS service"
  recovery_window_in_days = 7
}
