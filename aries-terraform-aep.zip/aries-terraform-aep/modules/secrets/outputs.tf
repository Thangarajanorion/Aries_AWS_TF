output "opensearch_secret_arn" {
  value = aws_secretsmanager_secret.opensearch.arn
}

output "oidc_secret_arn" {
  value = aws_secretsmanager_secret.oidc.arn
}

output "backend_secret_arn" {
  value = aws_secretsmanager_secret.backend.arn
}