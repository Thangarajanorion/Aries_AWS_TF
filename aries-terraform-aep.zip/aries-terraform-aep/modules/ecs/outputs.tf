########################################
# 🧠 ECS Cluster
########################################
output "cluster_id" {
  value = aws_ecs_cluster.this.id
}

########################################
# 🚀 Services
########################################
output "backend_service_name" {
  value = aws_ecs_service.backend.name
}

output "frontend_service_name" {
  value = aws_ecs_service.frontend.name
}