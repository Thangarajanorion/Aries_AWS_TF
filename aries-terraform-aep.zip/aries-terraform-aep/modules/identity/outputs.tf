########################################
# 🔑 Identity Outputs
########################################
output "oidc_client_id" {
  value = "dummy-client-id"
}

output "oidc_client_secret" {
  value = "dummy-client-secret"
}

output "identity_role_arn" {
  value = aws_iam_role.identity_role.arn
}