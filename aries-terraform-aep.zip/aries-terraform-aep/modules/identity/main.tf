########################################
# 🔐 IAM OIDC Provider (placeholder)
# (used for future Entra / OIDC integration)
########################################
resource "aws_iam_openid_connect_provider" "this" {
  url = "https://oidc.eks.${var.aws_region}.amazonaws.com/id/example"

  client_id_list = [
    "sts.amazonaws.com"
  ]

  thumbprint_list = ["6938fd4d98bab03faadb97b34396831e3780aea1"]
}

########################################
# 👤 Example IAM Role for Identity Layer
########################################
resource "aws_iam_role" "identity_role" {
  name = "${var.name_prefix}-identity-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Service = "ec2.amazonaws.com"
      }
      Action = "sts:AssumeRole"
    }]
  })
}

########################################
# 🔑 Dummy outputs for SSO placeholders
########################################
locals {
  oidc_client_id     = "dummy-client-id"
  oidc_client_secret = "dummy-client-secret"
}