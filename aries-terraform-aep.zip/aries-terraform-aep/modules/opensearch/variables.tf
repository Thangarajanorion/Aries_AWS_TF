########################################
# OpenSearch Serverless Variables
# Removed: instance_type, instance_count, volume_size
# Added:   aoss_vpc_endpoint_id
########################################

variable "project" {
  type = string
}

variable "environment" {
  type = string
}

variable "aws_account_id" {
  type = string
}

variable "aws_region" {
  type = string
}

variable "vpc_id" {
  type        = string
  description = "VPC ID for aoss VPC endpoint"
}

variable "subnet_ids" {
  type        = list(string)
  description = "Subnet IDs for aoss VPC endpoint"
}

variable "security_group_id" {
  type        = string
  description = "Security group for aoss VPC endpoint"
}

variable "admin_principal_arns" {
  type        = list(string)
  description = "IAM roles/users with full access to the collection (index creation and admin)"
  default     = []
}

variable "backend_task_role_arn" {
  type        = string
  description = "ECS backend task role ARN — added to data access policy"
}

variable "bedrock_kb_role_arn" {
  type        = string
  description = "Bedrock KB role ARN — added to data access policy"
}

variable "name_prefix" {
  description = "Prefix for resource names, e.g. aep-demo-aries"
  type        = string
}
