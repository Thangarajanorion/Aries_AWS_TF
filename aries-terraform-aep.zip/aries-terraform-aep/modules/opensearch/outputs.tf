# All outputs moved to main.tf to keep them
# alongside the resources they reference.
# This file intentionally left minimal.
