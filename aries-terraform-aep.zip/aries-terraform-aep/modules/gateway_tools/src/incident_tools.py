"""ARIES incident tools, called by the AgentCore Gateway.

The gateway passes the tool arguments as the event and the tool name as
"<target>___<tool>" in context.client_context.custom["bedrockAgentCoreToolName"].
"""
import json
import os
import re

import boto3

s3 = boto3.client("s3")

BUCKET = os.environ["INCIDENTS_BUCKET"]
PREFIX = os.environ.get("INCIDENTS_PREFIX", "approved-incidents/")

# Returned to the agent. Caller and assignee names are left out on purpose.
FIELDS = [
    "incidentId", "title", "state", "priority", "urgency", "impact",
    "category", "subcategory", "assignment_group", "opened_at",
    "resolved_at", "description", "resolution",
]
ID_PATTERN = re.compile(r"^[A-Za-z]{2,4}\d{4,10}$")
MAX_TEXT = 4000


def handler(event, context):
    tool = ""
    try:
        tool = context.client_context.custom["bedrockAgentCoreToolName"]
    except (AttributeError, KeyError, TypeError):
        pass
    tool = tool.split("___")[-1]

    if tool == "get_incident":
        return get_incident(str(event.get("incident_id", "")).strip())
    if tool == "list_incidents":
        return list_incidents(event.get("limit", 20))
    return {"error": f"Unknown tool: {tool or '(none)'}"}


def _keys(prefix):
    for page in s3.get_paginator("list_objects_v2").paginate(Bucket=BUCKET, Prefix=prefix):
        for obj in page.get("Contents", []):
            if not obj["Key"].endswith("/"):
                yield obj["Key"]


def _incident_id(key):
    name = key[len(PREFIX):].rsplit(".", 1)[0]
    return name.split("_", 1)[0]


def get_incident(incident_id):
    if not ID_PATTERN.match(incident_id):
        return {"error": "incident_id must look like INC0078085."}

    keys = [k for k in _keys(PREFIX + incident_id) if _incident_id(k).upper() == incident_id.upper()]
    if not keys:
        return {"error": f"Incident {incident_id} was not found among the approved incidents."}

    key = sorted(keys, key=lambda k: not k.endswith(".json"))[0]
    body = s3.get_object(Bucket=BUCKET, Key=key)["Body"].read().decode("utf-8", errors="replace")

    if key.endswith(".json"):
        data = json.loads(body)
        result = {f: data.get(f) for f in FIELDS if data.get(f) not in (None, "")}
        for f in ("description", "resolution"):
            if isinstance(result.get(f), str):
                result[f] = result[f][:MAX_TEXT]
        return result
    return {"incidentId": incident_id, "content": body[:MAX_TEXT]}


def list_incidents(limit):
    try:
        limit = max(1, min(int(limit), 100))
    except (TypeError, ValueError):
        limit = 20
    ids = sorted({_incident_id(k) for k in _keys(PREFIX)})
    return {"count": len(ids), "incident_ids": ids[:limit]}
