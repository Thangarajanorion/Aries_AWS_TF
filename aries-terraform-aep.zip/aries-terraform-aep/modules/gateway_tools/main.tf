locals {
  name = "${var.name_prefix}-incident-tools"
}

########################################
# Lambda: incident tools for the AgentCore Gateway
########################################
data "archive_file" "lambda" {
  type        = "zip"
  source_file = "${path.module}/src/incident_tools.py"
  output_path = "${path.module}/build/incident_tools.zip"
}

resource "aws_iam_role" "lambda" {
  name = "${local.name}-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = { Environment = var.environment }
}

resource "aws_iam_role_policy" "lambda" {
  name = "read-approved-incidents"
  role = aws_iam_role.lambda.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect    = "Allow"
        Action    = "s3:ListBucket"
        Resource  = var.incidents_bucket_arn
        Condition = { StringLike = { "s3:prefix" = ["${var.incidents_prefix}*"] } }
      },
      {
        Effect   = "Allow"
        Action   = "s3:GetObject"
        Resource = "${var.incidents_bucket_arn}/${var.incidents_prefix}*"
      },
      {
        Effect   = "Allow"
        Action   = ["logs:CreateLogStream", "logs:PutLogEvents"]
        Resource = "${aws_cloudwatch_log_group.lambda.arn}:*"
      },
    ]
  })
}

resource "aws_cloudwatch_log_group" "lambda" {
  name              = "/aws/lambda/${local.name}"
  retention_in_days = 30

  tags = { Environment = var.environment }
}

resource "aws_lambda_function" "this" {
  function_name    = local.name
  description      = "ARIES incident tools (get_incident, list_incidents) for the AgentCore Gateway"
  role             = aws_iam_role.lambda.arn
  runtime          = "python3.12"
  handler          = "incident_tools.handler"
  filename         = data.archive_file.lambda.output_path
  source_code_hash = data.archive_file.lambda.output_base64sha256
  timeout          = 15
  memory_size      = 256

  environment {
    variables = {
      INCIDENTS_BUCKET = var.incidents_bucket_name
      INCIDENTS_PREFIX = var.incidents_prefix
    }
  }

  tags = { Environment = var.environment }

  depends_on = [aws_iam_role_policy.lambda, aws_cloudwatch_log_group.lambda]
}

########################################
# Tool definitions read by the gateway
########################################
resource "aws_s3_object" "tool_schema" {
  bucket       = var.incidents_bucket_name
  key          = "gateway-tools/incident-tools.json"
  content_type = "application/json"

  content = jsonencode([
    {
      name        = "get_incident"
      description = "Get an approved ARIES incident by its number, for example INC0078085. Returns title, state, priority, category, assignment group, dates, description and resolution."
      inputSchema = {
        type = "object"
        properties = {
          incident_id = { type = "string", description = "Incident number, for example INC0078085" }
        }
        required = ["incident_id"]
      }
    },
    {
      name        = "list_incidents"
      description = "List the numbers of the approved incidents available to ARIES."
      inputSchema = {
        type = "object"
        properties = {
          limit = { type = "integer", description = "Maximum number of incident numbers to return (1-100, default 20)" }
        }
      }
    },
  ])

  tags = { Environment = var.environment }
}
