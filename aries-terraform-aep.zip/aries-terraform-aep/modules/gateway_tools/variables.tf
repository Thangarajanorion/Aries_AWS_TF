variable "project" {
  type = string
}

variable "environment" {
  type = string
}

variable "incidents_bucket_name" {
  type = string
}

variable "incidents_bucket_arn" {
  type = string
}

variable "incidents_prefix" {
  description = "Prefix of the approved incident objects the tools may read"
  type        = string
  default     = "approved-incidents/"
}

variable "name_prefix" {
  description = "Prefix for resource names, e.g. aep-demo-aries"
  type        = string
}
