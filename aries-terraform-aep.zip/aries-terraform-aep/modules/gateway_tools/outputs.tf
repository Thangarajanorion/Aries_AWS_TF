output "lambda_arn" {
  value = aws_lambda_function.this.arn
}

# Built from the object's attributes so gateway targets wait for the upload.
output "tool_schema_s3_uri" {
  value = "s3://${aws_s3_object.tool_schema.bucket}/${aws_s3_object.tool_schema.key}"
}
