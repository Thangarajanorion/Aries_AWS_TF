output "alb_sg_id" {
  value = aws_security_group.alb.id
}

output "ecs_backend_sg_id" {
  value = aws_security_group.ecs_backend.id
}

output "ecs_frontend_sg_id" {
  value = aws_security_group.ecs_frontend.id
}
