variable "project" {
  type        = string
  description = "Project name"
}

variable "environment" {
  type        = string
  description = "Environment name (dev, qa, prod)"
}

variable "vpc_id" {
  type        = string
  description = "VPC ID where security groups will be created"
}

variable "alb_ingress_cidrs" {
  type        = list(string)
  description = "Networks allowed to reach the internal ALB on HTTPS 443"
}

variable "name_prefix" {
  description = "Prefix for resource names, e.g. aep-demo-aries"
  type        = string
}
