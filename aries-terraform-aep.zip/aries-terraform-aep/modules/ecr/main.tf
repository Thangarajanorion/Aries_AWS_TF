########################################
# BACKEND ECR REPOSITORY
########################################

resource "aws_ecr_repository" "backend" {
  name = "${var.name_prefix}-api"

  image_scanning_configuration {
    scan_on_push = true
  }

  force_delete = true

  tags = {
    Name        = "${var.name_prefix}-api"
    Environment = var.environment
  }
}

########################################
# FRONTEND ECR REPOSITORY
########################################

resource "aws_ecr_repository" "frontend" {
  name = "${var.name_prefix}-fe"

  image_scanning_configuration {
    scan_on_push = true
  }

  force_delete = true

  tags = {
    Name        = "${var.name_prefix}-fe"
    Environment = var.environment
  }
}