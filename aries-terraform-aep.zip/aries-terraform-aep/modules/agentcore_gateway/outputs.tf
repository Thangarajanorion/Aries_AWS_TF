output "gateway_id" {
  value = aws_bedrockagentcore_gateway.this.gateway_id
}

output "gateway_arn" {
  value = aws_bedrockagentcore_gateway.this.gateway_arn
}

output "gateway_url" {
  description = "MCP endpoint of the gateway"
  value       = aws_bedrockagentcore_gateway.this.gateway_url
}

output "execution_role_arn" {
  value = aws_iam_role.gateway.arn
}

output "vpc_endpoint_id" {
  value = one(aws_vpc_endpoint.gateway[*].id)
}

output "log_group_name" {
  value = one(aws_cloudwatch_log_group.gateway[*].name)
}
