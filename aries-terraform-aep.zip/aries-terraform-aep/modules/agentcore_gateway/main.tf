data "aws_caller_identity" "current" {}
data "aws_region" "current" {}

locals {
  name         = var.name_prefix
  gateway_name = "${local.name}-gateway"
  account_id   = data.aws_caller_identity.current.account_id
  region       = data.aws_region.current.region

  tags = merge({ Environment = var.environment }, var.tags)

  discovery_url = "https://login.microsoftonline.com/${coalesce(var.entra_tenant_id, "unset")}/v2.0/.well-known/openid-configuration"

  # "s3://bucket/key" -> "arn:aws:s3:::bucket/key"
  spec_object_arns = [
    for uri in concat(
      [for t in values(var.lambda_targets) : t.tool_schema_s3_uri],
      [for t in values(var.openapi_targets) : t.spec_s3_uri],
    ) : "arn:aws:s3:::${trimprefix(uri, "s3://")}"
  ]
}

########################################
# Execution role (assumed by the gateway)
########################################
resource "aws_iam_role" "gateway" {
  name = "${local.name}-agentcore-gateway-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "bedrock-agentcore.amazonaws.com" }
      Action    = "sts:AssumeRole"
      Condition = {
        StringEquals = { "aws:SourceAccount" = local.account_id }
        ArnLike      = { "aws:SourceArn" = "arn:aws:bedrock-agentcore:${local.region}:${local.account_id}:gateway/*" }
      }
    }]
  })

  tags = local.tags
}

# Least privilege: only the listed functions, spec objects and credential providers.
resource "aws_iam_role_policy" "gateway" {
  count = length(var.lambda_targets) + length(var.openapi_targets) + length(var.mcp_server_targets) + (var.kms_key_arn == null ? 0 : 1) > 0 ? 1 : 0

  name = "agentcore-gateway-targets"
  role = aws_iam_role.gateway.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = concat(
      length(var.lambda_targets) == 0 ? [] : [{
        Sid      = "InvokeTargetLambdas"
        Effect   = "Allow"
        Action   = "lambda:InvokeFunction"
        Resource = [for t in values(var.lambda_targets) : t.lambda_arn]
      }],
      length(local.spec_object_arns) == 0 ? [] : [{
        Sid      = "ReadToolSpecs"
        Effect   = "Allow"
        Action   = "s3:GetObject"
        Resource = local.spec_object_arns
      }],
      length(var.openapi_targets) + length(var.mcp_server_targets) == 0 ? [] : [{
        Sid    = "OutboundCredentials"
        Effect = "Allow"
        Action = [
          "bedrock-agentcore:GetWorkloadAccessToken",
          "bedrock-agentcore:GetResourceApiKey",
          "bedrock-agentcore:GetResourceOauth2Token",
        ]
        Resource = [
          "arn:aws:bedrock-agentcore:${local.region}:${local.account_id}:workload-identity-directory/default",
          "arn:aws:bedrock-agentcore:${local.region}:${local.account_id}:workload-identity-directory/default/workload-identity/${local.gateway_name}-*",
          "arn:aws:bedrock-agentcore:${local.region}:${local.account_id}:token-vault/default",
          "arn:aws:bedrock-agentcore:${local.region}:${local.account_id}:token-vault/default/*",
        ]
      }],
      length(var.openapi_targets) == 0 ? [] : [{
        Sid      = "ReadApiKeys"
        Effect   = "Allow"
        Action   = "secretsmanager:GetSecretValue"
        Resource = [for p in aws_bedrockagentcore_api_key_credential_provider.openapi : p.api_key_secret_arn[0].secret_arn]
      }],
      var.kms_key_arn == null ? [] : [{
        Sid      = "UseGatewayKey"
        Effect   = "Allow"
        Action   = ["kms:Decrypt", "kms:GenerateDataKey"]
        Resource = var.kms_key_arn
      }],
    )
  })
}

########################################
# Gateway (MCP endpoint)
########################################
resource "aws_bedrockagentcore_gateway" "this" {
  name            = local.gateway_name
  description     = "ARIES tools gateway (${var.environment})"
  role_arn        = aws_iam_role.gateway.arn
  protocol_type   = "MCP"
  authorizer_type = var.authorizer_type
  kms_key_arn     = var.kms_key_arn

  dynamic "authorizer_configuration" {
    for_each = var.authorizer_type == "CUSTOM_JWT" ? [1] : []
    content {
      custom_jwt_authorizer {
        discovery_url    = local.discovery_url
        allowed_audience = var.jwt_allowed_audiences
        allowed_clients  = var.jwt_allowed_clients
      }
    }
  }

  dynamic "protocol_configuration" {
    for_each = var.enable_semantic_search ? [1] : []
    content {
      mcp {
        search_type = "SEMANTIC"
      }
    }
  }

  tags = local.tags

  lifecycle {
    precondition {
      condition     = var.authorizer_type != "CUSTOM_JWT" || (var.entra_tenant_id != null && length(var.jwt_allowed_audiences) + length(var.jwt_allowed_clients) > 0)
      error_message = "CUSTOM_JWT needs entra_tenant_id and at least one of jwt_allowed_audiences / jwt_allowed_clients."
    }
  }
}

########################################
# Outbound credentials (AgentCore Identity)
########################################
# Read at apply time only; the value is passed to a write-only argument and is
# never stored in the Terraform state.
ephemeral "aws_secretsmanager_secret_version" "openapi_key" {
  for_each  = var.openapi_targets
  secret_id = each.value.api_key_secret_arn
}

resource "aws_bedrockagentcore_api_key_credential_provider" "openapi" {
  for_each = var.openapi_targets

  name = "${local.name}-${each.key}-apikey"
  api_key_wo = (
    each.value.api_key_secret_json_key == null
    ? ephemeral.aws_secretsmanager_secret_version.openapi_key[each.key].secret_string
    : jsondecode(ephemeral.aws_secretsmanager_secret_version.openapi_key[each.key].secret_string)[each.value.api_key_secret_json_key]
  )
  api_key_wo_version = each.value.api_key_version

  tags = local.tags
}

########################################
# Targets
########################################
resource "aws_bedrockagentcore_gateway_target" "lambda" {
  for_each = var.lambda_targets

  name               = each.key
  description        = each.value.description
  gateway_identifier = aws_bedrockagentcore_gateway.this.gateway_id

  credential_provider_configuration {
    gateway_iam_role {}
  }

  target_configuration {
    mcp {
      lambda {
        lambda_arn = each.value.lambda_arn
        tool_schema {
          s3 {
            uri = each.value.tool_schema_s3_uri
          }
        }
      }
    }
  }

  depends_on = [aws_iam_role_policy.gateway]
}

resource "aws_bedrockagentcore_gateway_target" "openapi" {
  for_each = var.openapi_targets

  name               = each.key
  description        = each.value.description
  gateway_identifier = aws_bedrockagentcore_gateway.this.gateway_id

  credential_provider_configuration {
    api_key {
      provider_arn              = aws_bedrockagentcore_api_key_credential_provider.openapi[each.key].credential_provider_arn
      credential_location       = each.value.credential_location
      credential_parameter_name = each.value.credential_parameter_name
      credential_prefix         = each.value.credential_prefix
    }
  }

  target_configuration {
    mcp {
      open_api_schema {
        s3 {
          uri = each.value.spec_s3_uri
        }
      }
    }
  }

  depends_on = [aws_iam_role_policy.gateway]
}

resource "aws_bedrockagentcore_gateway_target" "mcp_server" {
  for_each = var.mcp_server_targets

  name               = each.key
  description        = each.value.description
  gateway_identifier = aws_bedrockagentcore_gateway.this.gateway_id

  dynamic "credential_provider_configuration" {
    for_each = each.value.oauth_provider_arn == null ? [] : [1]
    content {
      oauth {
        provider_arn = each.value.oauth_provider_arn
        scopes       = each.value.oauth_scopes
      }
    }
  }

  target_configuration {
    mcp {
      mcp_server {
        endpoint = each.value.endpoint
      }
    }
  }

  depends_on = [aws_iam_role_policy.gateway]
}

########################################
# Callers (AWS_IAM)
########################################
# New inline policy on the existing task role; the role itself is not changed.
resource "aws_iam_role_policy" "caller_invoke" {
  # Keyed on a plain bool: the role ARN is unknown until the role exists.
  count = var.authorizer_type == "AWS_IAM" && var.attach_caller_policy ? 1 : 0

  name = "invoke-agentcore-gateway"
  role = element(split("/", var.caller_role_arn), length(split("/", var.caller_role_arn)) - 1)

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "bedrock-agentcore:InvokeGateway"
      Resource = aws_bedrockagentcore_gateway.this.gateway_arn
    }]
  })
}

########################################
# Private access: interface VPC endpoint
########################################
resource "aws_security_group" "gateway_endpoint" {
  count = var.create_vpc_endpoint ? 1 : 0

  name        = "${local.name}-agentcore-gw-vpce-sg"
  description = "AgentCore Gateway VPC endpoint"
  vpc_id      = var.vpc_id

  ingress {
    from_port       = 443
    to_port         = 443
    protocol        = "tcp"
    security_groups = var.allowed_security_group_ids
    description     = "HTTPS from the ARIES API"
  }

  tags = merge(local.tags, { Name = "${local.name}-agentcore-gw-vpce-sg" })
}

resource "aws_vpc_endpoint" "gateway" {
  count = var.create_vpc_endpoint ? 1 : 0

  vpc_id              = var.vpc_id
  service_name        = "com.amazonaws.${local.region}.bedrock-agentcore.gateway"
  vpc_endpoint_type   = "Interface"
  subnet_ids          = var.endpoint_subnet_ids
  security_group_ids  = [aws_security_group.gateway_endpoint[0].id]
  private_dns_enabled = true

  tags = merge(local.tags, { Name = "${local.name}-agentcore-gw-vpce" })
}

########################################
# Logging (CloudWatch vended logs)
########################################
resource "aws_cloudwatch_log_group" "gateway" {
  count = var.enable_logging ? 1 : 0

  name              = "/aws/vendedlogs/bedrock-agentcore/gateway/${local.gateway_name}"
  retention_in_days = var.log_retention_days
  kms_key_id        = var.kms_key_arn

  tags = local.tags
}

resource "aws_cloudwatch_log_delivery_source" "gateway" {
  count = var.enable_logging ? 1 : 0

  name         = "${local.gateway_name}-logs"
  log_type     = "APPLICATION_LOGS"
  resource_arn = aws_bedrockagentcore_gateway.this.gateway_arn

  tags = local.tags
}

resource "aws_cloudwatch_log_delivery_destination" "gateway" {
  count = var.enable_logging ? 1 : 0

  name = "${local.gateway_name}-logs"

  delivery_destination_configuration {
    destination_resource_arn = aws_cloudwatch_log_group.gateway[0].arn
  }

  tags = local.tags
}

resource "aws_cloudwatch_log_delivery" "gateway" {
  count = var.enable_logging ? 1 : 0

  delivery_source_name     = aws_cloudwatch_log_delivery_source.gateway[0].name
  delivery_destination_arn = aws_cloudwatch_log_delivery_destination.gateway[0].arn

  tags = local.tags
}
