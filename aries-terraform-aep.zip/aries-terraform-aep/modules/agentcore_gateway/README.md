# agentcore_gateway

Amazon Bedrock AgentCore Gateway for ARIES: one MCP endpoint through which the
ARIES agents call tools (Lambda functions, REST APIs with an OpenAPI spec, or
existing MCP servers). Only adds resources; existing roles and security groups
are referenced, never modified.

## What it creates

| Resource | Notes |
|---|---|
| `aws_bedrockagentcore_gateway` | MCP protocol, `AWS_IAM` or `CUSTOM_JWT` (Microsoft Entra ID) inbound auth |
| `aws_bedrockagentcore_gateway_target` | one per entry in `lambda_targets`, `openapi_targets`, `mcp_server_targets` |
| `aws_bedrockagentcore_api_key_credential_provider` | one per OpenAPI target; key read from Secrets Manager, never stored in state |
| `aws_iam_role` + inline policy | gateway execution role: only the listed Lambdas, spec objects, credential providers |
| `aws_iam_role_policy` on the caller role | `bedrock-agentcore:InvokeGateway` (AWS_IAM only); a new policy, the role is untouched |
| `aws_vpc_endpoint` + security group | `bedrock-agentcore.gateway` interface endpoint, private DNS, 443 only from `allowed_security_group_ids` |
| CloudWatch log group + log delivery | `/aws/vendedlogs/bedrock-agentcore/gateway/<name>`, APPLICATION_LOGS |

Requires Terraform >= 1.11 (write-only arguments) and AWS provider 6.x.

## Inputs

| Name | Default | Description |
|---|---|---|
| `project`, `environment` | â€“ | naming prefix `<project>-<environment>` |
| `authorizer_type` | `AWS_IAM` | `AWS_IAM` or `CUSTOM_JWT` |
| `entra_tenant_id` | `null` | CUSTOM_JWT: builds `https://login.microsoftonline.com/<tenant>/v2.0/.well-known/openid-configuration` |
| `jwt_allowed_audiences` / `jwt_allowed_clients` | `[]` | CUSTOM_JWT: at least one is required |
| `caller_role_arn` | `null` | AWS_IAM: role allowed to invoke the gateway (ARIES API task role) |
| `attach_caller_policy` | `true` | attach the InvokeGateway policy to `caller_role_arn`; set `false` if no caller role is given |
| `lambda_targets` | `{}` | `{ name = { lambda_arn, tool_schema_s3_uri, description? } }` |
| `openapi_targets` | `{}` | `{ name = { spec_s3_uri, api_key_secret_arn, api_key_secret_json_key?, api_key_version?, credential_location?, credential_parameter_name?, credential_prefix?, description? } }` |
| `mcp_server_targets` | `{}` | `{ name = { endpoint, oauth_provider_arn?, oauth_scopes?, description? } }` |
| `enable_semantic_search` | `false` | built-in tool search; fixed at creation |
| `create_vpc_endpoint` | `true` | interface endpoint with private DNS |
| `vpc_id`, `endpoint_subnet_ids`, `allowed_security_group_ids` | â€“ | endpoint placement and who may reach it |
| `kms_key_arn` | `null` | customer managed key for the gateway and log group (key policy must allow CloudWatch Logs) |
| `log_retention_days` | `30` | |
| `tags` | `{}` | merged with `Environment` |

## Outputs

`gateway_id`, `gateway_arn`, `gateway_url` (MCP endpoint), `execution_role_arn`,
`vpc_endpoint_id`, `log_group_name`.

## Adding a tool

Target names: letters, digits and single hyphens.

**Lambda function**
1. Upload the tool definitions (JSON array of `{ name, description, inputSchema }`) to S3.
2. Add to `agentcore_gateway_lambda_targets` in `terraform.tfvars`:
   ```hcl
   "ticket-lookup" = {
     lambda_arn         = "arn:aws:lambda:<region>:<account>:function:<name>"
     tool_schema_s3_uri = "s3://<bucket>/gateway/ticket-lookup-tools.json"
   }
   ```

**REST API (OpenAPI)**
1. Upload the OpenAPI 3 spec to S3.
2. Store the API key in Secrets Manager (plain string, or JSON with `api_key_secret_json_key`).
3. Add to `agentcore_gateway_openapi_targets`:
   ```hcl
   "servicenow" = {
     spec_s3_uri               = "s3://<bucket>/gateway/servicenow-openapi.json"
     api_key_secret_arn        = "arn:aws:secretsmanager:<region>:<account>:secret:<name>"
     credential_parameter_name = "Authorization"
     credential_prefix         = "Bearer "
   }
   ```
   After rotating the key, increase `api_key_version` and apply.

**Existing MCP server**
```hcl
"kb-search" = {
  endpoint = "https://<mcp-server>/mcp"
}
```

Then `terraform plan` â€“ it should show only the new target (and its credential
provider / policy update).

## Calling the gateway

- **AWS_IAM**: sign requests to `gateway_url` with SigV4, service `bedrock-agentcore`,
  using the ECS task role credentials.
- **CUSTOM_JWT**: send `Authorization: Bearer <Entra access token>`; the token's
  `aud` / client ID must match the configured values.

With the VPC endpoint (private DNS), calls from the VPC to `gateway_url` stay on
AWS PrivateLink.
