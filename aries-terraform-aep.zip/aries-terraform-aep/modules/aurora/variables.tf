variable "name_prefix" {
  description = "Prefix for resource names, e.g. aep-demo-aries"
  type        = string
}

variable "vpc_id" {
  type = string
}

variable "subnet_ids" {
  description = "Existing subnets for the DB subnet group"
  type        = list(string)
}

variable "allowed_security_group_ids" {
  description = "Security groups allowed to connect on 5432, keyed by a fixed name"
  type        = map(string)
}

variable "db_name" {
  type = string
}

variable "master_username" {
  type = string
}

variable "engine_version" {
  description = "Aurora PostgreSQL version (15.x matches the previous PostgreSQL 15 instance)"
  type        = string
}

variable "instance_class" {
  description = "Instance class when serverless_v2 is false"
  type        = string
}

variable "instance_count" {
  description = "Number of cluster instances (1 = writer only)"
  type        = number
  default     = 1
}

variable "serverless_v2" {
  description = "Use Aurora Serverless v2 (instance class db.serverless)"
  type        = bool
  default     = false
}

variable "serverless_min_capacity" {
  description = "Serverless v2 minimum ACUs"
  type        = number
  default     = 0.5
}

variable "serverless_max_capacity" {
  description = "Serverless v2 maximum ACUs"
  type        = number
  default     = 4
}

variable "kms_key_arn" {
  description = "KMS key for storage and the master user secret; null = AWS managed keys"
  type        = string
  default     = null
}

variable "backup_retention_period" {
  type    = number
  default = 7
}
