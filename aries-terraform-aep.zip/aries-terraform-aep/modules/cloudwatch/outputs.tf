output "ecs_backend_log_group" {
  value = "/ecs/${var.name_prefix}-backend"
}

output "ecs_frontend_log_group" {
  value = "/ecs/${var.name_prefix}-frontend"
}

output "alb_log_group" {
  value = aws_cloudwatch_log_group.alb.name
}