variable "project" {
  type = string
}

variable "environment" {
  type = string
}

variable "name_prefix" {
  description = "Prefix for resource names, e.g. aep-demo-aries"
  type        = string
}
