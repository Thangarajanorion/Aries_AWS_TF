########################################
# 📊 CloudWatch Log Groups
########################################

# ❌ REMOVED: ecs_backend log group (already created by ECS module)
# ❌ REMOVED: ecs_frontend log group (already created by ECS module)

resource "aws_cloudwatch_log_group" "alb" {
  name              = "/aws/alb/${var.name_prefix}"
  retention_in_days = 14

  lifecycle {
    prevent_destroy = false
    ignore_changes  = all
  }
}

########################################
# 🚨 ECS CPU Alarm (Backend)
########################################

resource "aws_cloudwatch_metric_alarm" "ecs_backend_cpu" {
  alarm_name          = "${var.name_prefix}-backend-high-cpu"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  metric_name         = "CPUUtilization"
  namespace           = "AWS/ECS"
  period              = 60
  statistic           = "Average"
  threshold           = 80

  dimensions = {
    ClusterName = "${var.name_prefix}-cluster"
    ServiceName = "${var.name_prefix}-backend"
  }

  alarm_description = "Backend ECS CPU > 80%"
}

########################################
# 🚨 ECS CPU Alarm (Frontend)
########################################

resource "aws_cloudwatch_metric_alarm" "ecs_frontend_cpu" {
  alarm_name          = "${var.name_prefix}-frontend-high-cpu"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  metric_name         = "CPUUtilization"
  namespace           = "AWS/ECS"
  period              = 60
  statistic           = "Average"
  threshold           = 80

  dimensions = {
    ClusterName = "${var.name_prefix}-cluster"
    ServiceName = "${var.name_prefix}-frontend"
  }

  alarm_description = "Frontend ECS CPU > 80%"
}