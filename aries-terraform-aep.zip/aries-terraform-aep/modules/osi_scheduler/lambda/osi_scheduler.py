"""
Runs OpenSearch Ingestion (OSI) pipelines only when there is work to do.

OSI bills at least 1 OCU per hour for a running pipeline, even an idle one, so
the pipelines are kept STOPPED and this function starts and stops them:

  action=start      (on the ingest schedule, e.g. every 6 hours)
      Counts the objects in each pipeline's S3 prefixes. If none are new since
      the last completed run, the pipeline is left stopped. Otherwise it is
      started with a run budget that grows with the number of objects, because
      an S3-scan pipeline re-reads the whole prefix every time it starts.

  action=reconcile  (every few minutes)
      For each pipeline this function started, stops it as soon as:
        - complete: every object has been read and the buffer is empty, or
        - idle:     the buffer is empty and nothing has been read for a while, or
        - deadline: the run budget is used up.

State (checkpoint + current run) is kept as one SSM parameter per pipeline.
"""
import json
import logging
import math
import os
from datetime import datetime, timedelta, timezone

import boto3

log = logging.getLogger()
log.setLevel(logging.INFO)

osis = boto3.client("osis")
s3 = boto3.client("s3")
ssm = boto3.client("ssm")
cloudwatch = boto3.client("cloudwatch")

PIPELINES = json.loads(os.environ["PIPELINES"])
STATE_PREFIX = os.environ["STATE_PREFIX"].rstrip("/")
MIN_ACTIVE_MINUTES = int(os.environ.get("MIN_ACTIVE_MINUTES", "7"))
IDLE_MINUTES = int(os.environ.get("IDLE_MINUTES", "12"))
BASE_RUN_MINUTES = int(os.environ.get("BASE_RUN_MINUTES", "15"))
SECONDS_PER_OBJECT = float(os.environ.get("SECONDS_PER_OBJECT", "3"))
MAX_RUN_MINUTES = int(os.environ.get("MAX_RUN_MINUTES", "120"))

# Objects uploaded just before a scan can carry a LastModified slightly older
# than the scan itself, so the checkpoint is set a little in the past.
CHECKPOINT_MARGIN = timedelta(minutes=2)
STARTING_STATUSES = ("CREATING", "STARTING", "UPDATING")


def handler(event, context):
    action = event.get("action")
    if action not in ("start", "reconcile"):
        raise ValueError(f"Unknown action: {action!r}")

    now = datetime.now(timezone.utc)
    results, failed = {}, []
    for pipeline in PIPELINES:
        name = pipeline["name"]
        try:
            results[name] = start(pipeline, now) if action == "start" else reconcile(pipeline, now)
        except Exception as exc:  # keep going so one pipeline can't block the other
            log.exception("%s failed for %s", action, name)
            results[name] = f"error: {exc}"
            failed.append(name)

    log.info(json.dumps({"action": action, "results": results}))
    if failed:
        raise RuntimeError(f"{action} failed for: {', '.join(failed)}")
    return results


########################################
# Actions
########################################

def start(pipeline, now):
    name = pipeline["name"]
    state = load_state(name)
    if state.get("run"):
        return "already running"

    status = pipeline_status(name)
    if status != "STOPPED":
        return f"skipped: pipeline is {status}"

    since = parse_time(state.get("checkpoint"))
    total, new = count_objects(pipeline, since)
    checkpoint = to_iso(now - CHECKPOINT_MARGIN)

    if since is not None and new == 0:
        state["checkpoint"] = checkpoint
        save_state(name, state)
        return f"no new objects ({total} total), left stopped"

    budget = min(MAX_RUN_MINUTES, BASE_RUN_MINUTES + math.ceil(total * SECONDS_PER_OBJECT / 60))
    osis.start_pipeline(PipelineName=name)
    state["run"] = {
        "started_at": to_iso(now),
        "objects": total,
        "new_objects": new,
        "budget_minutes": budget,
        "next_checkpoint": checkpoint,
    }
    save_state(name, state)
    return f"started: {new} new / {total} total objects, budget {budget} min"


def reconcile(pipeline, now):
    name = pipeline["name"]
    state = load_state(name)
    run = state.get("run")
    if not run:
        return "not running"

    status = pipeline_status(name)
    started_at = parse_time(run["started_at"])

    if run.get("stop_reason"):
        if status != "STOPPED":
            return f"stopping ({status})"
        # Only a run that finished its work moves the checkpoint forward;
        # after a deadline stop the next slot runs again.
        if run["stop_reason"] in ("complete", "idle"):
            state["checkpoint"] = run["next_checkpoint"]
        run["stopped_at"] = to_iso(now)
        state["last_run"] = run
        state.pop("run")
        save_state(name, state)
        return f"stopped ({run['stop_reason']})"

    if status in STARTING_STATUSES or (status == "STOPPED" and now - started_at < timedelta(minutes=3)):
        return f"starting ({status})"

    if status != "ACTIVE":
        # Start failed, or someone stopped it by hand. Keep the checkpoint so
        # the next slot retries.
        log.warning("%s is %s during a run, abandoning the run", name, status)
        state["last_run"] = {**run, "stop_reason": f"abandoned ({status})", "stopped_at": to_iso(now)}
        state.pop("run")
        save_state(name, state)
        return f"run abandoned: pipeline is {status}"

    if not run.get("active_at"):
        run["active_at"] = to_iso(now)
        save_state(name, state)
    active_at = parse_time(run["active_at"])

    if now - active_at < timedelta(minutes=MIN_ACTIVE_MINUTES):
        return "warming up"

    processed, last_progress, buffer_empty = read_metrics(pipeline, started_at - timedelta(minutes=1), now)
    last_progress = max(last_progress or active_at, active_at)

    if processed >= run["objects"] and buffer_empty:
        reason = "complete"
    elif buffer_empty and now - last_progress >= timedelta(minutes=IDLE_MINUTES):
        reason = "idle"
    elif now - active_at >= timedelta(minutes=run["budget_minutes"]):
        reason = "deadline"
    else:
        return f"processing: {processed:.0f}/{run['objects']} objects, buffer empty={buffer_empty}"

    osis.stop_pipeline(PipelineName=name)
    run.update(stop_reason=reason, processed=processed, stop_requested_at=to_iso(now))
    save_state(name, state)
    return f"stop requested ({reason}): {processed:.0f}/{run['objects']} objects"


########################################
# Helpers
########################################

def count_objects(pipeline, since):
    """Return (objects the pipeline will read, objects modified after `since`)."""
    excluded = tuple(pipeline.get("exclude_suffixes") or ())
    total = new = 0
    paginator = s3.get_paginator("list_objects_v2")
    for prefix in pipeline["prefixes"]:
        for page in paginator.paginate(Bucket=pipeline["bucket"], Prefix=prefix):
            for obj in page.get("Contents", []):
                key = obj["Key"]
                if key.endswith("/") or (excluded and key.endswith(excluded)):
                    continue
                total += 1
                if since is None or obj["LastModified"] > since:
                    new += 1
    return total, new


def read_metrics(pipeline, start, end):
    """Return (objects processed since start, time of last progress, buffer empty now)."""
    sub = pipeline["sub_pipeline"]
    dimensions = [{"Name": "PipelineName", "Value": pipeline["name"]}]

    def query(query_id, metric, stat):
        return {
            "Id": query_id,
            "MetricStat": {
                "Metric": {"Namespace": "AWS/OSIS", "MetricName": f"{sub}.{metric}", "Dimensions": dimensions},
                "Period": 60,
                "Stat": stat,
            },
        }

    queries = [
        query("succeeded", "s3.s3ObjectsSucceeded.count", "Sum"),
        query("failed", "s3.s3ObjectsFailed.count", "Sum"),
        query("records", "recordsProcessed.count", "Sum"),
        query("buffered", "BlockingBuffer.recordsInBuffer.value", "Maximum"),
        query("inflight", "BlockingBuffer.recordsInFlight.value", "Maximum"),
    ]
    series = {}
    for page in cloudwatch.get_paginator("get_metric_data").paginate(
        MetricDataQueries=queries, StartTime=start, EndTime=end
    ):
        for result in page["MetricDataResults"]:
            series.setdefault(result["Id"], []).extend(zip(result["Timestamps"], result["Values"]))

    processed = sum(v for _, v in series.get("succeeded", [])) + sum(v for _, v in series.get("failed", []))
    progress = [t for key in ("succeeded", "records") for t, v in series.get(key, []) if v > 0]

    # Gauges are published every minute while the pipeline runs. With no recent
    # datapoint the buffer state is unknown, so treat it as not empty.
    recent = end - timedelta(minutes=3)
    gauges = [v for key in ("buffered", "inflight") for t, v in series.get(key, []) if t >= recent]
    buffer_empty = bool(gauges) and max(gauges) == 0

    return processed, max(progress, default=None), buffer_empty


def pipeline_status(name):
    return osis.get_pipeline(PipelineName=name)["Pipeline"]["Status"]


def load_state(name):
    try:
        return json.loads(ssm.get_parameter(Name=f"{STATE_PREFIX}/{name}")["Parameter"]["Value"])
    except ssm.exceptions.ParameterNotFound:
        return {}


def save_state(name, state):
    ssm.put_parameter(Name=f"{STATE_PREFIX}/{name}", Value=json.dumps(state), Type="String", Overwrite=True)


def parse_time(value):
    return datetime.fromisoformat(value) if value else None


def to_iso(value):
    return value.isoformat(timespec="seconds")
