output "lambda_function_name" {
  value = aws_lambda_function.this.function_name
}

output "state_parameter_prefix" {
  value = local.state_prefix
}
