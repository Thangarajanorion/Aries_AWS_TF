########################################
# 🤖 Bedrock — Variables
# Region: set by the root module (us-east-2 for AEP)
########################################

########################################
# GENERAL
########################################

variable "project" {
  description = "Project name"
  type        = string
}

variable "environment" {
  description = "Deployment environment (dev, stg, uat, prod)"
  type        = string
}

variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "us-east-2"
}

variable "aws_account_id" {
  description = "AWS account ID"
  type        = string
}

########################################
# IAM — separate roles for KB and Agent
########################################

variable "bedrock_kb_role_arn" {
  description = "IAM role ARN for Bedrock Knowledge Base"
  type        = string
}

variable "bedrock_agent_role_arn" {
  description = "IAM role ARN for Bedrock Agent"
  type        = string
}

########################################
# S3
########################################

variable "kb_s3_bucket_arn" {
  description = "ARN of the S3 bucket used as KB data source"
  type        = string
}

########################################
# OPENSEARCH SERVERLESS
########################################

variable "opensearch_collection_arn" {
  description = "OpenSearch Serverless collection ARN"
  type        = string
}

variable "opensearch_vector_index_name" {
  description = "Name of the vector index in OpenSearch Serverless"
  type        = string
  default     = "bedrock-kb-index"
}

########################################
# ✅ TWO-PASS DEPLOYMENT CONTROL
# Pass 1: false → KB skipped (the vector index does not exist yet)
# Pass 2: true  → KB, data source and agent association created
########################################

variable "create_knowledge_base" {
  description = "Create the Knowledge Base; set true once the vector index exists"
  type        = bool
  default     = false
}

########################################
# EMBEDDING MODEL
# ✅ eu-north-1: Titan Embed v2 is ON_DEMAND
# No inference profile prefix needed.
# Supported dimensions: 256, 512, 1024
########################################

variable "embedding_model_id" {
  description = "Bedrock embedding model ID"
  type        = string
  default     = "amazon.titan-embed-text-v2:0"
}

variable "embedding_dimensions" {
  description = "Vector dimensions for titan-embed-text-v2:0 (256, 512, or 1024)"
  type        = number
  default     = 1024

  validation {
    condition     = contains([256, 512, 1024], var.embedding_dimensions)
    error_message = "embedding_dimensions must be 256, 512, or 1024 for amazon.titan-embed-text-v2:0."
  }
}

########################################
# AGENT FOUNDATION MODEL
# ✅ eu-north-1: Must use eu. cross-region
# inference profile — bare model IDs not
# supported for Agents in this region.
########################################

variable "agent_foundation_model" {
  description = "Cross-region inference profile ARN for the Bedrock Agent"
  type        = string
  default     = "us.anthropic.claude-sonnet-4-6"
}

variable "agent_instruction" {
  description = "System instruction for the Bedrock Agent"
  type        = string
  default     = <<-EOT
    You are ARIES, an intelligent AI assistant for IT operations.
    You help resolve incidents, answer queries using the knowledge base,
    and assist with operational tasks. Always be concise, accurate, and helpful.
  EOT
}

variable "name_prefix" {
  description = "Prefix for resource names, e.g. aep-demo-aries"
  type        = string
}
