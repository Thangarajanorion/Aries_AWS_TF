output "security_group_id" {
  description = "Endpoint security group; the OpenSearch Serverless endpoint uses it too"
  value       = aws_security_group.endpoints.id
}

output "interface_endpoint_ids" {
  value = { for k, e in aws_vpc_endpoint.interface : k => e.id }
}

output "s3_gateway_endpoint_id" {
  value = one(aws_vpc_endpoint.s3[*].id)
}
