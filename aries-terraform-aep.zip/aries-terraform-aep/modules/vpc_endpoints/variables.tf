variable "name_prefix" {
  description = "Prefix for resource names, e.g. aep-demo-aries"
  type        = string
}

variable "vpc_id" {
  description = "Existing VPC"
  type        = string
}

variable "subnet_ids" {
  description = "Existing subnets for the interface endpoints"
  type        = list(string)
}

variable "interface_services" {
  description = "Interface endpoint services, e.g. bedrock-runtime, secretsmanager, ecr.dkr"
  type        = set(string)
}

variable "allowed_security_group_ids" {
  description = "Security groups allowed to reach the endpoints on 443, keyed by a fixed name"
  type        = map(string)
}

variable "create_s3_gateway_endpoint" {
  description = "Create the S3 gateway endpoint; false if the VPC already has one on the route table"
  type        = bool
  default     = true
}

variable "route_table_ids" {
  description = "Route tables the S3 gateway endpoint is associated with"
  type        = list(string)
  default     = []
}
