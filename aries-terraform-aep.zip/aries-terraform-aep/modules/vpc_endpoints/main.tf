########################################
# VPC endpoints for the AWS services ARIES calls
########################################
# The subnets have no NAT gateway; 0.0.0.0/0 goes to the AEP Transit Gateway.
# These endpoints keep AWS API traffic inside the VPC.
# Remove a service from var.interface_services if the VPC already has an
# endpoint with private DNS for it (a second one would fail).

data "aws_region" "current" {}

########################################
# Endpoint security group
########################################
# HTTPS from the listed security groups only. Rules are separate resources
# so other modules (e.g. retention) can add their own.
resource "aws_security_group" "endpoints" {
  name        = "${var.name_prefix}-vpce-sg"
  description = "VPC interface endpoints for ${var.name_prefix}"
  vpc_id      = var.vpc_id

  tags = {
    Name = "${var.name_prefix}-vpce-sg"
  }
}

resource "aws_vpc_security_group_ingress_rule" "https" {
  for_each = var.allowed_security_group_ids

  security_group_id            = aws_security_group.endpoints.id
  referenced_security_group_id = each.value
  from_port                    = 443
  to_port                      = 443
  ip_protocol                  = "tcp"
  description                  = "HTTPS from ${each.key}"
}

########################################
# Interface endpoints
########################################
resource "aws_vpc_endpoint" "interface" {
  for_each = var.interface_services

  vpc_id              = var.vpc_id
  service_name        = "com.amazonaws.${data.aws_region.current.region}.${each.value}"
  vpc_endpoint_type   = "Interface"
  private_dns_enabled = true
  subnet_ids          = var.subnet_ids
  security_group_ids  = [aws_security_group.endpoints.id]

  tags = {
    Name = "${var.name_prefix}-${each.value}"
  }
}

########################################
# S3 gateway endpoint
########################################
# Adds the S3 prefix-list route to the given route tables. ECR image layers
# are pulled from S3, so ECS needs this without a NAT gateway.
resource "aws_vpc_endpoint" "s3" {
  count = var.create_s3_gateway_endpoint ? 1 : 0

  vpc_id            = var.vpc_id
  service_name      = "com.amazonaws.${data.aws_region.current.region}.s3"
  vpc_endpoint_type = "Gateway"
  route_table_ids   = var.route_table_ids

  tags = {
    Name = "${var.name_prefix}-s3"
  }
}
