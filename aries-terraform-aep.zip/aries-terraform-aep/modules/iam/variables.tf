variable "project" {
  type = string
}

variable "environment" {
  type = string
}

variable "aws_account_id" {
  type = string
}

variable "aws_region" {
  type = string
}

variable "backend_secret_arn" {
  description = "Secrets Manager secret the ECS execution role may read for the backend"
  type        = string
}

variable "name_prefix" {
  description = "Prefix for resource names, e.g. aep-demo-aries"
  type        = string
}

variable "bedrock_inference_profile_id" {
  description = "Cross-region inference profile the Bedrock Agent uses, e.g. us.anthropic.claude-sonnet-4-6"
  type        = string
}
