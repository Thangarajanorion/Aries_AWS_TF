########################################
# 👷 ECS Roles
########################################
output "ecs_execution_role_arn" {
  value = aws_iam_role.ecs_execution_role.arn
}

output "ecs_backend_task_role_arn" {
  value = aws_iam_role.ecs_backend_task_role.arn
}

output "ecs_frontend_task_role_arn" {
  value = aws_iam_role.ecs_frontend_task_role.arn
}

########################################
# 🧠 Bedrock Role
########################################
output "bedrock_kb_role_arn" {
  value = aws_iam_role.bedrock_kb_role.arn
}
output "bedrock_agent_role_arn" {
  value = aws_iam_role.bedrock_agent_role.arn
}