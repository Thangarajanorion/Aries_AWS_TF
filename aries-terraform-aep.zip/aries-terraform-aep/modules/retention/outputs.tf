########################################
# FILE: modules/retention/outputs.tf
########################################

output "retention_lambda_name" {
  description = "Lambda function name - use for manual invocation and log lookup"
  value       = aws_lambda_function.retention.function_name
}

output "retention_lambda_arn" {
  value = aws_lambda_function.retention.arn
}

output "retention_lambda_role_arn" {
  description = "Lambda execution role ARN"
  value       = aws_iam_role.retention_lambda.arn
}

output "retention_log_group" {
  description = "CloudWatch log group to check after a run"
  value       = aws_cloudwatch_log_group.retention.name
}

output "retention_security_group_id" {
  value = aws_security_group.retention_lambda.id
}

output "retention_status" {
  description = "Human readable summary of the current retention configuration"
  value = format(
    "OpenSearch retention: index='%s' field='%s' older_than=%dd | dry_run=%s | schedule=%s",
    var.incident_index_name,
    var.query_field,
    var.retention_days,
    var.dry_run ? "TRUE (nothing will be deleted)" : "FALSE (deletions ACTIVE)",
    var.schedule_enabled ? var.schedule_expression : "DISABLED"
  )
}

output "manual_invoke_command" {
  description = "Run this to test the Lambda without waiting for the schedule"
  value       = "aws lambda invoke --function-name ${aws_lambda_function.retention.function_name} --region ${var.aws_region} /tmp/out.json && cat /tmp/out.json"
}
