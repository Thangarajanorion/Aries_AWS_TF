# ARIES – AEP deployment (Terraform)

Terraform for ARIES in the AEP AWS account (387340471575, us-east-2): internal ALB,
ECS Fargate (backend + frontend), Aurora PostgreSQL, OpenSearch Serverless, Bedrock
(agent + knowledge base + guardrail), the AgentCore Gateway with the incident tool,
Secrets Manager, VPC endpoints, the OSI on-demand scheduler and the incident retention job.

The network is AEP's. This code does not create a VPC, subnets, gateways, Transit
Gateway attachments or route tables. It looks up the existing VPC, the 3 subnets and the
route table, and only adds the S3 gateway endpoint route to that route table.

```
AEP network ──TGW──> internal ALB (HTTPS 443) ──> ECS frontend / backend
                                                     │
                     VPC endpoints (private DNS) <───┤  Bedrock, AgentCore Gateway,
                     aoss VPC endpoint          <───┤  Secrets Manager, ECR, logs, STS, KMS, S3
                     Aurora PostgreSQL          <───┘
Internet egress: 0.0.0.0/0 -> Transit Gateway -> AEP firewall (no NAT gateway)
```

## Requirements

- Terraform >= 1.11; providers pinned in `environments/dev/.terraform.lock.hcl`
  (AWS 6.53.0)
- AWS CLI with the `aep-aries` AWS SSO profile
- Bedrock model access in us-east-2 for Claude Sonnet (`us.anthropic.claude-sonnet-4-6`)
  and Titan Text Embeddings V2
- An ACM certificate in us-east-2 for the ARIES internal hostname
- For the gateway test: Python 3 with `botocore`

## Layout

```
environments/dev/   root module – run terraform from here
  aep.tfvars        all AEP-specific values (IDs, CIDRs, ARNs, tags)
  backend-aep.hcl   S3 state backend settings
modules/            agentcore_gateway, alb, aurora, bedrock, cloudwatch, ecr, ecs,
                    gateway_tools, iam, identity, opensearch, osi_scheduler, retention,
                    s3, secrets, security_groups, vpc_endpoints
scripts/            test-gateway.py – smoke test for the AgentCore Gateway
```

## Deploy

1. Log in and fill in the TBD / `<...>` values in `environments/dev/aep.tfvars` and
   `backend-aep.hcl`:
   ```
   aws sso login --profile aep-aries
   ```

2. Check which VPC endpoints already exist in the VPC. Remove those services from
   `interface_endpoint_services` (and set `create_s3_gateway_endpoint = false` if S3 is
   already there); a second endpoint with private DNS for the same service fails.
   ```
   aws ec2 describe-vpc-endpoints --profile aep-aries --region us-east-2 \
     --filters Name=vpc-id,Values=vpc-0a5c1a4507b784997 \
     --query "VpcEndpoints[].[ServiceName,VpcEndpointType,PrivateDnsEnabled,State]" --output table
   ```

3. Pass 1:
   ```
   cd environments/dev
   terraform init -backend-config=backend-aep.hcl
   terraform plan  -var-file=aep.tfvars -out=aep.tfplan
   terraform apply aep.tfplan
   ```

4. Push the application images to the ECR repositories `aep-demo-aries-api` and
   `aep-demo-aries-fe` with the tags set in `aep.tfvars`.

5. Load the backend credentials into `aep-demo-aries-backend-secrets` (JSON with the keys
   listed in `local.backend_secret_keys`, `modules/ecs/main.tf`). Build `DB_URL` and
   `DB_URL_ASYNC` from the `aurora_writer_endpoint` output and the password in the
   `aurora_master_user_secret_arn` secret. Do not add `sslmode` to `DB_URL_ASYNC`.
   ```
   aws secretsmanager put-secret-value --profile aep-aries --region us-east-2 \
     --secret-id aep-demo-aries-backend-secrets --secret-string file://backend-secrets.json
   ```
   Delete the local JSON file afterwards.

6. Create the OpenSearch indexes (the KB vector index from the `create_index_command`
   output, and `aries-incidents-idx`) from a host that reaches the aoss VPC endpoint,
   with a role listed in `aoss_admin_principal_arns`.

7. Pass 2: set `create_knowledge_base = true` in `aep.tfvars`, then plan and apply again.

8. Ask AEP to point the ARIES internal hostname (`app_url`) at the `alb_dns_name` output,
   then open `app_url` from the AEP network.

9. Test the AgentCore Gateway:
   ```
   python ../../scripts/test-gateway.py "$(terraform output -raw agentcore_gateway_url)"
   ```

## Database

Aurora PostgreSQL 15 (`aurora_engine_version`), 1 instance by default
(`aurora_instance_count`), or Serverless v2 with `aurora_serverless_v2 = true`.
Encrypted with `db_kms_key_arn` (or the AWS managed key), deletion protection on,
7-day backups. RDS creates and stores the master password in Secrets Manager.
Port 5432 is open only to the ECS and retention Lambda security groups.

## VPC endpoints

Interface endpoints with private DNS in the 3 subnets (`interface_endpoint_services`),
the S3 gateway endpoint on `route_table_id`, and the OpenSearch Serverless endpoint.
They share one security group allowing 443 from the ECS and retention Lambda security
groups only. The 3 subnets are /26 (59 usable addresses each); the endpoints use one
address per subnet each.

## Not managed by this code

- The VPC, subnets, Transit Gateway, routing and the AEP firewall.
- DNS for the internal hostname, and the ACM certificate.
- OpenSearch Ingestion (OSI) pipelines and the OpenSearch indexes. The OSI scheduler
  expects pipelines named `aep-demo-aries-incidents` and `aep-demo-aries-knowledge`.
- CI/CD (image build and ECS deploy).
- The ARIES API code change that connects to the AgentCore Gateway (MCP client).
- WAF / perimeter firewall.

## Optional components – safe defaults

- **OSI scheduler**: starts an OSI pipeline only when new files arrive in S3 and
  stops it when ingestion is complete, idle, or past its time budget.
- **Retention**: deletes incidents older than `retention_days` from OpenSearch and S3.
  Ships with `retention_dry_run = true` and `retention_schedule_enabled = false`,
  so nothing is deleted until those are changed.
