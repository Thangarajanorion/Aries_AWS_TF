########################################
# Outputs — Key values after deployment
########################################

output "opensearch_endpoint" {
  description = "Set as OPENSEARCH_ENDPOINT in ECS task definition"
  value       = module.opensearch.opensearch_endpoint
}

output "aoss_vpc_endpoint_id" {
  description = "OpenSearch Serverless VPC endpoint (referenced by the network policy)"
  value       = module.opensearch.aoss_vpc_endpoint_id
}

output "create_index_command" {
  description = "Creates the KB vector index; run from a host that reaches the aoss endpoint"
  value       = module.opensearch.create_index_command
}

output "bedrock_kb_id" {
  description = "Set as BEDROCK_KNOWLEDGE_BASE_ID in ECS task definition"
  value       = module.bedrock.knowledge_base_id
}

output "bedrock_agent_id" {
  description = "Set as BEDROCK_AGENT_ID in ECS task definition"
  value       = module.bedrock.agent_id
}

output "bedrock_agent_alias_id" {
  description = "Set as BEDROCK_AGENT_ALIAS_ID in ECS task definition"
  value       = module.bedrock.agent_alias_id
}

output "alb_dns_name" {
  description = "Internal ALB; point the AEP internal DNS name (app_url) at it"
  value       = module.alb.alb_dns_name
}

output "aurora_writer_endpoint" {
  description = "Host for DB_URL / DB_URL_ASYNC in the backend secret"
  value       = module.aurora.writer_endpoint
}

output "aurora_reader_endpoint" {
  value = module.aurora.reader_endpoint
}

output "aurora_master_user_secret_arn" {
  description = "Secrets Manager secret with the Aurora master username and password"
  value       = module.aurora.master_user_secret_arn
}

output "vpc_id" {
  value = local.vpc_id
}

output "vpc_endpoint_ids" {
  value = module.vpc_endpoints.interface_endpoint_ids
}

output "s3_gateway_endpoint_id" {
  value = module.vpc_endpoints.s3_gateway_endpoint_id
}

########################################
# RETENTION OUTPUTS
########################################

output "incident_retention_summary" {
  description = "Current S3 incidents bucket retention configuration"
  value       = module.s3.incident_retention_summary
}

output "opensearch_retention_status" {
  description = "Current OpenSearch retention configuration"
  value       = module.retention.retention_status
}

output "retention_lambda_name" {
  description = "Retention Lambda function name"
  value       = module.retention.retention_lambda_name
}

output "retention_log_group" {
  description = "CloudWatch log group to inspect after a run"
  value       = module.retention.retention_log_group
}

output "retention_manual_invoke" {
  description = "Command to test the retention Lambda"
  value       = module.retention.manual_invoke_command
}

output "agentcore_gateway_id" {
  value = module.agentcore_gateway.gateway_id
}

output "agentcore_gateway_url" {
  description = "Set as the gateway URL env var on the ARIES API task"
  value       = module.agentcore_gateway.gateway_url
}

output "agentcore_gateway_role_arn" {
  value = module.agentcore_gateway.execution_role_arn
}
