# TBD: state bucket in account 387340471575 (versioning on, encrypted)
bucket       = "<STATE_BUCKET>"
key          = "aries/aep-demo/terraform.tfstate"
region       = "us-east-2"
profile      = "aep-aries"
encrypt      = true
use_lockfile = true
