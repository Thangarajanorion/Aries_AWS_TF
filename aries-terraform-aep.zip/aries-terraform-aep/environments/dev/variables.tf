########################################
# GLOBAL VARIABLES (ROOT MODULE)
########################################

variable "aws_region" {
  type = string
}

variable "aws_profile" {
  description = "AWS CLI profile (AWS SSO); null = default credential chain"
  type        = string
  default     = null
}

variable "project" {
  type = string
}

variable "environment" {
  type = string
}

variable "name_prefix" {
  description = "Prefix for all resource names"
  type        = string
  default     = "aep-demo-aries"
}

variable "tags" {
  description = "Tags applied to every resource through the provider default_tags"
  type        = map(string)
  default     = {}
}

variable "aws_account_id" {
  type = string
}

variable "entra_tenant_id" {
  type = string
}

variable "domain_name" {
  type = string
}

variable "sso_admin_group_name" {
  type = string
}

variable "sso_dev_group_name" {
  type = string
}

variable "sso_readonly_group_name" {
  type = string
}

########################################
# EXISTING NETWORK (looked up, not created)
########################################

variable "vpc_id" {
  description = "Existing VPC"
  type        = string
}

variable "subnet_ids" {
  description = "Existing subnets for the ALB, ECS, Lambda, Aurora and the VPC endpoints"
  type        = list(string)
}

variable "route_table_id" {
  description = "Existing route table the S3 gateway endpoint is associated with"
  type        = string
}

########################################
# ENTRY POINT (internal ALB)
########################################

variable "alb_certificate_arn" {
  description = "ACM certificate ARN for the internal ALB HTTPS listener"
  type        = string
}

variable "alb_ingress_cidrs" {
  description = "AEP networks allowed to reach the ALB on HTTPS 443"
  type        = list(string)
  default     = ["10.0.0.0/8"]
}

variable "app_url" {
  description = "URL users open ARIES on, e.g. https://aries.<aep-internal-domain>; used by the frontend"
  type        = string
}

########################################
# VPC ENDPOINTS
########################################

variable "interface_endpoint_services" {
  description = "Interface endpoints to create; remove any service the VPC already has an endpoint for"
  type        = set(string)
  default = [
    "bedrock-runtime",
    "bedrock-agent-runtime",
    "bedrock-agentcore.gateway",
    "secretsmanager",
    "ecr.api",
    "ecr.dkr",
    "logs",
    "sts",
    "kms",
  ]
}

variable "create_s3_gateway_endpoint" {
  description = "Create the S3 gateway endpoint; false if the route table already has one"
  type        = bool
  default     = true
}

########################################
# DATABASE VARIABLES (Aurora PostgreSQL)
########################################

variable "db_name" {
  type = string
}

variable "db_user" {
  type = string
}

variable "aurora_engine_version" {
  description = "Aurora PostgreSQL version; 15.x matches the PostgreSQL 15 used before"
  type        = string
  default     = "15.13"
}

variable "db_instance_class" {
  description = "Aurora instance class (ignored when aurora_serverless_v2 = true)"
  type        = string
}

variable "aurora_instance_count" {
  description = "Number of Aurora instances (1 = writer only)"
  type        = number
  default     = 1
}

variable "aurora_serverless_v2" {
  description = "Use Aurora Serverless v2 instead of a fixed instance class"
  type        = bool
  default     = false
}

variable "aurora_serverless_min_capacity" {
  type    = number
  default = 0.5
}

variable "aurora_serverless_max_capacity" {
  type    = number
  default = 4
}

variable "db_kms_key_arn" {
  description = "Existing KMS key for Aurora storage and its master user secret; null = AWS managed keys"
  type        = string
  default     = null
}

########################################
# ✅ OPENSEARCH SERVERLESS / BEDROCK
########################################

variable "aoss_admin_principal_arns" {
  description = "IAM roles/users with admin access to the collection (they create the indexes)"
  type        = list(string)
  default     = []
}

variable "create_knowledge_base" {
  description = "Pass 2: set true once the vector index exists in OpenSearch"
  type        = bool
  default     = false
}

variable "bedrock_inference_profile_id" {
  description = "Cross-region inference profile for the Bedrock Agent (us. prefix in us-east-2)"
  type        = string
  default     = "us.anthropic.claude-sonnet-4-6"
}

########################################
# IMAGE TAG VARIABLES
########################################

variable "image_tag_backend" {
  type    = string
  default = "latest"
}

variable "image_tag_frontend" {
  type    = string
  default = "latest"
}

########################################
# RETENTION VARIABLES
#
# Controls 90 day deletion of incident data from both
# the S3 incidents bucket and OpenSearch.
#
# All flags default to OFF so applying changes nothing
# until deliberately enabled.
########################################

variable "incident_index_name" {
  type        = string
  description = "AOSS index holding incident documents. Created by the application at runtime, not by Terraform."
  default     = "aries-incidents-idx"
}

variable "incident_query_field" {
  type        = string
  description = "Field queried for document age. ticket_creation_date is mapped as TEXT so the .keyword subfield is required."
  default     = "ticket_creation_date.keyword"
}

variable "retention_days" {
  type        = number
  description = "Retention period in days, applied to both S3 and OpenSearch"
  default     = 90
}

variable "incident_retention_enabled" {
  type        = bool
  description = "Enable the S3 lifecycle rule on the incidents bucket. Keep false until security approval."
  default     = false
}

variable "retention_dry_run" {
  type        = bool
  description = "True means the Lambda reports eligible documents but deletes nothing. Keep true until verified."
  default     = true
}

variable "retention_schedule_enabled" {
  type        = bool
  description = "Whether the daily EventBridge cleanup schedule is active. Keep false until verified and approved."
  default     = false
}

variable "additional_access_principals" {
  type        = list(string)
  description = "TEMPORARY. Extra IAM ARNs granted read access to the OpenSearch collection. Reset to [] when finished."
  default     = []
}

variable "delete_s3_objects" {
  type        = bool
  description = "Whether the retention Lambda also deletes the matching S3 object. Keeps S3 and OpenSearch on the same parameter."
  default     = true
}

########################################
# AGENTCORE GATEWAY VARIABLES
########################################

variable "agentcore_gateway_authorizer_type" {
  description = "AWS_IAM (ECS task role signs requests) or CUSTOM_JWT (Microsoft Entra ID token)"
  type        = string
  default     = "AWS_IAM"
}

variable "agentcore_gateway_jwt_allowed_audiences" {
  description = "CUSTOM_JWT only: accepted 'aud' values of the Entra token"
  type        = list(string)
  default     = []
}

variable "agentcore_gateway_jwt_allowed_clients" {
  description = "CUSTOM_JWT only: accepted Entra client IDs"
  type        = list(string)
  default     = []
}

variable "agentcore_gateway_lambda_targets" {
  description = "Lambda tools exposed through the gateway (see modules/agentcore_gateway)"
  type = map(object({
    lambda_arn         = string
    tool_schema_s3_uri = string
    description        = optional(string)
  }))
  default = {}
}

variable "agentcore_gateway_openapi_targets" {
  description = "REST API tools exposed through the gateway (see modules/agentcore_gateway)"
  type = map(object({
    spec_s3_uri               = string
    api_key_secret_arn        = string
    api_key_secret_json_key   = optional(string)
    api_key_version           = optional(number, 1)
    credential_location       = optional(string, "HEADER")
    credential_parameter_name = optional(string, "x-api-key")
    credential_prefix         = optional(string)
    description               = optional(string)
  }))
  default = {}
}

variable "agentcore_gateway_mcp_server_targets" {
  description = "Existing MCP servers exposed through the gateway (see modules/agentcore_gateway)"
  type = map(object({
    endpoint           = string
    oauth_provider_arn = optional(string)
    oauth_scopes       = optional(list(string), [])
    description        = optional(string)
  }))
  default = {}
}

variable "agentcore_gateway_kms_key_arn" {
  description = "Customer managed KMS key for the gateway and its logs; null = AWS owned key"
  type        = string
  default     = null
}
