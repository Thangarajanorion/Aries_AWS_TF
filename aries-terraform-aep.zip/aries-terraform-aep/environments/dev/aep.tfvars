# AEP deployment of ARIES
# Run: terraform plan -var-file=aep.tfvars
# Values marked TBD / <...> must be confirmed before apply.

project     = "aries"
environment = "aep-demo"
name_prefix = "aep-demo-aries"

# ---------------- Account ----------------
aws_region     = "us-east-2"
aws_account_id = "387340471575"
aws_profile    = "aep-aries"

# ---------------- Tags (provider default_tags) ----------------
# TBD: confirm keys and values with AEP
tags = {
  BusinessUnit       = "TBD"
  DeptID             = "TBD"
  ProductName        = "TBD"
  Owner              = "TBD"
  Dataclassification = "TBD"
  Team               = "TBD"
  Deployment         = "aep_demo_ecs"
}

# ---------------- Existing network (Esri-Sb_VPC) ----------------
# Looked up read-only; this code does not change the VPC, subnets or route tables.
vpc_id = "vpc-0bee26f8fe1b724b8" # Esri-Sb_VPC 10.203.0.0/24

subnet_ids = [
  "subnet-0ead5c457a155d8c1", # esri-sb_Private_1  us-east-2a  10.203.0.0/26
  "subnet-07c2722ae346deedc", # esri-sb_Private_2  us-east-2b  10.203.0.64/26
  "subnet-00b91cc1c13e3e4f9", # esri-sb_Private_3  us-east-2c  10.203.0.128/26
]

# Main route table of the esri subnets:
#   10.0.0.0/8 and 0.0.0.0/0 -> tgw-02ac34f9cf5cc3667
#   existing S3 gateway endpoint already attached
route_table_id = "rtb-0a6c50d12be3ba392"

# ---------------- Entry point (internal ALB) ----------------
# TBD: ACM certificate for the ARIES internal hostname
alb_certificate_arn = "arn:aws:acm:us-east-2:387340471575:certificate/REPLACE-WITH-CERTIFICATE-ID"

# TBD: AEP networks allowed to reach ARIES
alb_ingress_cidrs = ["10.0.0.0/8"]

# TBD: internal hostname users open; AEP DNS points it at the alb_dns_name output
app_url = "https://<ARIES_INTERNAL_HOSTNAME>"

# ---------------- VPC endpoints ----------------
# None of these exist in Esri-Sb_VPC today (checked 24 Nov 2026).
# Remove any service that gets an endpoint with private DNS before apply.
interface_endpoint_services = [
  "bedrock-runtime",
  "bedrock-agent-runtime",
  "bedrock-agentcore.gateway",
  "secretsmanager",
  "ecr.api",
  "ecr.dkr",
  "logs",
  "sts",
  "kms",
]

# The S3 gateway endpoint already exists on rtb-0a6c50d12be3ba392: do not create another
create_s3_gateway_endpoint = false

# ---------------- Database (Aurora PostgreSQL) ----------------
# Checked: Aurora PostgreSQL 15.13 on db.t3.medium is available in us-east-2
db_name               = "appdb"
db_user               = "dbadmin"
aurora_engine_version = "15.13"
db_instance_class     = "db.t3.medium"
aurora_instance_count = 1
aurora_serverless_v2  = false

# TBD: ARN of the existing KMS key (null = AWS managed aws/rds key)
db_kms_key_arn = null

# ---------------- OpenSearch Serverless / Bedrock ----------------
# TBD: AEP role(s) that create the OpenSearch indexes
aoss_admin_principal_arns = []

# Pass 1: false. Pass 2: true, after the vector index has been created.
create_knowledge_base = false

# TBD: confirm the exact inference profile ID in the Bedrock console (us-east-2)
bedrock_inference_profile_id = "us.anthropic.claude-sonnet-4-6"

# ---------------- Identity ----------------
# TBD: AEP values
domain_name     = "<AEP_DOMAIN>"
entra_tenant_id = "<ENTRA_TENANT_ID>"

sso_admin_group_name    = "Admins"
sso_dev_group_name      = "Developers"
sso_readonly_group_name = "ReadOnly"

# ---------------- Images ----------------
# TBD: tags of the images pushed to ECR
image_tag_backend  = "<BACKEND_IMAGE_TAG>"
image_tag_frontend = "<FRONTEND_IMAGE_TAG>"

# ---------------- Retention ----------------
incident_index_name  = "aries-incidents-idx"
incident_query_field = "ticket_creation_date.keyword"
retention_days       = 90

incident_retention_enabled = false
delete_s3_objects          = true
retention_dry_run          = true
retention_schedule_enabled = false

additional_access_principals = []

# ---------------- AgentCore Gateway ----------------
agentcore_gateway_authorizer_type       = "AWS_IAM"
agentcore_gateway_jwt_allowed_audiences = []
agentcore_gateway_jwt_allowed_clients   = []

agentcore_gateway_lambda_targets     = {}
agentcore_gateway_openapi_targets    = {}
agentcore_gateway_mcp_server_targets = {}
