# Remote state in S3. Settings are in backend-aep.hcl:
#   terraform init -backend-config=backend-aep.hcl
terraform {
  backend "s3" {}
}
