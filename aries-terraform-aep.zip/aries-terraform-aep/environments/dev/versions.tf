terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.0"
    }
    opensearch = {
      source  = "opensearch-project/opensearch"
      version = ">= 2.2.0"
    }
    # ADDED - required to zip the retention Lambda source
    archive = {
      source  = "hashicorp/archive"
      version = "~> 2.4"
    }
  }
}
