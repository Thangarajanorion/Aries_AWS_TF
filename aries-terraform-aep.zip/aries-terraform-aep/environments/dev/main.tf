########################################
# 🌍 Providers
########################################
provider "aws" {
  region  = var.aws_region
  profile = var.aws_profile

  # Refuse to run against any other account.
  allowed_account_ids = [var.aws_account_id]

  default_tags {
    tags = var.tags
  }
}

########################################
# LEVEL 0 — Existing AEP network (read-only lookups)
########################################
# Nothing in the network is created or changed here, except the S3 gateway
# endpoint route on var.route_table_id (modules/vpc_endpoints).

data "aws_vpc" "this" {
  id = var.vpc_id
}

data "aws_subnet" "selected" {
  for_each = toset(var.subnet_ids)
  id       = each.value

  lifecycle {
    postcondition {
      condition     = self.vpc_id == var.vpc_id
      error_message = "Subnet ${each.value} is not in ${var.vpc_id}."
    }
  }
}

data "aws_route_table" "s3_endpoint" {
  route_table_id = var.route_table_id

  lifecycle {
    postcondition {
      condition     = self.vpc_id == var.vpc_id
      error_message = "Route table ${var.route_table_id} is not in ${var.vpc_id}."
    }
  }
}

locals {
  vpc_id     = data.aws_vpc.this.id
  subnet_ids = [for id in var.subnet_ids : data.aws_subnet.selected[id].id]
}

########################################
# LEVEL 0 — Identity + Base Infra
########################################

module "identity" {
  source = "../../modules/identity"

  project         = var.project
  environment     = var.environment
  name_prefix     = var.name_prefix
  aws_account_id  = var.aws_account_id
  aws_region      = var.aws_region
  entra_tenant_id = var.entra_tenant_id

  domain_name             = var.domain_name
  sso_admin_group_name    = var.sso_admin_group_name
  sso_dev_group_name      = var.sso_dev_group_name
  sso_readonly_group_name = var.sso_readonly_group_name
}

module "iam" {
  source = "../../modules/iam"

  project        = var.project
  environment    = var.environment
  name_prefix    = var.name_prefix
  aws_account_id = var.aws_account_id
  aws_region     = var.aws_region

  backend_secret_arn           = module.secrets.backend_secret_arn
  bedrock_inference_profile_id = var.bedrock_inference_profile_id
}

module "s3" {
  source = "../../modules/s3"

  project        = var.project
  environment    = var.environment
  name_prefix    = var.name_prefix
  aws_account_id = var.aws_account_id
  kb_role_arn    = module.iam.bedrock_kb_role_arn

  # S3 lifecycle rule. NOTE: leave this DISABLED.
  # Deletion is handled by the retention Lambda instead, so
  # that S3 and OpenSearch both key off ticket_creation_date.
  # An S3 lifecycle rule can only expire on UPLOAD date, which
  # would cause the two stores to drift apart.
  incident_retention_enabled = var.incident_retention_enabled
  incident_retention_days    = var.retention_days

  depends_on = [module.iam]
}

########################################
# LEVEL 1 — Security Layer
########################################

module "security_groups" {
  source = "../../modules/security_groups"

  project     = var.project
  environment = var.environment
  name_prefix = var.name_prefix
  vpc_id      = local.vpc_id

  alb_ingress_cidrs = var.alb_ingress_cidrs
}

module "secrets" {
  source = "../../modules/secrets"

  project            = var.project
  environment        = var.environment
  name_prefix        = var.name_prefix
  db_name            = var.db_name
  oidc_client_id     = module.identity.oidc_client_id
  oidc_client_secret = module.identity.oidc_client_secret

  depends_on = [module.identity]
}

########################################
# LEVEL 1 — VPC endpoints
########################################
# The retention Lambda adds its own 443 rule to this security group
# (modules/retention).
module "vpc_endpoints" {
  source = "../../modules/vpc_endpoints"

  name_prefix = var.name_prefix
  vpc_id      = local.vpc_id
  subnet_ids  = local.subnet_ids

  interface_services = var.interface_endpoint_services
  allowed_security_group_ids = {
    ecs_backend  = module.security_groups.ecs_backend_sg_id
    ecs_frontend = module.security_groups.ecs_frontend_sg_id
  }

  create_s3_gateway_endpoint = var.create_s3_gateway_endpoint
  route_table_ids            = [data.aws_route_table.s3_endpoint.id]
}

########################################
# LEVEL 2 — Core Services
########################################

module "aurora" {
  source = "../../modules/aurora"

  name_prefix = var.name_prefix
  vpc_id      = local.vpc_id
  subnet_ids  = local.subnet_ids

  allowed_security_group_ids = {
    ecs_backend      = module.security_groups.ecs_backend_sg_id
    ecs_frontend     = module.security_groups.ecs_frontend_sg_id
    retention_lambda = module.retention.retention_security_group_id
  }

  db_name                 = var.db_name
  master_username         = var.db_user
  engine_version          = var.aurora_engine_version
  instance_class          = var.db_instance_class
  instance_count          = var.aurora_instance_count
  serverless_v2           = var.aurora_serverless_v2
  serverless_min_capacity = var.aurora_serverless_min_capacity
  serverless_max_capacity = var.aurora_serverless_max_capacity
  kms_key_arn             = var.db_kms_key_arn
  backup_retention_period = 7
}

########################################
# ✅ OpenSearch Serverless
# The collection is reachable only through its aoss VPC endpoint
# (network policy references the endpoint directly).
# ✅ opensearch provider removed — index created manually
#    from inside the AEP network using awscurl (see create_index_command output)
########################################
module "opensearch" {
  source = "../../modules/opensearch"

  project        = var.project
  environment    = var.environment
  name_prefix    = var.name_prefix
  aws_account_id = var.aws_account_id
  aws_region     = var.aws_region

  vpc_id            = local.vpc_id
  subnet_ids        = local.subnet_ids
  security_group_id = module.vpc_endpoints.security_group_id

  backend_task_role_arn = module.iam.ecs_backend_task_role_arn
  bedrock_kb_role_arn   = module.iam.bedrock_kb_role_arn
  admin_principal_arns  = var.aoss_admin_principal_arns
}

module "alb" {
  source = "../../modules/alb"

  project           = var.project
  environment       = var.environment
  name_prefix       = var.name_prefix
  vpc_id            = local.vpc_id
  subnet_ids        = local.subnet_ids
  security_group_id = module.security_groups.alb_sg_id
  certificate_arn   = var.alb_certificate_arn

  depends_on = [module.security_groups]
}

########################################
# LEVEL 3 — ECR
########################################
module "ecr" {
  source = "../../modules/ecr"

  project     = var.project
  environment = var.environment
  name_prefix = var.name_prefix
}

########################################
# LEVEL 3 — ECS
# ✅ OPENSEARCH_ENDPOINT points to serverless endpoint
# Format: https://xxx.us-east-2.aoss.amazonaws.com
########################################
module "ecs" {
  source = "../../modules/ecs"

  project     = var.project
  environment = var.environment
  name_prefix = var.name_prefix
  aws_region  = var.aws_region

  private_subnet_ids = local.subnet_ids
  backend_sg_id      = module.security_groups.ecs_backend_sg_id
  frontend_sg_id     = module.security_groups.ecs_frontend_sg_id

  execution_role_arn     = module.iam.ecs_execution_role_arn
  backend_task_role_arn  = module.iam.ecs_backend_task_role_arn
  frontend_task_role_arn = module.iam.ecs_frontend_task_role_arn

  backend_image  = "${module.ecr.backend_repository_url}:${var.image_tag_backend}"
  frontend_image = "${module.ecr.frontend_repository_url}:${var.image_tag_frontend}"

  backend_target_group_arn  = module.alb.backend_target_group_arn
  frontend_target_group_arn = module.alb.frontend_target_group_arn

  app_url                = var.app_url
  db_endpoint            = module.aurora.writer_endpoint
  opensearch_kb_endpoint = module.opensearch.opensearch_endpoint

  db_name            = var.db_name
  db_user            = var.db_user
  backend_secret_arn = module.secrets.backend_secret_arn

  bedrock_agent_id          = module.bedrock.agent_id
  bedrock_agent_alias_id    = module.bedrock.agent_alias_id
  bedrock_knowledge_base_id = module.bedrock.knowledge_base_id

  depends_on = [
    module.aurora,
    module.opensearch,
    module.alb,
    module.iam,
    module.bedrock,
    module.vpc_endpoints
  ]
}

########################################
# LEVEL 4 — Bedrock
########################################
module "bedrock" {
  source = "../../modules/bedrock"

  project        = var.project
  environment    = var.environment
  name_prefix    = var.name_prefix
  aws_region     = var.aws_region
  aws_account_id = var.aws_account_id

  bedrock_kb_role_arn    = module.iam.bedrock_kb_role_arn
  bedrock_agent_role_arn = module.iam.bedrock_agent_role_arn

  kb_s3_bucket_arn             = module.s3.knowledge_bucket_arn
  opensearch_collection_arn    = module.opensearch.opensearch_serverless_collection_arn
  opensearch_vector_index_name = module.opensearch.vector_index_name

  # Two-pass: the Knowledge Base is created once the vector index exists
  create_knowledge_base = var.create_knowledge_base

  agent_foundation_model = "arn:aws:bedrock:${var.aws_region}:${var.aws_account_id}:inference-profile/${var.bedrock_inference_profile_id}"

  agent_instruction = "You are a helpful assistant. Answer questions using the knowledge base."

  depends_on = [
    module.iam,
    module.s3,
    module.opensearch
  ]
}

########################################
# LEVEL 5 - Retention
#
# Deletes incident data older than the retention period
# from OpenSearch Serverless and S3.
#
# A Lambda is required for OpenSearch because:
#   1. AOSS data lifecycle policies support only TIME
#      SERIES collections; ours is VECTORSEARCH
#   2. _delete_by_query is not supported in AOSS
#   3. Only search + bulk delete by _id are available
#
# SAFETY: dry_run and schedule_enabled default to safe
# values, so applying changes nothing until enabled.
########################################
module "retention" {
  source = "../../modules/retention"

  project     = var.project
  environment = var.environment
  name_prefix = var.name_prefix
  aws_region  = var.aws_region

  opensearch_endpoint        = module.opensearch.opensearch_endpoint
  opensearch_collection_arn  = module.opensearch.opensearch_serverless_collection_arn
  opensearch_collection_name = module.opensearch.collection_name
  # Adds the Lambda to the VPC endpoint security group (aoss included)
  opensearch_security_group_id = module.vpc_endpoints.security_group_id

  incident_index_name = var.incident_index_name

  # ticket_creation_date is mapped as TEXT, not date, so the
  # .keyword subfield must be queried.
  query_field    = var.incident_query_field
  retention_days = var.retention_days

  dry_run          = var.retention_dry_run
  schedule_enabled = var.retention_schedule_enabled

  # Deletes the matching S3 object in the same pass, so both
  # stores are driven by ticket_creation_date and cannot drift.
  incidents_bucket_arn = module.s3.incidents_bucket_arn
  delete_s3_objects    = var.delete_s3_objects

  # TEMPORARY: extra identities granted read access for
  # troubleshooting. Reset to [] when finished.
  additional_access_principals = var.additional_access_principals

  vpc_id     = local.vpc_id
  subnet_ids = local.subnet_ids

  depends_on = [
    module.opensearch,
    module.security_groups
  ]
}

########################################
# LEVEL 6 - OSI on-demand scheduler
########################################
# The OSI pipelines themselves are not managed by Terraform yet; their names
# and S3 sources below must match the live pipeline configuration.
module "osi_scheduler" {
  source = "../../modules/osi_scheduler"

  project     = var.project
  environment = var.environment
  name_prefix = var.name_prefix

  pipelines = {
    "${var.name_prefix}-incidents" = {
      sub_pipeline     = "incidents-approved-pipeline"
      bucket           = module.s3.incidents_bucket_name
      prefixes         = ["approved-incidents/"]
      exclude_suffixes = [".pdf", ".md"]
    }
    "${var.name_prefix}-knowledge" = {
      sub_pipeline     = "knowledge-approved-pipeline"
      bucket           = module.s3.knowledge_bucket_name
      prefixes         = ["approved-files/"]
      exclude_suffixes = [".pdf", ".md"]
    }
  }
}

########################################
# LEVEL 7 - AgentCore Gateway (MCP tools for the ARIES agents)
########################################
module "agentcore_gateway" {
  source = "../../modules/agentcore_gateway"

  project     = var.project
  environment = var.environment
  name_prefix = var.name_prefix

  authorizer_type       = var.agentcore_gateway_authorizer_type
  entra_tenant_id       = var.entra_tenant_id
  jwt_allowed_audiences = var.agentcore_gateway_jwt_allowed_audiences
  jwt_allowed_clients   = var.agentcore_gateway_jwt_allowed_clients
  caller_role_arn       = module.iam.ecs_backend_task_role_arn

  lambda_targets = merge(var.agentcore_gateway_lambda_targets, {
    "incident-tools" = {
      lambda_arn         = module.gateway_tools.lambda_arn
      tool_schema_s3_uri = module.gateway_tools.tool_schema_s3_uri
      description        = "Look up approved ARIES incidents"
    }
  })
  openapi_targets    = var.agentcore_gateway_openapi_targets
  mcp_server_targets = var.agentcore_gateway_mcp_server_targets

  # The bedrock-agentcore.gateway endpoint is created with the other VPC
  # endpoints (modules/vpc_endpoints), so the module does not create its own.
  create_vpc_endpoint        = false
  vpc_id                     = local.vpc_id
  endpoint_subnet_ids        = local.subnet_ids
  allowed_security_group_ids = [module.security_groups.ecs_backend_sg_id]

  kms_key_arn = var.agentcore_gateway_kms_key_arn
}

# First gateway tool: read-only lookup of approved incidents in S3.
module "gateway_tools" {
  source = "../../modules/gateway_tools"

  project     = var.project
  environment = var.environment
  name_prefix = var.name_prefix

  incidents_bucket_name = module.s3.incidents_bucket_name
  incidents_bucket_arn  = module.s3.incidents_bucket_arn
}
